# Этап 8 — топология провинций

This stage is cumulative from Etap 7. It adds a reproducible data pipeline and a runtime graph API. The graph is generated from Natural Earth Admin-1 polygon boundaries; point-only contacts are excluded. No synthetic neighbor edges are created.

## Build
The GitHub Actions workflow installs Shapely 2, runs `prepare_natural_earth.py`, then builds the APK. The script downloads the upstream GeoJSON and emits `natural_earth_admin1_data.js` and `natural_earth_admin1_adjacency.js`.

## Runtime API
`NovariaProvinceGraph.ready()`
`neighbors(id)`
`areAdjacent(a,b)`
`moveCheck(from,to,ownerByProvince,armyOwner)`
`findPath(from,to)`
`stats()`

## Limitations
The stage-7 bundle contained an empty Natural Earth data placeholder. Therefore the checked-in adjacency bundle is intentionally empty until the build pipeline runs. This is not the original AoH2 province dataset. Do not treat Natural Earth Admin-1 regions as exact AoH2 provinces.
