const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
class Path2DMock {
  moveTo(){} lineTo(){} closePath(){}
}
const window = {Path2D:Path2DMock, devicePixelRatio:1, addEventListener(){}};
vm.runInNewContext(fs.readFileSync('app/src/main/assets/game/natural_earth_map.js','utf8'), {window, console, Promise, Set, Map, Math, Number, String, Array, Error});
const api=window.NaturalEarthMap;
assert(api, 'NaturalEarthMap API exported');
assert(api.panel().includes('Географическая карта'), 'map panel generated');
const bad=api.validateDataset({type:'FeatureCollection',features:[{type:'Feature',geometry:null,properties:{}}]});
assert.strictEqual(bad.valid,0);
assert.strictEqual(bad.invalid,1);
const polygon={type:'Feature',properties:{name:'Test Province',admin:'Testland',adm0_a3:'TST',iso_3166_2:'TS-01'},geometry:{type:'Polygon',coordinates:[[[0,0],[2,0],[2,2],[0,2],[0,0]]]}};
const data={type:'FeatureCollection',features:[polygon,polygon]};
const report=api.validateDataset(data);
assert.strictEqual(report.valid,2);
assert.strictEqual(report.duplicates,1);
api.loadData(data).then(features=>{
 assert.strictEqual(features.length,1,'duplicate feature IDs are de-duplicated');
 assert.strictEqual(api.features,1);
 assert.strictEqual(api.status.state,'ready');
 assert.strictEqual(features[0].name,'Test Province');
 console.log('Stage 21 tests passed: API, GeoJSON validation, invalid geometry, duplicate IDs, data load.');
}).catch(e=>{console.error(e);process.exit(1)});
