/* Автотест этапа 9: node tools/stage9_test.js (запуск из корня проекта) */
global.window=global;
const dir='app/src/main/assets/game/';
require('../'+dir+'province_graph.js');require('../'+dir+'army_movement.js');
let fails=0;const t=(n,c)=>{console.log((c?'PASS ':'FAIL ')+n);if(!c)fails++};
const rect=(x0,y0,x1,y1)=>[[[x0,y0],[x1,y0],[x1,y1],[x0,y1]]];
const mk=(iso,name,ring,seeds)=>({iso,name,rings:ring,bb:[Math.min(...ring[0].map(p=>p[0])),Math.min(...ring[0].map(p=>p[1])),Math.max(...ring[0].map(p=>p[0])),Math.max(...ring[0].map(p=>p[1]))],regs:seeds.map((c,i)=>({id:iso+':'+i,n:name+i,cx:c[0],cy:c[1],d:'x'}))});
/* A (две провинции) | B | отдельная C; D касается B только углом; E — союзник за B; F — нейтрал */
window.GEO={W:1000,H:500,c:{
 AAA:mk('AAA','Альфа',rect(100,100,300,200),[[150,150],[250,150]]),
 BBB:mk('BBB','Браво',rect(300,100,400,200),[[350,150]]),
 CCC:mk('CCC','Чарли',rect(600,100,700,200),[[650,150]]),
 DDD:mk('DDD','Дельта',rect(400,200,450,250),[[425,225]]),
 EEE:mk('EEE','Эхо',rect(400,100,500,200),[[450,150]]),
 FFF:mk('FFF','Фокс',rect(500,100,600,200),[[550,150]])}};
const r=NovariaProvinceGraph.buildFromGeo(GEO,{cols:500});
t('граф построен',r.ok&&r.regions===7);
const P=NovariaProvinceGraph;
t('внутри страны соседи AAA:0–AAA:1',P.areAdjacent('AAA:0','AAA:1'));
t('через границу стран AAA:1–BBB:0',P.areAdjacent('AAA:1','BBB:0'));
t('AAA:0 не сосед BBB:0',!P.areAdjacent('AAA:0','BBB:0'));
t('касание углом BBB–DDD не считается',!P.areAdjacent('BBB:0','DDD:0'));
t('CCC изолирована',P.neighbors('CCC:0').includes('FFF:0')&&!P.neighbors('CCC:0').includes('BBB:0'));
t('findPath AAA:0→EEE:0 через BBB',JSON.stringify(P.findPath('AAA:0','EEE:0').path)==='["AAA:0","AAA:1","BBB:0","EEE:0"]');
const A=NovariaArmies;
const S={me:'Альфа',name:'Альфа',year:1,month:0,taken:{},wars:[],allies:[],relations:[{name:'Браво',value:10},{name:'Эхо',value:80},{name:'Фокс',value:0},{name:'Чарли',value:0}],
 military:{divisions:[{id:1,type:'infantry',manpower:10000,supply:80},{id:2,type:'armor',manpower:5000,supply:80},{id:3,type:'infantry',manpower:9000,supply:80}]}};
t('размещение в чужой провинции запрещено',!A.deploy(S,[1],'BBB:0').ok);
const d=A.deploy(S,[1,2],'AAA:0');t('размещение в своей провинции',d.ok);
t('занятые дивизии не берутся повторно',A.freeDivisions(S).length===1&&A.freeDivisions(S)[0].id===3);
const st=d.stack;
t('скорость = самый медленный тип (пехота 25)',A.stackSpeed(S,st)===25);
let p=A.plan(S,st,'AAA:1');t('маршрут по своим провинциям',p.ok&&p.path.length===1&&p.days>=1);
p=A.plan(S,st,'BBB:0');t('нейтрал без союза — проход запрещён',!p.ok&&p.code==='FORBIDDEN');
S.allies=['Браво'];p=A.plan(S,st,'BBB:0');t('союзник без разрешения — NO_ACCESS',!p.ok&&p.code==='NO_ACCESS');
t('запрос доступа у союзника',A.requestAccess(S,'Браво').ok);
p=A.plan(S,st,'BBB:0');t('союзник с разрешением — проход',p.ok&&p.path.join()==='AAA:1,BBB:0');
S.wars=[{n:'Эхо'}];p=A.plan(S,st,'EEE:0');t('вражеская провинция — отказ (бои в этапе 10)',!p.ok);
S.wars=[];t('Эхо не союзник и не даёт доступ (relation≥60 даёт)',A.requestAccess(S,'Эхо').ok);
S.allies=['Браво','Эхо'];p=A.plan(S,st,'EEE:0');t('маршрут через двух союзников',p.ok&&p.path.length===3);
const o=A.order(S,st.id,'AAA:1');t('приказ принят',o.ok&&st.status==='moving');
const fast=A.stackSpeed(S,A.deploy(S,[3],'AAA:0').stack);
A.advance(S,1);t('движение по суткам (дискретный переход)',st.status==='moving'||st.prov==='AAA:1');
t('время хода >1 суток на большом расстоянии',A.plan(S,st,'AAA:1').days>30);A.tick(S);t('за месяц армия ещё в пути (расстояние ~4000 км)',st.status==='moving');A.advance(S,400);t('армия дошла',st.prov==='AAA:1'&&st.status==='idle');
t('возврат на исходную позицию',A.recall(S,st.id).ok&&(A.advance(S,400),st.prov==='AAA:0'));
/* потеря доступа во время марша: остановка */
A.order(S,st.id,'BBB:0');A.advance(S,1);A.revokeAccess(S,'Браво');A.advance(S,2000);t('потеря доступа — армия остановлена, не входит в чужую',st.prov!=='BBB:0');
/* сохранение */
const S2=JSON.parse(JSON.stringify(S));t('позиции переживают сохранение',A.ensure(S2).stacks[0].prov===st.prov&&A.ensure(S2).nextId===S.armies.nextId);
t('ownerOf учитывает захват',(S.taken['BBB:0']=1,A.ownerOf(S,'BBB:0')==='Альфа'));
console.log(fails?'\nПРОВАЛЕНО: '+fails:'\nВсе тесты пройдены');process.exit(fails?1:0);
