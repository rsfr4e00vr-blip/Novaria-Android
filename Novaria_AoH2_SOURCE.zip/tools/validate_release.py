#!/usr/bin/env python3
"""Strict pre-APK checks. Run after prepare_natural_earth.py."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GAME = ROOT / "app/src/main/assets/game"
def read_assignment(path, variable):
    raw = path.read_text(encoding="utf-8")
    match = re.search(r"window\." + re.escape(variable) + r"\s*=\s*(\{.*\})\s*;\s*$", raw, re.S)
    if not match:
        raise SystemExit(f"FAIL: {path.name} does not contain {variable} JSON assignment")
    try:
        return json.loads(match.group(1))
    except json.JSONDecodeError as exc:
        raise SystemExit(f"FAIL: invalid JSON in {path.name}: {exc}")

geometry = read_assignment(GAME / "natural_earth_admin1_data.js", "NATURAL_EARTH_ADMIN1")
adjacency = read_assignment(GAME / "natural_earth_admin1_adjacency.js", "NATURAL_EARTH_ADMIN1_ADJACENCY")
features = geometry.get("features", [])
neighbors = adjacency.get("neighbors", {})
if geometry.get("type") != "FeatureCollection" or len(features) < 3000:
    raise SystemExit(f"FAIL: expected >=3000 Admin-1 polygons, got {len(features)}")
if adjacency.get("source") != "Natural Earth Admin-1" or not neighbors:
    raise SystemExit("FAIL: adjacency graph is missing or still a placeholder")
ids = set()
for i, feature in enumerate(features):
    props = feature.get("properties") or {}
    geom = feature.get("geometry") or {}
    rid = props.get("novaria_id") or props.get("iso_3166_2")
    if not rid or geom.get("type") not in ("Polygon", "MultiPolygon"):
        raise SystemExit(f"FAIL: feature {i} lacks a stable id or polygon geometry")
    if rid in ids:
        raise SystemExit(f"FAIL: duplicate region ID {rid}")
    ids.add(rid)
edge_count = sum(len(v) for v in neighbors.values()) // 2
if edge_count <= 0:
    raise SystemExit("FAIL: adjacency graph has no edges")

html = (GAME / "game.html").read_text(encoding="utf-8")
if html.find('src="save_manager.js"') < 0 or html.find('src="save_manager.js"') > html.find('src="game.js"'):
    raise SystemExit("FAIL: save_manager.js must load before game.js")
for required in ('stage22-mobile.css', 'stage22-mobile.js', 'natural_earth_map.js'):
    if required not in html:
        raise SystemExit(f"FAIL: {required} is not included in game.html")
manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
if 'android:name=".MainActivity"' not in manifest or 'compileSdk = 35' not in gradle:
    raise SystemExit("FAIL: Android launcher or compile SDK configuration is missing")
print(f"Release validation passed: {len(features)} polygons, {edge_count} adjacency edges, {len(ids)} unique IDs.")
