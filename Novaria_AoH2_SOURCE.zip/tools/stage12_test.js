/* Этап 12 — автоматические проверки экономических последствий войны.
 * Запуск из корня проекта: node tools/stage12_test.js
 */
'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
global.window=global;
global.NovariaArmies={regionOf:id=>({id,n:'Тестовый регион'})};
vm.runInThisContext(fs.readFileSync(path.join(__dirname,'../app/src/main/assets/game/war_economy.js'),'utf8'));
const fresh=()=>({gdp:42000,money:10000,debt:0,pop:1000000,tax:20,employment:95,inflation:5,stability:70,approval:60,trust:70,
 wars:[],mpWars:[],regions:[{name:'Тестовый регион',industry:70,infra:70,unrest:10}],military:{divisions:[]},armies:{stacks:[]},battles:{history:[]}});
let checks=0;
function ok(v,msg){assert.ok(v,msg);checks++}
function eq(a,b,msg){assert.strictEqual(a,b,msg);checks++}
{
 const S=fresh(),r=NovariaWarEconomy.tick(S,42000);
 eq(r.war,false,'peace status');
 eq(r.maintenance,0,'no peacetime army maintenance');
}
{
 const S=fresh();S.wars=[{n:'Сосед'}];
 S.military.divisions=[{id:1,type:'infantry',manpower:12000},{id:2,type:'armor',manpower:3000}];
 S.armies.stacks=[{divs:[1,2]}];
 const before=S.money,emp=S.employment,gdp=S.gdp;
 const r=NovariaWarEconomy.tick(S,gdp);
 ok(r.maintenance>0,'maintenance charged');
 ok(r.mobilization>0,'initial mobilization charged');
 ok(S.money<before,'war costs charged to treasury');
 ok(S.employment<emp,'mobilization affects employment');
 ok(S.gdp<gdp,'war pressure affects GDP');
 ok(S.warEconomy.totalTaxLoss>0,'tax revenue loss tracked');
 const m=r.mobilization;
 const r2=NovariaWarEconomy.tick(S,S.gdp);
 eq(r2.mobilization,0,'no repeated mobilization charge for unchanged force');
 ok(S.warEconomy.totalMaintenance>r.maintenance,'maintenance accumulates monthly');
}
{
 const S=fresh();S.wars=[{n:'Сосед'}];
 S.battles.history=[{id:1,target:'X:0',attLost:4000,defLost:5000,result:'attacker_victory'}];
 const r=NovariaWarEconomy.tick(S,S.gdp);
 ok(r.battleDamage>0,'battle losses create economic damage');
 ok(S.regions[0].industry<70,'battle damage reduces industry');
 ok(S.regions[0].infra<70,'battle damage reduces infrastructure');
 ok(S.warEconomy.recovery>0,'recovery bill created');
 const before=S.money;
 S.wars=[];
 const r2=NovariaWarEconomy.tick(S,S.gdp);
 ok(S.money<=before,'recovery is funded from treasury');
 ok(S.warEconomy.recovery<r.recoveryLeft,'recovery balance decreases when funded');
}
{
 const S=fresh();S.warEconomy={version:1,pendingOutcome:'victory',processedBattles:[],recovery:100};
 const before=S.stability,approval=S.approval;
 const r=NovariaWarEconomy.tick(S,S.gdp);
 eq(r.outcome,'victory','victory settlement recognized');
 ok(S.stability>before&&S.approval>approval,'victory effects applied');
 ok(!S.warEconomy.pendingOutcome,'outcome consumed once');
}
{
 const S=fresh();S.wars=[{n:'Сосед'}];S.military.divisions=[{id:1,manpower:1000}];
 NovariaWarEconomy.tick(S,S.gdp);
 const saved=JSON.parse(JSON.stringify(S));
 ok(saved.warEconomy&&saved.warEconomy.last,'war economy persists in save state');
}
console.log(`Этап 12: успешно ${checks} проверок.`);
