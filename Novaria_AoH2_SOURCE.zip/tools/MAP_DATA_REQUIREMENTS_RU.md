# Требования к оригинальным данным карты AoH2

Публичная документация стороннего рендерера AgeOfHistory2Map описывает структуру:
- геометрия провинций: `data/map/Earth/data/provinces/{provinceId}`;
- сценарные цивилизации: `data/map/Earth/scenarios/{scenario}/{scenario}`;
- владельцы провинций: `data/map/Earth/scenarios/{scenario}/{scenario}_PD`;
- определения цивилизаций: `data/game/civilizations/{civTag}`.

См. https://github.com/samuelyuan/AgeOfHistory2Map

Нужна законно полученная копия игровых данных. Архив исходного кода сам по себе не заменяет данные установленной игры. Не включайте в публичный ZIP ресурсы, если лицензия игры не разрешает их распространение.

Natural Earth Admin-1 описывает административные единицы первого уровня и не является точной заменой провинциям AoH2.
