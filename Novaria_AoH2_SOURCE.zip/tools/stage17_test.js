const assert=require('assert');
const fs=require('fs'),vm=require('vm');
const src=fs.readFileSync('app/src/main/assets/game/extended_diplomacy.js','utf8');
const ctx={console,Math,Number,Object,Array,String,JSON,Set,globalThis:null};ctx.globalThis=ctx;ctx.window=ctx;vm.createContext(ctx);vm.runInContext(src,ctx);
const D=ctx.NovariaDiplomacy;assert(D,'API экспортирован');
let checks=0;const ok=(c,m)=>{assert(c,m);checks++};const eq=(a,b,m)=>{assert.deepStrictEqual(a,b,m);checks++};

const mk=(name,o)=>Object.assign({name,iso:name,power:50,gdp:1000,pop:100,manpower:8,treasury:100,morale:75,stability:65,debt:0,exhaustion:5,relations:30,allies:[],tradePartners:[],rivals:{},ideology:'прагматизм'},o||{});
const world=(names,extra)=>{const W={month:1,nations:names.map(n=>mk(n)),wars:[],alliances:[],events:[],player:'Игрок'};return Object.assign(W,extra||{})};

/* --- 1. Базовое состояние --- */
let W=world(['A','B','C','D','E']);
const T=D.ensure(W);ok(T&&T.version===1,'состояние создано');
ok(['nap','alliance','access','trade','sanction','reparation'].every(k=>D.TYPES[k]),'все типы договоров описаны');

/* --- 2. Ненападение: принятие, дубль, отказ с задержкой --- */
let r=D.propose(W,'nap','A','B',{},{});ok(r.accepted&&r.treaty,'дружественные страны подписали пакт');
ok(D.hasPact(W,'A','B')&&D.hasPact(W,'B','A'),'пакт взаимный');
r=D.propose(W,'nap','A','B',{},{});ok(!r.accepted&&/уже действует/.test(r.reason),'повторный пакт запрещён');
W.treaties.rel[['A','C'].sort().join('::')]=-60;
r=D.propose(W,'nap','A','C',{},{});ok(!r.accepted,'враждебная страна пакт не подписывает');
r=D.propose(W,'nap','A','C',{},{});ok(!r.accepted,'второй отказ подряд');

/* --- 3. Союз: порог отношений и синхронизация со старой системой --- */
W.treaties.rel[['A','D'].sort().join('::')]=10;
r=D.propose(W,'alliance','A','D',{},{});ok(!r.accepted&&/25/.test(r.reason),'для союза нужны отношения ≥25');
W.treaties.rel[['A','E'].sort().join('::')]=70;
r=D.propose(W,'alliance','A','E',{},{});ok(r.accepted,'союз при высоких отношениях принят');
ok(W.nations[0].allies.includes('E')&&W.nations[4].allies.includes('A'),'allies синхронизированы');
ok(W.alliances.some(x=>x.a==='A'&&x.b==='E'),'запись в W.alliances добавлена');
ok(D.hasAccess(W,'A','E')&&D.hasAccess(W,'E','A'),'союз даёт военный доступ');

/* --- 4. Военный доступ --- */
W.treaties.rel[['B','C'].sort().join('::')]=30;
r=D.propose(W,'access','B','C',{},{});ok(r.accepted&&D.hasAccess(W,'B','C')&&!D.hasAccess(W,'C','B'),'доступ односторонний');

/* --- 5. Торговля и санкции --- */
r=D.propose(W,'trade','B','E',{},{});ok(r.accepted,'торговое соглашение подписано');
ok(W.nations[1].tradePartners.includes('E')&&W.nations[4].tradePartners.includes('B'),'tradePartners связаны');
W.nations[0].treasury=100;
r=D.propose(W,'sanction','C','E',{},{});ok(r.accepted,'санкции введены');
ok(W.nations[4].sanctions===1,'счётчик санкций n.sanctions обновлён для экономики');
ok(W.nations[4].economicGrievances&&W.nations[4].economicGrievances.C.severity>0,'санкции порождают экономическую претензию');
r=D.propose(W,'sanction','A','E',{},{});ok(!r.accepted&&/союзник/.test(r.reason),'нельзя санкционировать союзника');
r=D.propose(W,'trade','C','E',{},{});ok(!r.accepted,'торговля под санкциями невозможна');

/* --- 6. Разрыв и восстановление отношений --- */
r=D.breakRelations(W,'B','E','тест');ok(r.ok,'отношения разорваны');
ok(!W.nations[1].tradePartners.includes('E'),'торговля прекращена при разрыве');
r=D.propose(W,'trade','B','E',{},{});ok(!r.accepted&&/разорваны/.test(r.reason),'после разрыва договоры невозможны');
r=D.restoreRelations(W,'B','E');ok(!r.ok,'восстановить сразу нельзя');
W.month+=10;r=D.restoreRelations(W,'B','E');ok(r.ok,'через несколько месяцев можно восстановить');

/* --- 7. Объявление войны: пакт, союз, последствия --- */
W=world(['A','B','C']);D.ensure(W);
D.propose(W,'nap','A','B',{},{});
let c=D.canDeclareWar(W,'A','B');ok(!c.ok&&/ненападении/.test(c.reason),'пакт блокирует войну');
c=D.canDeclareWar(W,'A','B',{breakPact:true});ok(c.ok&&c.violation,'игрок может нарушить пакт, нарушение отмечено');
const relBefore=D.relGet(W,'A','B');
const war={id:'1:A:B',a:'A',b:'B',months:0,score:0,front:50,joinedA:[],joinedB:[]};W.wars.push(war);
D.onWarDeclared(W,'A','B',war);
ok(!D.hasPact(W,'A','B'),'пакт расторгнут при нарушении');
ok(D.relGet(W,'A','B')<relBefore-30,'отношения резко упали');
ok(W.treaties.aggression.A>=38,'агрессор получил штраф репутации (война + нарушение)');
const aggr=W.treaties.aggression.A;D.onWarDeclared(W,'A','B',war);eq(W.treaties.aggression.A,aggr,'повторная регистрация войны идемпотентна');
W.treaties.rel['A::C']=70;ok(D.propose(W,'alliance','A','C',{},{}).accepted,'союз A–C заключён');
c=D.canDeclareWar(W,'A','C');ok(!c.ok,'союзнику нельзя объявить войну');

/* --- 8. Мир: репарации, контрибуции, территория --- */
W=world(['W','L','X']);D.ensure(W);
const w1={id:'w1',a:'W',b:'L',goal:'territory',claimRegion:'Север',months:6,score:60,joinedA:[],joinedB:[]};W.wars.push(w1);D.onWarDeclared(W,'W','L',w1);
const d0={w:W.nations[0].treasury,l:W.nations[1].treasury};W.nations[0].treasury+=18;
const out=D.onPeace(W,w1,W.nations[0],W.nations[1],60,d0);
ok(out.reparation&&out.reparation.type==='reparation','репарации оформлены договором');
eq(out.contribution,18,'контрибуция зафиксирована по фактическому переводу казны');
ok(out.territory&&out.territory.ok&&W.treaties.transfers[0].region==='Север','передача территории записана');
ok(W.nations[1].lostRegions.some(x=>x.region==='Север'),'проигравший потерял область');
ok(W.nations[0].gainedRegions.some(x=>x.region==='Север'),'победитель получил область');
W.wars=[];
const tw=W.nations[0].treasury,tl=W.nations[1].treasury;
D.tick(W,W.nations);
ok(W.nations[0].treasury>tw&&W.nations[1].treasury<tl,'репарации реально переводят деньги');
const t0=W.nations[0].treasury;W.month++;D.tick(W,W.nations);ok(W.nations[0].treasury>t0,'выплаты идут каждый месяц');
W.nations[1].treasury=0;const rep=W.treaties.list.find(t=>t.type==='reparation');
for(let i=0;i<4;i++){W.month++;D.tick(W,W.nations)}
ok(rep.arrears>=3,'просрочка репараций накапливается');
ok(W.nations[0].economicGrievances&&W.nations[0].economicGrievances.L,'просрочка порождает претензию');
const w2={id:'w2',a:'W',b:'X',goal:'tribute',months:5,score:5,joinedA:[],joinedB:[]};
const nap=D.onPeace(W,w2,W.nations[0],W.nations[2],5,null);
ok(nap.nap&&D.hasPact(W,'W','X'),'мир без решающей победы создаёт пакт о ненападении');

/* --- 9. Коалиции --- */
W=world(['T','M1','M2','M3','M4','F']);D.ensure(W);
W.nations[0].power=120;
W.treaties.aggression.T=55;
['M1','M2','M3','M4'].forEach(n=>W.treaties.rel[['T',n].sort().join('::')]=-20);
D.propose(W,'alliance','T','F',{},{});
D.tick(W,W.nations);
const coal=W.treaties.coalitions[0];
ok(coal&&coal.target==='T'&&coal.members.length>=2,'против агрессора формируется коалиция');
ok(!coal.members.includes('F'),'союзник агрессора в коалицию не входит');
ok(W.treaties.list.some(t=>t.type==='sanction'&&t.b==='T'),'коалиция вводит санкции');
ok(W.nations[0].sanctions>=1,'экономика видит санкции против агрессора');
const wc={id:'c1',a:'T',b:'F2',months:2,score:0,front:50,joinedA:[],joinedB:[]};
W.nations.push(mk('F2'));W.wars.push(wc);W.nations[0].war='c1';
let joined=false;for(let i=0;i<40&&!joined;i++){W.month++;D.tick(W,W.nations);joined=wc.joinedB.length>0}
ok(joined,'члены коалиции вступают в войну против агрессора');
W.treaties.aggression.T=0;W.wars=[];for(let i=0;i<2;i++){W.month++;D.tick(W,W.nations)}
eq(W.treaties.coalitions.length,0,'после снижения агрессии коалиция распускается');

/* --- 10. Совместные операции --- */
W=world(['L1','H','AL','Z']);D.ensure(W);
W.treaties.rel['AL::L1']=70;ok(D.propose(W,'alliance','L1','AL',{},{}).accepted,'союз L1–AL заключён');
const wj={id:'j1',a:'L1',b:'Z',months:3,score:0,front:50,joinedA:['AL'],joinedB:[]};W.wars.push(wj);W.treaties.seenWars.j1=1;
const tre=W.nations[2].treasury;W.month++;D.tick(W,W.nations);
ok(wj.score>0&&wj.front>50,'союзник с доступом даёт совместный бонус в войне');
ok(W.nations[2].treasury<tre,'совместная операция стоит денег');
ok(W.treaties.joint.j1&&W.treaties.joint.j1.a.includes('AL'),'операция записана');
const sc=wj.score;D.tick(W,W.nations);eq(wj.score,sc,'повторный вызов в тот же месяц идемпотентен');
const wk={id:'j2',a:'L1',b:'Z',months:3,score:0,front:50,joinedA:['H'],joinedB:[]};W.wars=[wk];W.treaties.seenWars.j2=1;W.month++;D.tick(W,W.nations);
eq(wk.score,0,'без союза или доступа координации нет');

/* --- 11. Принятие старых данных, срок действия, сохранение --- */
W=world(['P','Q','R']);W.nations[0].allies=['Q'];W.nations[1].allies=['P'];W.alliances.push({a:'P',b:'Q',formed:0});W.nations[1].tradePartners=['R'];W.nations[2].tradePartners=['Q'];
D.tick(W,W.nations);
ok(D.find(W,'alliance','P','Q'),'существующий союз принят в реестр');
ok(D.find(W,'trade','Q','R'),'существующая торговля принята в реестр');
eq(W.alliances.length,1,'дубликатов союзов не создано');
const nt=D.propose(W,'nap','P','R',{},{}).treaty;ok(nt&&nt.expires===W.month+60,'срок пакта 60 месяцев');
const saved=JSON.parse(JSON.stringify(W));D.tick(saved,saved.nations);saved.month++;D.tick(saved,saved.nations);
ok(saved.treaties.list.length>=3,'состояние переживает сохранение и загрузку');
W.month=nt.expires;D.tick(W,W.nations);ok(!D.find(W,'nap','P','R'),'договор истёк по сроку');
const old=world(['O1','O2']);old.treaties={version:0,junk:true};ok(D.ensure(old).version===1,'старое/повреждённое состояние пересоздаётся');
const bad=world(['B1','B2']);bad.treaties={version:1,list:null,rel:[],cool:5};ok(Array.isArray(D.ensure(bad).list)&&!Array.isArray(bad.treaties.rel),'повреждённые поля восстанавливаются');

/* --- 12. ИИ действует по тем же правилам и детерминирован --- */
const names=[];for(let i=0;i<30;i++)names.push('N'+i);
const run=()=>{const w=world(names);w.nations.forEach((n,i)=>{n.power=20+i*3;n.relations=20+(i%7)*5;n.exports=5;n.imports=5});D.ensure(w);
 for(let m=1;m<=36;m++){w.month=m;D.tick(w,w.nations)}return w};
const a1=run(),a2=run();
ok(a1.treaties.list.length>0,'ИИ заключает договоры');
eq(a1.treaties.list.map(t=>t.id+t.type+t.a+t.b).join('|'),a2.treaties.list.map(t=>t.id+t.type+t.a+t.b).join('|'),'поведение ИИ воспроизводимо');
ok(a1.treaties.list.every(t=>t.a!==t.b),'нет договоров страны с самой собой');
ok(a1.nations.every(n=>n.allies.length<=5&&n.tradePartners.length<=8),'лимиты союзов и партнёров соблюдены');
ok(a1.nations.every(n=>n.allies.every(x=>a1.nations.find(y=>y.name===x).allies.includes(n.name))),'союзы взаимны');

/* --- 13. Игрок: те же правила --- */
const S={me:'Игрок',year:1,month:0,money:300,gdp:500,power:40,stability:60,allies:[],relations:[{name:'A',value:50},{name:'B',value:-50}],aiWorld:null};
S.aiWorld=world(['A','B']);
r=D.playerAction(S,'nap','A',{});ok(r.accepted,'игрок подписывает пакт с дружественной страной');
ok(S.pacts&&S.pacts.A>0,'пакт отражён в старой системе S.pacts');
r=D.playerAction(S,'nap','B',{});ok(!r.accepted,'враждебная страна отказала игроку');
r=D.playerAction(S,'alliance','A',{});ok(r.accepted&&S.allies.includes('A'),'союз игрока обновляет S.allies');
S.relations[0].value=10;
r=D.playerAction(S,'sanction','B',{});ok(r.accepted&&S.sanc&&S.sanc.B,'санкции игрока отражены в S.sanc');
r=D.playerAction(S,'cancel_nap','A',{});ok(r.ok&&r.violation,'односторонний выход из пакта считается нарушением');
ok(S.relations[0].value<10,'нарушение ухудшает отношения в старой системе');
r=D.playerAction(S,'join_coalition','B',{});ok(!r.ok,'вступить можно только в существующую коалицию');
const html=D.panel(S.aiWorld,S);ok(typeof html==='string'&&html.includes('ndTarget'),'панель выводит управление игрока');
const evil=world(['<b>X</b>','Y']);evil.player='Игрок';D.ensure(evil);D.propose(evil,'nap','<b>X</b>','Y',{},{});
ok(!D.panel(evil,null).includes('<b>X</b>'),'названия экранируются в панели');

console.log(`Stage 17 OK: ${checks} assertions`);
