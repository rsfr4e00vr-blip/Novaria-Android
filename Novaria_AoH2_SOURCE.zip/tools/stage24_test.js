const fs=require('fs'),assert=require('assert');
const wf=fs.readFileSync('.github/workflows/android-apk.yml','utf8');
const order=['Run all strategy regression tests','Generate Natural Earth administrative polygons and adjacency graph','Validate release assets and Android configuration','Build debug APK','Upload debug APK'];
let last=-1;for(const label of order){const p=wf.indexOf(label);assert(p>last,`workflow step order: ${label}`);last=p;}
assert(wf.includes('assembleDebug'),'debug APK build configured');
assert(wf.includes('Novaria-AoH2-Android-APK'),'APK artifact named');
const html=fs.readFileSync('app/src/main/assets/game/game.html','utf8');
assert(html.indexOf('src="save_manager.js"')<html.indexOf('src="game.js"'),'SaveManager loads before game.js');
console.log('Stage 24 tests passed: CI test/build/artifact order and app script dependencies.');
