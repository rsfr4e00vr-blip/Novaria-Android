/* Автотест этапа 10: node tools/stage10_test.js */
global.window=global;const dir='app/src/main/assets/game/';
['province_graph','army_movement','battle_system'].forEach(f=>require('../'+dir+f+'.js'));
let fails=0;const t=(n,c)=>{console.log((c?'PASS ':'FAIL ')+n);if(!c)fails++};
const rect=(x0,y0,x1,y1)=>[[[x0,y0],[x1,y0],[x1,y1],[x0,y1]]];
const mk=(iso,name,ring,seeds)=>({iso,name,rings:ring,bb:[Math.min(...ring[0].map(p=>p[0])),Math.min(...ring[0].map(p=>p[1])),Math.max(...ring[0].map(p=>p[0])),Math.max(...ring[0].map(p=>p[1]))],regs:seeds.map((c,i)=>({id:iso+':'+i,n:name+i,cx:c[0],cy:c[1],s:100/seeds.length,d:'x'}))});
window.GEO={W:1000,H:500,c:{AAA:mk('AAA','Альфа',rect(100,100,300,200),[[150,150],[250,150]]),BBB:mk('BBB','Браво',rect(300,100,400,200),[[350,150]]),CCC:mk('CCC','Чарли',rect(600,100,700,200),[[650,150]])}};
NovariaProvinceGraph.buildFromGeo(GEO,{cols:500});
const A=NovariaArmies,B=NovariaBattles;
const mkS=(n,power)=>({me:'Альфа',name:'Альфа',year:1,month:0,army:200000,taken:{},wars:[],allies:[],relations:[{name:'Браво',value:-50,power:power||40}],
 military:{log:[],divisions:Array.from({length:n},(_,i)=>({id:i+1,type:i%4===3?'artillery':'infantry',manpower:10000,supply:80,morale:70,equipment:60,experience:10}))}});
let S=mkS(6);const st=A.deploy(S,[1,2,3,4,5,6],'AAA:1').stack;
t('нет войны — атака запрещена',!B.attack(S,st.id,'BBB:0').ok);
S.wars=[{n:'Браво'}];
t('не соседняя провинция — запрет',(st.prov='AAA:0',!B.attack(S,st.id,'BBB:0').ok));st.prov='AAA:1';
t('своя провинция — запрет',!B.attack(S,st.id,'AAA:0').ok);
t('цели для атаки найдены',B.targets(S,st).join()==='BBB:0');
t('движение в вражескую провинцию без атаки запрещено',A.plan(S,st,'BBB:0').code==='ENEMY_TERRITORY');
const pv=B.preview(S,st.id,'BBB:0');t('предпросмотр боя',pv&&pv.garrison>0&&pv.ratio>0);
const r=B.attack(S,st.id,'BBB:0');t('бой начался',r.ok&&st.status==='fighting');
t('армия в бою не получает приказ движения',!A.order(S,st.id,'AAA:0').ok&&!A.disband(S,st.id).ok);
t('второй бой за ту же провинцию запрещён',!B.attack(S,st.id,'BBB:0').ok);
const army0=S.army;B.advance(S,3);
t('потери списываются с дивизий и армии',S.army<army0&&S.battles.active[0].attLost>0&&S.battles.active[0].defLost>0);
t('защитник подкрепляется / мораль меняется',S.battles.active.length===0||S.battles.active[0].defMor<65);
B.advance(S,100);
t('бой завершился и попал в историю',S.battles.active.length===0&&S.battles.history.length===1);
const h=S.battles.history[0];console.log('  итог:',h.result,'дни',h.days,'потери',h.attLost,h.defLost);
t('владелец провинции НЕ изменён (захват — этап 11)',A.ownerOf(S,'BBB:0')==='Браво'&&!S.taken['BBB:0']);
t('армия снова свободна',(A.find(S,st.id)||{status:'idle'}).status==='idle');
/* детерминизм */
const run=(n,pw)=>{const X=mkS(n,pw);const s=A.deploy(X,X.military.divisions.map(d=>d.id),'AAA:1').stack;X.wars=[{n:'Браво'}];B.attack(X,s.id,'BBB:0');B.advance(X,100);return X.battles.history[0]};
const r1=run(6,40),r2=run(6,40);t('результат детерминирован',JSON.stringify(r1)===JSON.stringify(r2));
console.log('  6vs40:',run(6,40).result,run(6,40).days,' 3vs40:',run(3,40).result,run(3,40).days,' 10vs60:',run(10,60).result,run(10,60).days);const strong=run(14,20);t('сильная армия против слабого гарнизона побеждает',strong.result==='attacker_victory');
const weak=run(2,95);t('слабая армия против сильного гарнизона отступает или разгромлена',weak.result==='defender_victory'||weak.result==='rout');
t('прорыв отмечен для этапа 11',(()=>{const X=mkS(14,20);const s=A.deploy(X,X.military.divisions.map(d=>d.id),'AAA:1').stack;X.wars=[{n:'Браво'}];B.attack(X,s.id,'BBB:0');B.advance(X,100);return !!X.battles.breach['BBB:0']})());
/* укрепления и местность влияют */
const f0=B.fortOf('AAA:0');t('укрепления 0–3, местность определена',f0>=0&&f0<=3&&!!B.TERRAIN[B.terrainOf('BBB:0')]);
/* подкрепления */
const Y=mkS(8);const sy=A.deploy(Y,[1,2,3],'AAA:1').stack;Y.wars=[{n:'Браво'}];B.attack(Y,sy.id,'BBB:0');
t('подкрепления принимаются',B.reinforce(Y,sy.id,[4,5]).ok&&A.freeDivisions(Y).length===3);
B.advance(Y,3);t('подкрепления прибыли через 3 суток или бой окончен',sy.divs.length>=5||Y.battles.active.length===0);
/* отступление по приказу */
const Z=mkS(6);const sz=A.deploy(Z,[1,2,3],'AAA:1').stack;Z.wars=[{n:'Браво'}];B.attack(Z,sz.id,'BBB:0');B.advance(Z,1);
t('отступление по приказу',B.retreat(Z,sz.id).ok&&sz.status==='idle'&&Z.battles.history[0].result==='defender_victory');
/* мир во время боя */
const Q=mkS(6);const sq=A.deploy(Q,[1,2,3],'AAA:1').stack;Q.wars=[{n:'Браво'}];B.attack(Q,sq.id,'BBB:0');B.advance(Q,1);Q.wars=[];B.advance(Q,1);
t('мир прекращает бой',Q.battles.active.length===0&&Q.battles.history[0].result==='ceasefire');
/* сохранение посреди боя */
const W2=mkS(6);const sw=A.deploy(W2,[1,2,3],'AAA:1').stack;W2.wars=[{n:'Браво'}];B.attack(W2,sw.id,'BBB:0');B.advance(W2,2);
const W3=JSON.parse(JSON.stringify(W2));B.advance(W2,100);B.advance(W3,100);t('бой переживает сохранение/загрузку (тот же итог)',JSON.stringify(W2.battles.history)===JSON.stringify(W3.battles.history));
console.log(fails?'\nПРОВАЛЕНО: '+fails:'\nВсе тесты пройдены');process.exit(fails?1:0);
