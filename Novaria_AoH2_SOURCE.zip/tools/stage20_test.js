const assert=require('node:assert/strict');
global.window=global;
require('../app/src/main/assets/game/unified_game_system.js');
require('../app/src/main/assets/game/economy_core.js');
const U=global.UnifiedGameSystem;
assert.ok(U,'module exported');
const S={year:1,month:1,pop:1000000,army:12000,money:500,gdp:42000,food:20,fuel:25,energy:30,steel:35,equipment:70,ammo:70,morale:65,
 relations:[{name:'A',value:65},{name:'B',value:50},{name:'C',value:-20,embargo:0}],pacts:{A:20},allies:['A'],
 regions:[{name:'North',pop:600000,infra:80,industry:75,productivity:.95,unrest:10},{name:'South',pop:400000,infra:40,industry:35,productivity:.7,unrest:35}],
 wars:[{n:'Enemy'}]};
const before=S.food;
const row=U.tickPlayer(S);
assert.ok(row&&U.validate(S));
assert.equal(row.provinces.count,2);
assert.ok(row.provinces.index>0);
assert.ok(row.diplomacy.access>0);
assert.ok(row.military.readiness>0);
assert.ok(Number.isFinite(S.effectiveMilitaryPower));
assert.ok(S.food>=before,'resource import should ease shortage');
const after=S.food;
const repeated=U.tickPlayer(S);
assert.equal(repeated,row,'same month must be idempotent');
assert.equal(S.food,after,'duplicate call must not import twice');
const saved=JSON.parse(JSON.stringify(S));
assert.ok(U.validate(saved),'state must survive save/load');
const panel=global.EconCore.panelHtml(S);
assert.ok(panel.includes('Связь игровых систем'),'economy UI should expose cross-system metrics');
for(let m=2;m<35;m++){S.month=m%12;S.year=1+Math.floor(m/12);U.tickPlayer(S)}
assert.ok(S.unifiedSystems.history.length<=24);
const W={month:1};
const n={name:'AI',gdp:10000,pop:100,war:true,power:90,morale:70,manpower:3,industry:1.2,infrastructure:1.1,
 food:15,fuel:18,energy:30,steel:40,tradePartners:['X'],allies:['Y'],regions:[{productivity:1.1,industry:1.2,infrastructure:1.1}]};
const ai=U.tickNation(W,n);
assert.ok(ai&&Number.isFinite(n.effectivePower));
assert.ok(ai.military.readiness>0);
assert.equal(U.tickNation(W,n),ai,'AI same-month call must be idempotent');
assert.ok(n.food>=15,'AI trade channel should ease shortage');
console.log('Stage 20 tests passed: 17 assertions; player, AI, persistence, idempotence, resource access, province and military feedback.');
