/* Stage 19 integration: AI nations receive and resolve domestic events using their persisted country state. */
const assert=require('assert'),fs=require('fs'),vm=require('vm');
const G='app/src/main/assets/game/';
const ctx={console,Math,Number,Object,Array,String,JSON,Set,Map,Date,setInterval:()=>0,setTimeout:()=>0};
ctx.window=ctx;ctx.globalThis=ctx;ctx.document={getElementById:()=>null};vm.createContext(ctx);
const list=[];for(let i=0;i<80;i++)list.push({name:'Страна'+i,iso:'C'+i,pop:5+i%9*3,inc:1+i%5,power:15+(i*7)%60,lat:i%80-20,lon:(i*13)%300-150});
ctx.WORLD={list,map:Object.fromEntries(list.map(c=>[c.name,c]))};
for(const f of ['nn_core.js','grand_diplomacy.js','ai_strategic_commander.js','extended_diplomacy.js','domestic_politics.js','ai_nations.js'])vm.runInContext(fs.readFileSync(G+f,'utf8'),ctx);
const warns=[];ctx.console={...console,warn:(...a)=>warns.push(a.join(' '))};
const S={me:'Новария',name:'Новария',year:1,month:0,money:500,gdp:300,power:30,stability:60,relations:[]};
for(let m=1;m<=36;m++)ctx.NationsAI.tick(S);
const W=S.aiWorld;
assert.equal(warns.length,0,'AI domestic hooks do not throw');
assert(W.nations.every(n=>n.domesticPolitics&&Array.isArray(n.domesticPolitics.history)),'внутренняя политика сохранена у всех ИИ-государств');
assert(W.nations.some(n=>n.domesticPolitics.lastEventMonth>=0||n.domesticPolitics.history.length>0),'ИИ-государства создают и разрешают внутренние события');
const copy=JSON.parse(JSON.stringify(S));
assert(copy.aiWorld.nations.every(n=>n.domesticPolitics&&Array.isArray(n.domesticPolitics.events)),'состояние внутренней политики ИИ сериализуется');
console.log('Stage 19 integration OK: '+W.nations.length+' AI countries, '+W.month+' months');
