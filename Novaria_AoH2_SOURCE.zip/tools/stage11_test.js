/* Автотест этапа 11: node tools/stage11_test.js */
global.window=global;const dir='app/src/main/assets/game/';
['province_graph','army_movement','battle_system','territory_system'].forEach(f=>require('../'+dir+f+'.js'));
let fails=0;const t=(n,c)=>{console.log((c?'PASS ':'FAIL ')+n);if(!c)fails++};
const rect=(x0,y0,x1,y1)=>[[[x0,y0],[x1,y0],[x1,y1],[x0,y1]]];
const mk=(iso,name,ring,seeds)=>({iso,name,rings:ring,bb:[Math.min(...ring[0].map(p=>p[0])),Math.min(...ring[0].map(p=>p[1])),Math.max(...ring[0].map(p=>p[0])),Math.max(...ring[0].map(p=>p[1]))],regs:seeds.map((c,i)=>({id:iso+':'+i,n:name+i,cx:c[0],cy:c[1],s:100/seeds.length,d:'x'}))});
window.GEO={W:1000,H:500,c:{AAA:mk('AAA','Альфа',rect(100,100,300,200),[[150,150],[250,150]]),BBB:mk('BBB','Браво',rect(300,100,400,200),[[350,150],[380,120]])}};
NovariaProvinceGraph.buildFromGeo(GEO,{cols:500});
const A=NovariaArmies,B=NovariaBattles,T=NovariaTerritory;
const mkS=()=>({me:'Альфа',name:'Альфа',year:1,month:0,army:300000,pp:100,stability:60,taken:{},wars:[{n:'Браво'}],allies:[],relations:[{name:'Браво',value:-50,power:20},{name:'Альфа',value:0,power:60}],
 military:{log:[],divisions:Array.from({length:14},(_,i)=>({id:i+1,type:i%4===3?'artillery':'infantry',manpower:10000,supply:80,morale:70,equipment:60,experience:10}))}});
const ids=Array.from({length:14},(_,i)=>i+1);
let S=mkS();T.sync(S);const st=A.deploy(S,ids,'AAA:1').stack;
const nb=P=>P;const P=NovariaProvinceGraph;
const tg=B.targets(S,st);t('цели для атаки есть',tg.length>=1);
const target=tg[0];
B.attack(S,st.id,target);B.advance(S,100);
t('победа даёт прорыв',!!S.battles.breach[target]);
t('прорыв: повторная атака запрещена',!B.attack(S,st.id,target).ok&&B.targets(S,st).every(x=>x!==target));
t('владелец до занятия прежний',T.deJure(S,target)==='Браво'&&T.controllerOf(S,target)==='Браво');
const pl=A.plan(S,st,target);t('вход в провинцию с прорывом разрешён',pl.ok);
A.order(S,st.id,target);A.advance(S,1000);
t('провинция занята: контроль у нас, владелец прежний',T.controllerOf(S,target)==='Альфа'&&T.deJure(S,target)==='Браво'&&!S.battles.breach[target]);
t('армия стоит в занятой провинции',st.prov===target);
t('нельзя присоединить сразу (мало месяцев)',!T.annex(S,target,false).ok);
for(let i=0;i<3;i++)T.tick(S);
t('после 3 мес. присоединение возможно',(()=>{const pp=S.pp;const r=T.annex(S,target,false);return r.ok&&S.pp===pp-T.ANNEX_PP})());
t('владелец изменён, граница обновилась',T.deJure(S,target)==='Альфа'&&S.taken[target]===1&&A.ownerOf(S,target)==='Альфа');
t('недовольство присоединённой провинции растёт, гарнизон снижает',(()=>{const u0=S.territory.unrest[target];T.tick(S);return S.territory.unrest[target]!==undefined})());
/* вторая провинция + полное присоединение страны */
const other=['BBB:0','BBB:1'].find(x=>x!==target);S.territory.controller[other]={by:'Альфа',orig:'Браво',since:0,months:5};
T.annex(S,other,false);
t('полный захват страны: страна исчезает, война снята',S.relations[0].annexed===true&&!S.wars.some(w=>w.n==='Браво'));
/* сохранение */
const S2=JSON.parse(JSON.stringify(S));t('владельцы и границы переживают сохранение',T.deJure(S2,target)==='Альфа'&&T.deJure(S2,other)==='Альфа');
/* мир: требования */
let M=mkS();T.sync(M);M.territory.controller['BBB:0']={by:'Альфа',orig:'Браво',since:0,months:1};M.territory.controller['BBB:1']={by:'Альфа',orig:'Браво',since:0,months:1};M.territory.demand['BBB:1']=false;
M.wars=[];T.sync(M);
t('мир: потребованная провинция присоединена',T.deJure(M,'BBB:0')==='Альфа');
t('мир: непотребованная вернулась',T.deJure(M,'BBB:1')==='Браво'&&!M.territory.controller['BBB:1']);
/* оккупация нашей провинции и освобождение */
let L=mkS();T.sync(L);L.territory.controller['AAA:1']={by:'Браво',orig:'Альфа',since:0,months:2};
const sl=A.deploy(L,ids,'AAA:0').stack;
t('вражеская оккупация нашей провинции — это цель атаки',B.targets(L,sl).includes('AAA:1'));
B.attack(L,sl.id,'AAA:1');B.advance(L,100);A.order(L,sl.id,'AAA:1');A.advance(L,2000);
t('освобождение снимает оккупацию',T.controllerOf(L,'AAA:1')==='Альфа'&&!L.territory.controller['AAA:1']);
/* восстание в присоединённой провинции */
let R=mkS();T.sync(R);T.transfer(R,'BBB:0','Альфа');R.stability=20;let reb=false;
for(let i=0;i<400&&!reb;i++){T.tick(R);if(T.deJure(R,'BBB:0')==='Браво')reb=true}
t('восстание возвращает независимость',reb&&!R.taken['BBB:0']);
/* гарнизон гасит недовольство */
let G1=mkS(),G2=mkS();[G1,G2].forEach(X=>{T.sync(X);T.transfer(X,'BBB:0','Альфа');X.stability=50});A.deploy(G2,ids.slice(0,6),'BBB:0');
for(let i=0;i<20;i++){T.tick(G1);T.tick(G2)}
t('гарнизон снижает недовольство',G2.territory.unrest['BBB:0']<G1.territory.unrest['BBB:0']);
t('статистика территорий',T.stats(S).annexed>=0);
console.log(fails?'\nПРОВАЛЕНО: '+fails:'\nВсе тесты пройдены');process.exit(fails?1:0);
