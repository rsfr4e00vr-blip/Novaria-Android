/* Пример точки входа дополнения Novaria.
 * Доступные игровые объекты зависят от версии игры.
 * Подключайся к событию novaria-addon-loaded и проверяй нужные API.
 */
(function () {
  'use strict';
  console.log('[Novaria Add-on] Пример дополнения загружен');
  window.addEventListener('novaria-addon-loaded', function (event) {
    if (event.detail && event.detail.id === 'example_national_events') {
      console.log('[Novaria Add-on] Инициализация:', event.detail.name);
    }
  });
})();
