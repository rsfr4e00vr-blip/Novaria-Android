/* Novaria Extended Diplomacy — этап 17.
 * Единый слой договоров поверх существующей дипломатии, экономики и войн:
 * ненападение, союзы, военный доступ, торговые соглашения, санкции, репарации,
 * контрибуции, передача территорий, разрыв отношений, коалиции и совместные операции.
 * Игрок и ИИ проходят через одни и те же функции проверки (propose / evaluate).
 * Состояние хранится в W.treaties (обычный JSON, переживает сохранение).
 */
(function(root){'use strict';
 const VERSION=1;
 const C=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0));
 const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
 const hash=s=>{let h=2166136261;for(const ch of String(s)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0};
 const roll=(W,k)=>(hash(k+':'+num(W.month))%1000)/1000;
 const key=(a,b)=>[a,b].sort().join('::');
 const esc=x=>String(x==null?'':x).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
 let curS=null,norm={W:null,T:null,len:-1,month:NaN};

 /* Семантика полей a/b:
    nap, alliance, trade — взаимные;  sanction — a вводит санкции против b;
    access — a получает право прохода через территорию b;  reparation — b платит a. */
 const TYPES={
  nap:{label:'Договор о ненападении',icon:'📜',term:60,mutual:true},
  alliance:{label:'Военный союз',icon:'🤝',term:0,mutual:true},
  access:{label:'Военный доступ',icon:'🚪',term:36,mutual:false},
  trade:{label:'Торговое соглашение',icon:'🚢',term:60,mutual:true},
  sanction:{label:'Экономические санкции',icon:'🚫',term:24,mutual:false},
  reparation:{label:'Репарации',icon:'💱',term:36,mutual:false}
 };
 const COOLDOWN={nap:6,alliance:12,access:6,trade:4,sanction:3,reparation:0};
 const ALLY_CAP=5,TRADE_CAP=8,BREAK_MONTHS=12,COALITION_MONTHS=36;

 /* ---------- состояние ---------- */
 function ensure(W){
  if(!W||!Array.isArray(W.nations))return null;
  let T=W.treaties;
  /* Быстрый путь: полная нормализация стран выполняется раз в месяц или при смене числа стран. */
  if(T&&T===norm.T&&W===norm.W&&W.nations.length===norm.len&&num(W.month)===norm.month)return T;
  if(!T||T.version!==VERSION||typeof T!=='object'){
   T=W.treaties={version:VERSION,month:-1,nextId:1,list:[],coalitions:[],breaks:{},aggression:{},rel:{},cool:{},transfers:[],ledger:[],joint:{},seenWars:{},history:[]};
  }
  ['list','coalitions','transfers','ledger','history'].forEach(k=>{if(!Array.isArray(T[k]))T[k]=[]});
  ['breaks','aggression','rel','cool','joint','seenWars'].forEach(k=>{if(!T[k]||typeof T[k]!=='object'||Array.isArray(T[k]))T[k]={}});
  T.nextId=Math.max(1,num(T.nextId,1));
  W.alliances=Array.isArray(W.alliances)?W.alliances:[];
  W.wars=Array.isArray(W.wars)?W.wars:[];
  W.events=Array.isArray(W.events)?W.events:[];
  W.nations.forEach(n=>{n.allies=Array.isArray(n.allies)?n.allies:[];n.tradePartners=Array.isArray(n.tradePartners)?n.tradePartners:[];n.rivals=n.rivals&&typeof n.rivals==='object'?n.rivals:{}});
  norm={W,T,len:W.nations.length,month:num(W.month)};
  return T;
 }
 function log(W,text,kind){
  const T=ensure(W);T.history.unshift({month:num(W.month),kind:kind||'info',text});T.history.length=Math.min(T.history.length,120);
  W.events.unshift(text);W.events.length=Math.min(W.events.length,80);
 }
 function proxy(S,name){
  return {name,human:true,isPlayer:true,annexed:false,iso:'',relations:0,claims:{},
   get power(){return num(S.power,num(S.milPower,20))},set power(v){},
   get gdp(){return Math.max(1,num(S.gdp,100))},set gdp(v){},
   get treasury(){return num(S.money)},set treasury(v){S.money=Math.max(0,num(v))},
   get stability(){return num(S.stability,50)},set stability(v){},
   get debt(){return num(S.debt)},set debt(v){},
   get exhaustion(){return num(S.exhaustion)},set exhaustion(v){},
   get ideology(){return S.ideology||'прагматизм'},set ideology(v){},
   get war(){return (S.wars||[]).some(w=>!w.won)?'player':null},set war(v){},
   allies:S.allies||(S.allies=[]),tradePartners:S.tradePartners||(S.tradePartners=[]),rivals:S.rivals||(S.rivals={})};
 }
 function party(W,name){
  const n=(W.nations||[]).find(x=>x.name===name);if(n)return n;
  if(name&&W.player===name&&curS)return proxy(curS,name);
  return null;
 }
 const alive=p=>!!p&&!p.annexed;
 const isActive=(t,month)=>!t.expires||t.expires>month;

 /* ---------- отношения ---------- */
 function relGet(W,a,b){
  const T=ensure(W),k=key(a,b);
  if(T.rel[k]==null){
   const A=party(W,a),B=party(W,b);let base=0;
   if(A&&B){
    base=(num(A.relations)+num(B.relations))/2-num(A.rivals&&A.rivals[b])-num(B.rivals&&B.rivals[a]);
    if((A.isPlayer||B.isPlayer)&&curS){const o=A.isPlayer?B:A,rr=(curS.relations||[]).find(r=>r&&r.name===o.name);if(rr)base=num(rr.value)}
   }
   T.rel[k]=C(base,-100,100);
  }
  return T.rel[k];
 }
 function relAdd(W,a,b,d){
  const T=ensure(W),k=key(a,b);T.rel[k]=C(relGet(W,a,b)+d,-100,100);
  if(curS&&W.player&&(a===W.player||b===W.player)){const o=a===W.player?b:a,rr=(curS.relations||[]).find(r=>r&&r.name===o);if(rr)rr.value=C(num(rr.value)+d,-100,100)}
  return T.rel[k];
 }
 const atWarWith=(W,a,b)=>(W.wars||[]).some(w=>(w.a===a&&w.b===b)||(w.a===b&&w.b===a));
 const inAnyWar=(W,n)=>(W.wars||[]).some(w=>w.a===n||w.b===n||(w.joinedA||[]).includes(n)||(w.joinedB||[]).includes(n));
 function brokenOff(W,a,b){const e=ensure(W).breaks[key(a,b)];return !!e&&e>num(W.month)}

 /* ---------- поиск договоров ---------- */
 function find(W,type,a,b){
  const T=ensure(W),m=TYPES[type]&&TYPES[type].mutual,month=num(W.month);
  return T.list.find(t=>t.type===type&&isActive(t,month)&&(m?((t.a===a&&t.b===b)||(t.a===b&&t.b===a)):(t.a===a&&t.b===b)))||null;
 }
 const hasAlliance=(W,a,b)=>!!find(W,'alliance',a,b);
 function hasAccess(W,holder,grantor){return hasAlliance(W,holder,grantor)||!!find(W,'access',holder,grantor)}
 function hasPact(W,a,b){return !!find(W,'nap',a,b)||hasAlliance(W,a,b)}
 function countFor(W,name){const month=num(W.month);return ensure(W).list.filter(t=>isActive(t,month)&&(t.a===name||t.b===name)&&(t.type==='nap'||t.type==='access'||t.type==='sanction')).length}
 function alliesOf(W,name){const p=party(W,name);return p?p.allies.length:0}

 /* ---------- оценка предложения (общая для игрока и ИИ) ---------- */
 const deny=(reason,score)=>({ok:true,accept:false,reason,score:score==null?0:score});
 function evaluate(W,type,from,to,terms){
  const T=ensure(W);if(!T)return{ok:false,accept:false,reason:'Мир не готов'};
  if(!TYPES[type])return{ok:false,accept:false,reason:'Неизвестный тип договора'};
  const A=party(W,from),B=party(W,to);
  if(!alive(A)||!alive(B)||from===to)return{ok:false,accept:false,reason:'Сторона недоступна'};
  if(atWarWith(W,from,to))return deny('Стороны находятся в состоянии войны');
  if(brokenOff(W,from,to))return deny('Дипломатические отношения разорваны');
  if(find(W,type,from,to))return deny('Такой договор уже действует');
  const cd=T.cool[type+':'+from+':'+to];
  if(cd&&cd>num(W.month))return deny(`Повторное предложение возможно через ${cd-num(W.month)} мес.`);
  const r=relGet(W,from,to),ratio=num(A.power,1)/Math.max(1,num(B.power,1));
  const claim=!!(B.claims&&B.claims[from]&&num(B.claims[from].expires)>num(W.month));
  const crisis=T&&(W.diplomacy&&W.diplomacy.crises||[]).some(c=>c.expires>num(W.month)&&((c.a===from&&c.b===to)||(c.a===to&&c.b===from)));
  const agg=num(T.aggression[from]);
  if(type==='nap'){
   if(r<-35)return deny('Слишком враждебные отношения для пакта',r);
   const s=50+r*.5+(ratio>2?14:ratio>1.2?8:0)-(claim?25:0)-(crisis?15:0)-agg*.3;
   return{ok:true,accept:s>=55,score:s,reason:s>=55?'Пакт выгоден обеим сторонам':'Предложение отклонено: недостаточно доверия'};
  }
  if(type==='alliance'){
   if(r<25)return deny('Для союза нужны отношения не ниже 25',r);
   if(A.allies.length>=ALLY_CAP||B.allies.length>=ALLY_CAP)return deny('Достигнут предел числа союзников');
   const rivalsShared=(W.nations||[]).some(x=>alive(x)&&x.name!==from&&x.name!==to&&relGet(W,from,x.name)<-20&&relGet(W,to,x.name)<-20);
   const sameIdeo=A.ideology&&B.ideology&&A.ideology===B.ideology;
   const s=r*.7+10+(rivalsShared?10:0)+(sameIdeo?8:0)+((ratio<.4||ratio>2.5)?-15:0)-(agg>40?20:0)-(claim?20:0);
   return{ok:true,accept:s>=45,score:s,reason:s>=45?'Союз принят':'Союз отклонён: интересы сторон не совпадают'};
  }
  if(type==='access'){
   if(r<20&&!hasAlliance(W,from,to))return deny('Для военного доступа нужны отношения не ниже 20',r);
   const s=r*.8+(hasAlliance(W,from,to)?30:0)-(claim?30:0)-(crisis?20:0)-agg*.2;
   return{ok:true,accept:s>=16,score:s,reason:s>=16?'Проход разрешён':'Страна не пускает иностранные войска'};
  }
  if(type==='trade'){
   if(r<-10)return deny('Для торговли нужны отношения не ниже −10',r);
   const sanc=T.list.some(t=>t.type==='sanction'&&isActive(t,num(W.month))&&((t.a===from&&t.b===to)||(t.a===to&&t.b===from)));
   if(sanc)return deny('Действуют санкции');
   if(A.tradePartners.length>=TRADE_CAP||B.tradePartners.length>=TRADE_CAP)return deny('Достигнут предел торговых партнёров');
   const s=25+r*.5;
   return{ok:true,accept:s>=20,score:s,reason:s>=20?'Торговое соглашение подписано':'Торговые условия не устроили страну'};
  }
  if(type==='sanction'){
   if(hasAlliance(W,from,to))return deny('Нельзя вводить санкции против союзника');
   return{ok:true,accept:true,score:100,reason:'Санкции вводятся односторонне'};
  }
  if(type==='reparation')return deny('Репарации устанавливаются только мирным договором');
  return deny('Неизвестный тип');
 }

 /* ---------- создание, действие и отмена договоров ---------- */
 function sanctionTotals(W){
  const T=ensure(W),month=num(W.month),cnt={};
  T.list.forEach(t=>{if(t.type==='sanction'&&isActive(t,month))cnt[t.b]=(cnt[t.b]||0)+1});
  (W.nations||[]).forEach(n=>{
   n.sanctions=Math.min(4,cnt[n.name]||0);
   n.hostilePartners=(n.tradePartners||[]).filter(p=>relGet(W,n.name,p)<-20).length;
  });
 }
 function link(arr,name){if(!arr.includes(name))arr.push(name)}
 function unlink(arr,name){const i=arr.indexOf(name);if(i>=0)arr.splice(i,1)}
 function makeTreaty(W,type,a,b,terms,opts){
  const T=ensure(W),def=TYPES[type],A=party(W,a),B=party(W,b);
  if(!def||!A||!B)return null;
  const month=num(W.month),months=num(terms&&terms.months,def.term);
  const adopted=!!(opts&&opts.adopted);
  const t={id:'T'+(T.nextId++),type,a,b,created:month,expires:(months>0&&!adopted)?month+months:0,terms:Object.assign({},terms||{}),adopted};
  T.list.push(t);
  if(type==='alliance'){link(A.allies,b);link(B.allies,a);if(!W.alliances.some(x=>(x.a===a&&x.b===b)||(x.a===b&&x.b===a)))W.alliances.push({a,b,formed:month});if(!t.adopted)relAdd(W,a,b,15)}
  else if(type==='trade'){link(A.tradePartners,b);link(B.tradePartners,a);if(!t.adopted)relAdd(W,a,b,6)}
  else if(type==='nap'){if(!t.adopted)relAdd(W,a,b,8);mirrorPact(W,a,b,months)}
  else if(type==='access'){relAdd(W,a,b,4)}
  else if(type==='sanction'){
   relAdd(W,a,b,-18);
   dropTrade(W,a,b);
   B.economicGrievances=B.economicGrievances||{};B.economicGrievances[a]={severity:62,expires:month+18,detail:'Экономические санкции'};
   mirrorSanction(W,a,b);
  }else if(type==='reparation'){t.arrears=0;t.paid=0}
  sanctionTotals(W);
  return t;
 }
 function mirrorPact(W,a,b,months){
  if(!curS||!W.player||(a!==W.player&&b!==W.player))return;
  const o=a===W.player?b:a;curS.pacts=curS.pacts||{};curS.pacts[o]=((curS.year||0)*12+(curS.month||0))+(months||24);
 }
 function mirrorSanction(W,a,b){
  if(!curS||!W.player||a!==W.player)return;
  curS.sanc=curS.sanc||{};if(!curS.sanc[b])curS.sanc[b]={why:'Решение дипломатии',left:24,k:.0006};
 }
 function dropTrade(W,a,b){
  const T=ensure(W),A=party(W,a),B=party(W,b);
  if(A)unlink(A.tradePartners,b);if(B)unlink(B.tradePartners,a);
  T.list=T.list.filter(t=>!(t.type==='trade'&&((t.a===a&&t.b===b)||(t.a===b&&t.b===a))));
 }
 function dissolveEffects(W,t){
  const A=party(W,t.a),B=party(W,t.b);
  if(t.type==='alliance'){
   if(A)unlink(A.allies,t.b);if(B)unlink(B.allies,t.a);
   W.alliances=W.alliances.filter(x=>!((x.a===t.a&&x.b===t.b)||(x.a===t.b&&x.b===t.a)));
  }else if(t.type==='trade'){if(A)unlink(A.tradePartners,t.b);if(B)unlink(B.tradePartners,t.a)}
  else if(t.type==='nap'&&curS&&curS.pacts&&W.player&&(t.a===W.player||t.b===W.player)){delete curS.pacts[t.a===W.player?t.b:t.a]}
  else if(t.type==='sanction'&&curS&&curS.sanc&&W.player&&t.a===W.player){delete curS.sanc[t.b]}
 }
 function cancel(W,id,by,reason,opts){
  const T=ensure(W),i=T.list.findIndex(t=>t.id===id);if(i<0)return{ok:false,reason:'Договор не найден'};
  const t=T.list[i];T.list.splice(i,1);dissolveEffects(W,t);
  const violation=!!(opts&&opts.violation)&&(t.type==='nap'||t.type==='alliance');
  if(violation&&by){
   const other=by===t.a?t.b:t.a;relAdd(W,by,other,-25);T.aggression[by]=num(T.aggression[by])+(t.type==='nap'?20:10);
   log(W,`📜 ${by} нарушила договор «${TYPES[t.type].label}» с ${other}.`,'violation');
  }else log(W,`📜 Договор «${TYPES[t.type].label}» (${t.a} — ${t.b}) расторгнут${reason?': '+reason:''}.`,'cancel');
  sanctionTotals(W);
  return{ok:true,violation};
 }

 /* ---------- главный вход: предложить договор ---------- */
 function propose(W,type,from,to,terms,opts){
  const T=ensure(W);if(!T)return{ok:false,accepted:false,reason:'Мир не готов'};
  const ev=evaluate(W,type,from,to,terms);
  if(!ev.ok)return{ok:false,accepted:false,reason:ev.reason};
  const A=party(W,from);
  if(type==='sanction'&&A&&num(A.treasury)<num(A.gdp)*.002)return{ok:true,accepted:false,reason:'Недостаточно средств для санкционной кампании',evaluation:ev};
  if(!ev.accept){
   T.cool[type+':'+from+':'+to]=num(W.month)+(COOLDOWN[type]||0);
   relAdd(W,from,to,-1);
   return{ok:true,accepted:false,reason:ev.reason,evaluation:ev};
  }
  const t=makeTreaty(W,type,from,to,terms,opts);
  T.cool[type+':'+from+':'+to]=num(W.month)+(COOLDOWN[type]||0);
  log(W,`${TYPES[type].icon} ${TYPES[type].label}: ${from} — ${to}.`,type);
  return{ok:true,accepted:true,reason:ev.reason,treaty:t,evaluation:ev};
 }

 /* ---------- разрыв и восстановление отношений ---------- */
 function breakRelations(W,a,b,reason){
  const T=ensure(W),A=party(W,a),B=party(W,b);
  if(!alive(A)||!alive(B)||a===b)return{ok:false,reason:'Сторона недоступна'};
  if(brokenOff(W,a,b))return{ok:false,reason:'Отношения уже разорваны'};
  const month=num(W.month);
  T.list.filter(t=>isActive(t,month)&&((t.a===a&&t.b===b)||(t.a===b&&t.b===a))&&t.type!=='sanction'&&t.type!=='reparation').forEach(t=>{
   T.list=T.list.filter(x=>x!==t);dissolveEffects(W,t);
  });
  T.breaks[key(a,b)]=month+BREAK_MONTHS;
  relAdd(W,a,b,-30);
  A.rivals[b]=Math.max(num(A.rivals[b]),35);B.rivals[a]=Math.max(num(B.rivals[a]),30);
  log(W,`✂️ ${a} разорвала дипломатические отношения с ${b}${reason?' ('+reason+')':''}.`,'break');
  sanctionTotals(W);
  return{ok:true,until:month+BREAK_MONTHS};
 }
 function restoreRelations(W,a,b){
  const T=ensure(W),k=key(a,b);
  if(!brokenOff(W,a,b))return{ok:false,reason:'Отношения не разорваны'};
  const left=T.breaks[k]-num(W.month);
  if(left>BREAK_MONTHS-3)return{ok:false,reason:`Восстановление возможно не ранее чем через ${left-(BREAK_MONTHS-3)} мес.`};
  delete T.breaks[k];relAdd(W,a,b,8);
  log(W,`🕊 ${a} и ${b} восстановили дипломатические отношения.`,'restore');
  return{ok:true};
 }

 /* ---------- война: проверки и последствия ---------- */
 function canDeclareWar(W,a,b,opts){
  const T=ensure(W);if(!T)return{ok:true};
  const A=party(W,a),B=party(W,b);
  if(!alive(A)||!alive(B)||a===b)return{ok:false,reason:'Сторона недоступна'};
  if(atWarWith(W,a,b))return{ok:false,reason:'Война уже идёт'};
  if(hasAlliance(W,a,b))return{ok:false,reason:'Союзнику нельзя объявить войну без расторжения союза'};
  if(find(W,'nap',a,b)&&!(opts&&opts.breakPact))return{ok:false,reason:'Действует договор о ненападении'};
  return{ok:true,violation:!!find(W,'nap',a,b)};
 }
 function onWarDeclared(W,a,b,war){
  const T=ensure(W);if(!T)return;
  const id=war&&war.id?war.id:`${num(W.month)}:${a}:${b}`;
  if(T.seenWars[id])return;T.seenWars[id]=num(W.month);
  const nap=find(W,'nap',a,b);
  if(nap)cancel(W,nap.id,a,'нарушение при объявлении войны',{violation:true});
  const month=num(W.month);
  T.list.filter(t=>isActive(t,month)&&((t.a===a&&t.b===b)||(t.a===b&&t.b===a))&&(t.type==='trade'||t.type==='access'||t.type==='alliance')).forEach(t=>{
   T.list=T.list.filter(x=>x!==t);dissolveEffects(W,t);
  });
  relAdd(W,a,b,-40);
  T.aggression[a]=num(T.aggression[a])+18;
  sanctionTotals(W);
 }

 /* ---------- мир: репарации, контрибуции, территория ---------- */
 function transferFunds(W,from,to,amount,note){
  const P=party(W,from),Q=party(W,to);if(!P||!Q)return 0;
  const pay=Math.max(0,Math.min(num(amount),num(P.treasury)*.5));
  if(pay<=0)return 0;P.treasury=num(P.treasury)-pay;Q.treasury=num(Q.treasury)+pay;
  ensure(W).ledger.unshift({month:num(W.month),from,to,amount:Math.round(pay*100)/100,note:note||''});ensure(W).ledger.length=Math.min(ensure(W).ledger.length,200);
  return pay;
 }
 function transferTerritory(W,from,to,region,opts){
  const T=ensure(W);if(!region||!party(W,from)||!party(W,to))return{ok:false,reason:'Неверные параметры передачи'};
  opts=opts||{};
  if(T.transfers.some(x=>x.region===region&&x.from===from&&x.to===to&&x.war===opts.war&&x.month===num(W.month)))return{ok:false,reason:'Передача уже записана'};
  let applied=false;
  if(opts.provinceId!=null&&curS&&root.NovariaTerritory&&typeof root.NovariaTerritory.transfer==='function'){
   try{root.NovariaTerritory.transfer(curS,opts.provinceId,to);applied=true}catch(e){}
  }
  const rec={month:num(W.month),from,to,region,war:opts.war||null,provinceId:opts.provinceId==null?null:opts.provinceId,applied};
  T.transfers.unshift(rec);T.transfers.length=Math.min(T.transfers.length,120);
  const F=party(W,from),G=party(W,to);
  if(F&&!F.isPlayer){F.lostRegions=Array.isArray(F.lostRegions)?F.lostRegions:[];if(!F.lostRegions.some(x=>x.region===region&&x.to===to))F.lostRegions.push({region,to,month:num(W.month)})}
  if(G&&!G.isPlayer){G.gainedRegions=Array.isArray(G.gainedRegions)?G.gainedRegions:[];if(!G.gainedRegions.some(x=>x.region===region&&x.from===from))G.gainedRegions.push({region,from,month:num(W.month)})}
  T.aggression[to]=num(T.aggression[to])+12;
  relAdd(W,from,to,-15);
  log(W,`🗺 Передача территории: «${region}» от ${from} к ${to}.`,'territory');
  return{ok:true,record:rec};
 }
 /* Вызывается после существующего расчёта мира. d0 — казна победителя/проигравшего до расчёта. */
 function onPeace(W,w,win,lose,margin,d0){
  const T=ensure(W);if(!T||!win||!lose)return null;
  margin=num(margin);const out={contribution:0,reparation:null,territory:null,nap:null};
  delete T.joint[w&&w.id];
  if(margin>18){
   if(d0&&num(win.treasury)>num(d0.w)){out.contribution=Math.round((num(win.treasury)-num(d0.w))*100)/100;
    T.ledger.unshift({month:num(W.month),from:lose.name,to:win.name,amount:out.contribution,note:'контрибуция по мирному договору'})}
   const amount=Math.max(.01,num(lose.gdp)*.0006*(1+margin/100));
   const months=C(Math.round(12+margin/3),12,48);
   out.reparation=makeTreaty(W,'reparation',win.name,lose.name,{amount,months,war:w&&w.id},{});
   relAdd(W,win.name,lose.name,-10);
   if(w&&w.goal==='territory'&&w.claimRegion)out.territory=transferTerritory(W,lose.name,win.name,w.claimRegion,{war:w.id});
   if(margin>30)T.aggression[win.name]=num(T.aggression[win.name])+15;
   log(W,`💱 Репарации: ${lose.name} выплачивает ${win.name} по ${amount.toFixed(1)} в месяц на ${months} мес.`,'reparation');
  }else{
   out.nap=makeTreaty(W,'nap',win.name,lose.name,{months:36,war:w&&w.id},{});
   log(W,`📜 Мир без решающей победы: ${win.name} и ${lose.name} заключили договор о ненападении на 3 года.`,'nap');
  }
  if(lose.annexed)T.aggression[win.name]=num(T.aggression[win.name])+25;
  return out;
 }

 /* ---------- ежемесячная обработка ---------- */
 function adopt(W){
  const T=ensure(W);
  (W.alliances||[]).forEach(x=>{if(x&&x.a&&x.b&&!find(W,'alliance',x.a,x.b)&&alive(party(W,x.a))&&alive(party(W,x.b))){
   const t=makeTreaty(W,'alliance',x.a,x.b,{},{adopted:true});if(t)t.created=num(x.formed,t.created)}});
  (W.nations||[]).forEach(n=>{
   if(n.annexed)return;
   n.allies.slice().forEach(nm=>{const o=party(W,nm);if(!alive(o)){unlink(n.allies,nm);return}
    if(!find(W,'alliance',n.name,nm))makeTreaty(W,'alliance',n.name,nm,{},{adopted:true})});
   n.tradePartners.slice().forEach(nm=>{const o=party(W,nm);if(!alive(o)){unlink(n.tradePartners,nm);return}
    if(!find(W,'trade',n.name,nm))makeTreaty(W,'trade',n.name,nm,{},{adopted:true})});
  });
 }
 function expire(W){
  const T=ensure(W),month=num(W.month);
  T.list.filter(t=>!isActive(t,month)).forEach(t=>{dissolveEffects(W,t);
   if(t.type!=='sanction'||roll(W,t.id)<.5)log(W,`⌛ Срок договора «${TYPES[t.type].label}» (${t.a} — ${t.b}) истёк.`,'expire')});
  T.list=T.list.filter(t=>isActive(t,month)&&alive(party(W,t.a))&&alive(party(W,t.b)));
  Object.keys(T.breaks).forEach(k=>{if(T.breaks[k]<=month)delete T.breaks[k]});
  Object.keys(T.cool).forEach(k=>{if(T.cool[k]<=month)delete T.cool[k]});
 }
 function payments(W){
  const T=ensure(W),month=num(W.month);
  T.list.filter(t=>t.type==='reparation'&&isActive(t,month)).forEach(t=>{
   const need=num(t.terms.amount),paid=transferFunds(W,t.b,t.a,need,'репарации');
   t.paid=num(t.paid)+paid;
   if(paid<need*.5){
    t.arrears=num(t.arrears)+1;relAdd(W,t.a,t.b,-2);
    if(t.arrears===3){const A=party(W,t.a);if(A){A.economicGrievances=A.economicGrievances||{};A.economicGrievances[t.b]={severity:58,expires:month+18,detail:'Задержка выплаты репараций'}}
     log(W,`💱 ${t.b} задерживает выплату репараций ${t.a}.`,'arrears')}
   }else t.arrears=Math.max(0,num(t.arrears)-1);
  });
 }
 function drift(W){
  const T=ensure(W),month=num(W.month),pairs={};
  const add=(a,b,d)=>{const k=key(a,b);pairs[k]=(pairs[k]||0)+d};
  T.list.forEach(t=>{if(!isActive(t,month))return;
   if(t.type==='alliance')add(t.a,t.b,.5);else if(t.type==='trade')add(t.a,t.b,.25);else if(t.type==='nap')add(t.a,t.b,.15);
   else if(t.type==='access')add(t.a,t.b,.1);else if(t.type==='sanction')add(t.a,t.b,-.8)});
  (W.wars||[]).forEach(w=>add(w.a,w.b,-1.5));
  T.coalitions.forEach(c=>c.members.forEach(m=>add(m,c.target,-.6)));
  Object.keys(T.rel).forEach(k=>{
   const d=pairs[k]||0,cur=T.rel[k],eased=d===0?(cur>0?-.1:cur<0?.1:0):0;
   if(d||eased)T.rel[k]=C(cur+d+eased,-100,100);
  });
  Object.keys(pairs).forEach(k=>{if(T.rel[k]==null){const [a,b]=k.split('::');relGet(W,a,b);T.rel[k]=C(T.rel[k]+pairs[k],-100,100)}});
 }
 function observeWars(W){
  const T=ensure(W);
  (W.wars||[]).forEach(w=>{if(w&&w.id&&!T.seenWars[w.id])onWarDeclared(W,w.a,w.b,w)});
  const ids=new Set((W.wars||[]).map(w=>w.id));
  Object.keys(T.seenWars).forEach(id=>{if(!ids.has(id)&&num(W.month)-T.seenWars[id]>60)delete T.seenWars[id]});
  Object.keys(T.aggression).forEach(k=>{T.aggression[k]=Math.max(0,T.aggression[k]-1.5);if(T.aggression[k]<.1)delete T.aggression[k]});
 }

 /* ---------- коалиции ---------- */
 function formCoalitions(W,A){
  const T=ensure(W),month=num(W.month);
  T.coalitions=T.coalitions.filter(c=>{
   const tgt=party(W,c.target);
   const keep=alive(tgt)&&c.expires>month&&num(T.aggression[c.target])>=12;
   if(!keep)log(W,`🛡 Коалиция против ${c.target} распущена.`,'coalition');
   c.members=c.members.filter(m=>alive(party(W,m))&&!hasAlliance(W,m,c.target));
   return keep&&c.members.length>=2;
  });
  Object.keys(T.aggression).forEach(name=>{
   if(num(T.aggression[name])<40||T.coalitions.some(c=>c.target===name))return;
   const tgt=party(W,name);if(!alive(tgt))return;
   const members=(A||W.nations).filter(x=>alive(x)&&x.name!==name&&!hasPact(W,x.name,name)&&relGet(W,x.name,name)<=15)
    .sort((p,q)=>(relGet(W,p.name,name)-relGet(W,q.name,name))||(p.name<q.name?-1:1)).slice(0,6).map(x=>x.name);
   if(members.length<2)return;
   const c={id:'K'+(T.nextId++),target:name,members,created:month,expires:month+COALITION_MONTHS,reason:`Агрессивная политика ${name}`};
   T.coalitions.push(c);
   members.slice(0,3).forEach(m=>{if(!find(W,'sanction',m,name)&&!hasAlliance(W,m,name))makeTreaty(W,'sanction',m,name,{coalition:c.id,months:24},{})});
   log(W,`🛡 Против ${name} сформирована коалиция: ${members.join(', ')}.`,'coalition');
  });
 }
 function coalitionWar(W){
  const T=ensure(W);
  T.coalitions.forEach(c=>{
   const w=(W.wars||[]).find(x=>x.a===c.target||x.b===c.target);if(!w)return;
   const k=w.a===c.target?'joinedB':'joinedA';w[k]=Array.isArray(w[k])?w[k]:[];
   c.members.forEach(nm=>{
    if(nm===w.a||nm===w.b||w[k].includes(nm))return;
    const x=party(W,nm);if(!alive(x)||x.isPlayer||x.war)return;
    if(roll(W,nm+':coal:'+w.id)<.2){w[k].push(nm);x.war=w.id;log(W,`🛡 ${nm} вступила в войну против ${c.target} в составе коалиции.`,'coalition')}
   });
  });
 }

 /* ---------- совместные операции ---------- */
 function jointOps(W){
  const T=ensure(W);
  (W.wars||[]).forEach(w=>{
   const J=T.joint[w.id]||(T.joint[w.id]={a:[],b:[],months:0,bonus:0,lastMonth:-1});
   if(J.lastMonth===num(W.month))return;J.lastMonth=num(W.month);J.months++;
   let delta=0;
   [['a',w.a,w.joinedA||[],1],['b',w.b,w.joinedB||[],-1]].forEach(([side,leader,joined,sign])=>{
    const L=party(W,leader);
    const parts=joined.filter(nm=>{const x=party(W,nm);return alive(x)&&hasAccess(W,leader,nm)});
    J[side]=parts;
    parts.forEach(nm=>{
     const x=party(W,nm),cost=num(x.gdp)*.0004;
     if(num(x.treasury)>=cost*3){x.treasury=num(x.treasury)-cost;delta+=sign*Math.min(.4,.1+num(x.power)/Math.max(1,num(L&&L.power,1))*.3)}
    });
   });
   delta=C(delta,-1.2,1.2);
   if(delta){w.score=C(num(w.score)+delta,-100,100);w.front=C(50+w.score/2,0,100);J.bonus=Math.round((num(J.bonus)+delta)*100)/100}
  });
  Object.keys(T.joint).forEach(id=>{if(!(W.wars||[]).some(w=>w.id===id))delete T.joint[id]});
 }

 /* ---------- ИИ использует те же правила, что и игрок ---------- */
 function aiDiplomacy(W,A){
  const T=ensure(W),month=num(W.month);
  const list=(A||W.nations).filter(n=>alive(n)&&!n.human).slice().sort((p,q)=>p.name<q.name?-1:1);
  let actions=0;
  for(const n of list){
   if(actions>=24)break;
   if(roll(W,n.name+':dip')>.06||countFor(W,n.name)>=8)continue;
   const war=inAnyWar(W,n.name),cand=[];
   for(const m of list){
    if(m===n||atWarWith(W,n.name,m.name)||brokenOff(W,n.name,m.name))continue;
    const r=relGet(W,n.name,m.name),ratio=num(m.power,1)/Math.max(1,num(n.power,1));
    if(!war&&ratio>1.15&&r>=-30&&!hasPact(W,n.name,m.name))cand.push({type:'nap',to:m.name,pr:30+Math.min(10,ratio*4)});
    if(num(T.aggression[m.name])>=30&&r<-15&&!find(W,'sanction',n.name,m.name)&&!hasAlliance(W,n.name,m.name))cand.push({type:'sanction',to:m.name,pr:40+num(T.aggression[m.name])/2});
    if(!war&&r>=30&&!hasAlliance(W,n.name,m.name)&&n.allies.length<ALLY_CAP)cand.push({type:'alliance',to:m.name,pr:25+r/5});
    if(r>=5&&!find(W,'trade',n.name,m.name)&&n.tradePartners.length<TRADE_CAP)cand.push({type:'trade',to:m.name,pr:15+r/5});
    if(r>=40&&!hasAlliance(W,n.name,m.name)&&!find(W,'access',n.name,m.name))cand.push({type:'access',to:m.name,pr:10+r/10});
   }
   if(!cand.length)continue;
   cand.sort((p,q)=>(q.pr-p.pr)||(p.to<q.to?-1:1));
   const pick=cand[0],res=propose(W,pick.type,n.name,pick.to,{},{});
   actions++;
   if(res.accepted)n.intent=`${TYPES[pick.type].label}: ${pick.to}`;
  }
  return actions;
 }

 /* ---------- такт ---------- */
 function tick(W,A,S){
  if(S)curS=S;
  const T=ensure(W);if(!T)return null;
  const month=num(W.month);
  if(T.month===month)return T;
  T.month=month;
  adopt(W);expire(W);observeWars(W);payments(W);drift(W);
  formCoalitions(W,A);coalitionWar(W);jointOps(W);
  aiDiplomacy(W,A);
  sanctionTotals(W);
  return T;
 }

 /* ---------- интерфейс игрока ---------- */
 function playerAction(S,type,target,terms){
  curS=S;
  const W=S&&S.aiWorld;if(!W)return{ok:false,reason:'Мир ещё не создан'};
  const T=ensure(W);if(!T)return{ok:false,reason:'Мир не готов'};
  const me=W.player||S.me||S.name;W.player=me;
  if(!target||!party(W,target))return{ok:false,reason:'Выберите государство'};
  if(type==='break')return breakRelations(W,me,target,'решение игрока');
  if(type==='restore')return restoreRelations(W,me,target);
  if(type==='cancel_alliance'){const t=find(W,'alliance',me,target);return t?cancel(W,t.id,me,'решение игрока',{violation:false}):{ok:false,reason:'Союза нет'}}
  if(type==='cancel_nap'){const t=find(W,'nap',me,target);return t?cancel(W,t.id,me,'решение игрока',{violation:true}):{ok:false,reason:'Пакта нет'}}
  if(type==='join_coalition'){const c=T.coalitions.find(x=>x.target===target);if(!c)return{ok:false,reason:'Против этой страны нет коалиции'};if(!c.members.includes(me))c.members.push(me);return{ok:true,reason:'Вы присоединились к коалиции'}}
  return propose(W,type,me,target,terms||{},{});
 }
 function panel(W,S){
  const T=ensure(W);if(!T)return '';
  curS=S||curS;
  const month=num(W.month),act=T.list.filter(t=>isActive(t,month));
  const cnt=k=>act.filter(t=>t.type===k).length;
  const me=W.player,mine=act.filter(t=>t.a===me||t.b===me).slice(0,10);
  const names=(W.nations||[]).filter(n=>alive(n)).map(n=>n.name).sort((a,b)=>a.localeCompare(b,'ru'));
  const btn=(t,l)=>`<button onclick="NovariaDiplomacyUI.act('${t}')">${l}</button>`;
  const row=t=>`<div class="mini"><b>${TYPES[t.type].icon} ${esc(TYPES[t.type].label)}</b><br>${esc(t.a)} — ${esc(t.b)}<br><small class="muted">${t.expires?`до месяца ${t.expires}`:'бессрочно'}${t.type==='reparation'?` · ${num(t.terms.amount).toFixed(1)}/мес.`:''}</small></div>`;
  const co=T.coalitions.slice(0,6).map(c=>`<div class="mini"><b>🛡 Против ${esc(c.target)}</b><br><small class="muted">${c.members.map(esc).join(', ')} · до месяца ${c.expires}</small></div>`).join('');
  const hist=T.history.slice(0,8).map(h=>`<div>${esc(h.text)}</div>`).join('');
  return `<div class="mini" style="margin:10px 0"><b>📜 Расширенная дипломатия · этап 17</b><small class="muted">Договоров: ${act.length} (ненападение ${cnt('nap')}, союзов ${cnt('alliance')}, доступ ${cnt('access')}, торговля ${cnt('trade')}, санкции ${cnt('sanction')}, репарации ${cnt('reparation')}) · коалиций: ${T.coalitions.length}</small>`+
   (me?`<div class="row" style="margin-top:8px"><select id="ndTarget">${names.filter(n=>n!==me).map(n=>`<option>${esc(n)}</option>`).join('')}</select></div><div class="row">${btn('nap','📜 Ненападение')}${btn('alliance','🤝 Союз')}${btn('access','🚪 Доступ')}${btn('trade','🚢 Торговля')}${btn('sanction','🚫 Санкции')}${btn('break','✂️ Разрыв')}${btn('restore','🕊 Восстановить')}${btn('join_coalition','🛡 В коалицию')}</div>`:'')+
   `<h3>Ваши договоры</h3><div class="cards">${mine.map(row).join('')||'<p class="muted">Договоров нет.</p>'}</div><h3>Коалиции</h3><div class="cards">${co||'<p class="muted">Коалиций нет.</p>'}</div><h3>Журнал</h3><div class="feed">${hist||'<span class="muted">Пока тихо.</span>'}</div></div>`;
 }
 function inspect(W,name){
  const T=ensure(W);if(!T)return null;const month=num(W.month);
  return{name,treaties:T.list.filter(t=>isActive(t,month)&&(t.a===name||t.b===name)),aggression:num(T.aggression[name]),coalitions:T.coalitions.filter(c=>c.target===name||c.members.includes(name))};
 }

 const UI={act(type){
  const NGx=root.NG,sel=root.document&&root.document.getElementById('ndTarget'),S=NGx&&NGx.S;
  if(!S||!sel)return;
  const r=playerAction(S,type,sel.value,{});
  if(NGx.toast)NGx.toast(r.accepted===false?('✖ '+r.reason):(r.ok===false?('✖ '+(r.reason||'Невозможно')):('✔ '+(r.reason||'Выполнено'))));
  try{NGx.save&&NGx.save();NGx.render&&NGx.render()}catch(e){}
 }};

 root.NovariaDiplomacy={VERSION,TYPES,ensure,tick,evaluate,propose,cancel,find,hasAccess,hasAlliance,hasPact,relGet,relAdd,
  breakRelations,restoreRelations,canDeclareWar,onWarDeclared,onPeace,transferTerritory,transferFunds,playerAction,panel,inspect,bind:S=>{curS=S}};
 root.NovariaDiplomacyUI=UI;
})(typeof window!=='undefined'?window:globalThis);
