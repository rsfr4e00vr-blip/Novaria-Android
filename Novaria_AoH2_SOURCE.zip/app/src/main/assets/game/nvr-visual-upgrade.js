/* Novaria visual layer — presentation only; leaves simulation rules untouched. */
(function(){
'use strict'; if(window.NVRVisual)return;
var root=null,last='';
function fmt(n){return Math.round(Number(n)||0).toLocaleString('ru-RU')}
function ensure(){
 if(root)return root;
 root=document.createElement('aside');root.id='nvr-command-hud';root.setAttribute('aria-live','polite');
 root.innerHTML='<div class="nvr-hud-top"><div><small>NOVARIA COMMAND</small><strong id="nvr-hud-country">Выберите страну</strong></div><button type="button" id="nvr-hud-hide" aria-label="Свернуть панель">−</button></div><div class="nvr-hud-metrics"><div><span>Провинции</span><b id="nvr-hud-regions">—</b></div><div><span>Армия</span><b id="nvr-hud-army">—</b></div><div><span>В движении</span><b id="nvr-hud-moving">—</b></div></div><div class="nvr-hud-actions"><button data-open-tab="overview">Обзор</button><button data-open-tab="economy">Экономика</button><button data-open-tab="military">Армия</button><button data-open-tab="diplomacy">Дипломатия</button></div><div class="nvr-hud-foot" id="nvr-hud-foot">Стратегическая карта</div>';
 document.body.appendChild(root);
 root.querySelector('#nvr-hud-hide').onclick=function(){root.classList.toggle('compact');this.textContent=root.classList.contains('compact')?'+':'−'};
 root.addEventListener('click',function(e){var b=e.target.closest('[data-open-tab]');if(!b)return;var t=document.querySelector('#tabs [data-tab="'+b.dataset.openTab+'"]');if(t)t.click()});
 return root;
}
function update(){
 var el=ensure(),s=window.S;if(!s||!Array.isArray(s.regions)){el.classList.add('nvr-hud-idle');return}
 el.classList.remove('nvr-hud-idle');
 var armies=Array.isArray(s.armies)?s.armies:[],total=armies.reduce(function(n,a){return n+(Number(a.size)||0)},0),moving=armies.filter(function(a){return a.moving&&Number.isFinite(Number(a.moving.to))}).length;
 var sig=[s.name,s.regions.length,total,moving,s.selectedProv].join('|');if(sig===last)return;last=sig;
 el.querySelector('#nvr-hud-country').textContent=s.name||'Государство';
 el.querySelector('#nvr-hud-regions').textContent=fmt(s.regions.length);
 el.querySelector('#nvr-hud-army').textContent=fmt(total);
 el.querySelector('#nvr-hud-moving').textContent=fmt(moving);
 el.querySelector('#nvr-hud-foot').textContent=(s.selectedProv!=null&&s.regions[s.selectedProv]?'Выбрано: '+s.regions[s.selectedProv].name:'Нажмите на провинцию на карте');
}
function drawMovements(){
 var bg=document.getElementById('mapbg'),svg=bg&&bg.querySelector('svg');if(!svg)return;
 var markers=svg.querySelectorAll('#nvr-mk .nvr-mk'),byId={};markers.forEach(function(m){byId[m.getAttribute('data-i')]=m});
 var layer=svg.querySelector('#nvr-army-routes');if(!layer){layer=document.createElementNS('http://www.w3.org/2000/svg','g');layer.id='nvr-army-routes';svg.insertBefore(layer,svg.querySelector('#nvr-mk')||null)}
 var armies=window.S&&Array.isArray(S.armies)?S.armies:[],lines=[];
 armies.forEach(function(a){if(!a.moving||!byId[String(a.region)]||!byId[String(a.moving.to)])return;
 var p=byId[String(a.region)].getAttribute('transform')||'',q=byId[String(a.moving.to)].getAttribute('transform')||'';
 var pm=/translate\(([-\d.]+)[ ,]+([-\d.]+)\)/.exec(p),qm=/translate\(([-\d.]+)[ ,]+([-\d.]+)\)/.exec(q);if(!pm||!qm)return;
 lines.push('<g class="nvr-route"><path d="M'+pm[1]+' '+pm[2]+' L'+qm[1]+' '+qm[2]+'"/><circle cx="'+qm[1]+'" cy="'+qm[2]+'" r="5"/></g>');
 });layer.innerHTML=lines.join('');
}
function tick(){try{update();drawMovements()}catch(e){console.warn('[Novaria visual]',e)}}
window.NVRVisual={refresh:tick};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',tick);else tick();
window.setInterval(tick,1000);document.addEventListener('visibilitychange',function(){if(!document.hidden)tick()});
})();
