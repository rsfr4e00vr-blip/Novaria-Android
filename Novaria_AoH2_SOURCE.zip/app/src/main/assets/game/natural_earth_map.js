/* Novaria Stage 21 map renderer.
 * Accepts real GeoJSON polygons only. It never fabricates province borders.
 * Data source contract: window.NATURAL_EARTH_ADMIN1 FeatureCollection.
 */
(function(root){
'use strict';
const W=1200,H=600,features=[];
let canvas=null,ctx=null,selected=null,scale=1,ox=0,oy=0,drag=null;
let showLabels=false,searchText='',loadState='not-loaded',loadError='',suppressClick=false,dataPromise=null,drawQueued=false;
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const hash=s=>{let h=2166136261;for(let i=0;i<String(s).length;i++){h^=String(s).charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0};
function color(code){const h=hash(code||'world')%360;return `hsl(${h} 36% 34%)`}
function project(p){return [(Number(p[0])+180)/360*W,(85-Number(p[1]))/170*H]}
function boundsFor(g){
 const b=[Infinity,Infinity,-Infinity,-Infinity];
 function visit(v){if(!Array.isArray(v))return;if(typeof v[0]==='number'&&typeof v[1]==='number'){b[0]=Math.min(b[0],v[0]);b[1]=Math.min(b[1],v[1]);b[2]=Math.max(b[2],v[0]);b[3]=Math.max(b[3],v[1]);return;}v.forEach(visit)}
 visit(g.coordinates);return b.every(Number.isFinite)?b:null;
}
function pathFor(g){
 const p=new root.Path2D();
 const polys=g.type==='Polygon'?[g.coordinates]:g.coordinates;
 polys.forEach(poly=>poly.forEach(ring=>{
  if(!Array.isArray(ring)||ring.length<3)return;
  ring.forEach((v,i)=>{const q=project(v);if(!Number.isFinite(q[0])||!Number.isFinite(q[1]))return;if(i)p.lineTo(q[0],q[1]);else p.moveTo(q[0],q[1])});
  p.closePath();
 }));
 return p;
}
function validateDataset(data){
 const out={valid:0,invalid:0,duplicates:0,countries:0,ids:new Set(),errors:[]};
 if(!data||data.type!=='FeatureCollection'||!Array.isArray(data.features)){
  out.errors.push('Ожидается GeoJSON FeatureCollection');return out;
 }
 const countries=new Set();
 data.features.forEach((f,i)=>{
  const g=f&&f.geometry,p=f&&f.properties||{};
  const ok=g&&(g.type==='Polygon'||g.type==='MultiPolygon')&&Array.isArray(g.coordinates)&&g.coordinates.length>0;
  if(!ok){out.invalid++;if(out.errors.length<10)out.errors.push(`Объект ${i}: отсутствует Polygon/MultiPolygon`);return;}
  const id=String(p.novaria_id||p.iso_3166_2||`${p.adm0_a3||'UNK'}-${p.name||i}`);
  if(out.ids.has(id))out.duplicates++;else out.ids.add(id);
  countries.add(String(p.adm0_a3||p.admin||'UNK'));out.valid++;
 });
 out.countries=countries.size;
 return out;
}
function loadFrom(data){
 features.length=0;selected=null;
 const report=validateDataset(data);
 if(!report.valid){loadState='missing';loadError=report.errors[0]||'Геоданные не встроены';return Promise.reject(Error(loadError));}
 const seen=new Set();
 data.features.forEach((f,i)=>{
  const p=f.properties||{},id=String(p.novaria_id||p.iso_3166_2||`${p.adm0_a3||'UNK'}-${p.name||i}`);
  if(seen.has(id))return;seen.add(id);
  const name=p.name||p.name_en||'Без названия';
  features.push({id,name,country:p.admin||p.geonunit||'Неизвестная страна',iso:p.adm0_a3||'UNK',path:pathFor(f.geometry),geometry:f.geometry,bounds:boundsFor(f.geometry),properties:p});
 });
 loadState='ready';loadError='';
 return Promise.resolve(features);
}
function load(){
 if(features.length)return Promise.resolve(features);
 if(root.NATURAL_EARTH_ADMIN1&&Array.isArray(root.NATURAL_EARTH_ADMIN1.features)&&root.NATURAL_EARTH_ADMIN1.features.length)return loadFrom(root.NATURAL_EARTH_ADMIN1);
 if(dataPromise)return dataPromise;
 dataPromise=new Promise((resolve,reject)=>{
  const doc=root.document;
  if(!doc){reject(Error('Нет документа для загрузки геоданных'));return;}
  const script=doc.createElement('script');
  script.src='natural_earth_admin1_data.js';script.async=true;
  script.onload=()=>{try{resolve(loadFrom(root.NATURAL_EARTH_ADMIN1))}catch(e){reject(e)}};
  script.onerror=()=>{loadState='missing';loadError='Файл natural_earth_admin1_data.js не загружен';reject(Error(loadError))};
  (doc.head||doc.body).appendChild(script);
 }).catch(e=>{dataPromise=null;throw e});
 return dataPromise;
}
function panel(){
 return `<section class="panel wide"><h2>🌍 Географическая карта и провинции</h2>
 <p class="muted">Карта использует реальные полигоны из GeoJSON. Границы AoH2 подключаются только из оригинальных файлов карты; искусственные границы не создаются.</p>
 <div class="actions" style="gap:6px;flex-wrap:wrap">
  <button type="button" onclick="NaturalEarthMap.zoomIn()">＋ Увеличить</button>
  <button type="button" onclick="NaturalEarthMap.zoomOut()">－ Уменьшить</button>
  <button type="button" onclick="NaturalEarthMap.reset()">Сбросить</button>
  <button type="button" onclick="NaturalEarthMap.toggleLabels()">Подписи</button>
  <input id="neSearch" type="search" placeholder="Найти регион или страну" aria-label="Поиск региона" style="min-width:150px;max-width:260px" />
  <button type="button" onclick="NaturalEarthMap.search(document.getElementById('neSearch').value)">Найти</button>
 </div>
 <div id="neMapWrap" style="position:relative;width:100%;height:min(68vh,650px);min-height:300px;background:#081521;border:1px solid #314456;border-radius:8px;overflow:hidden;touch-action:none">
  <canvas id="neMap" aria-label="Интерактивная карта административных регионов" role="img" style="width:100%;height:100%;display:block;touch-action:none"></canvas>
 </div>
 <div id="neCount" class="muted" role="status" aria-live="polite">Проверка геоданных…</div>
 <div id="neSelected" class="mini" style="margin-top:10px">Выберите регион на карте.</div></section>`;
}
function resize(){
 if(!canvas||!ctx)return;
 const r=canvas.getBoundingClientRect(),dpr=Math.min(2,root.devicePixelRatio||1);
 canvas.width=Math.max(1,Math.round(r.width*dpr));canvas.height=Math.max(1,Math.round(r.height*dpr));
 ctx.setTransform(dpr,0,0,dpr,0,0);draw();
}
function drawNow(){
 if(!ctx||!canvas)return;
 const r=canvas.getBoundingClientRect(),sx=r.width/W*scale,sy=r.height/H*scale;
 ctx.clearRect(0,0,r.width,r.height);ctx.fillStyle='#081521';ctx.fillRect(0,0,r.width,r.height);
 if(!features.length){ctx.fillStyle='#9aadc2';ctx.font='14px system-ui';ctx.textAlign='center';ctx.fillText('Геоданные провинций не подключены',r.width/2,r.height/2);return;}
 ctx.save();ctx.translate(ox,oy);ctx.scale(sx,sy);
 features.forEach(f=>{
  const match=!searchText||(f.name+' '+f.country+' '+f.id).toLowerCase().includes(searchText);
  ctx.globalAlpha=match?1:.18;ctx.fillStyle=color(f.iso);ctx.strokeStyle='rgba(220,231,239,.55)';ctx.lineWidth=.55/Math.max(scale,.5);
  ctx.fill(f.path,'evenodd');ctx.stroke(f.path);
  if(showLabels&&scale>=1.8&&match){const b=featureCenter(f);if(b){ctx.fillStyle='#f3f6fa';ctx.font=`${Math.max(3,7/scale)}px system-ui`;ctx.textAlign='center';ctx.fillText(f.name,b[0],b[1]);}}
 });
 ctx.globalAlpha=1;
 if(selected){const f=features.find(x=>x.id===selected);if(f){ctx.fillStyle='rgba(245,195,77,.45)';ctx.strokeStyle='#ffe08a';ctx.lineWidth=2/Math.max(scale,.5);ctx.fill(f.path,'evenodd');ctx.stroke(f.path)}}
 ctx.restore();
}
function draw(){if(drawQueued)return;drawQueued=true;const raf=root.requestAnimationFrame||function(fn){return root.setTimeout(fn,16)};raf(()=>{drawQueued=false;drawNow()});}
function featureCenter(f){
 const c=f.geometry&&f.geometry.coordinates;if(!c)return null;
 const poly=f.geometry.type==='Polygon'?c[0]:c[0]&&c[0][0];if(!poly||!poly.length)return null;
 let x=0,y=0,n=0;poly.forEach(p=>{x+=p[0];y+=p[1];n++});return n?project([x/n,y/n]):null;
}
function showFeature(f){
 selected=f.id;const el=root.document&&root.document.getElementById('neSelected');
 if(el)el.innerHTML=`<b>${esc(f.name)}</b><br>${esc(f.country)} · ${esc(f.id)}<br><small>Географический административный полигон; это не подтверждает соответствие провинции AoH2.</small>`;
 draw();
}
function pick(e){
 if(suppressClick){suppressClick=false;return;}
 if(!ctx||!canvas||!features.length)return;
 const r=canvas.getBoundingClientRect(),sx=r.width/W*scale,sy=r.height/H*scale;
 const x=(e.clientX-r.left-ox)/sx,y=(e.clientY-r.top-oy)/sy,lon=x/W*360-180,lat=85-y/H*170;
 for(let i=features.length-1;i>=0;i--){const b=features[i].bounds;if(b&&(lon<b[0]||lon>b[2]||lat<b[1]||lat>b[3]))continue;if(ctx.isPointInPath(features[i].path,x,y,'evenodd')){showFeature(features[i]);return}}
}
function zoom(factor,anchorX,anchorY){
 if(!canvas)return;
 const r=canvas.getBoundingClientRect(),cx=anchorX==null?r.width/2:anchorX-r.left,cy=anchorY==null?r.height/2:anchorY-r.top;
 const next=Math.max(1,Math.min(12,scale*factor)),ratio=next/scale;
 ox=cx-(cx-ox)*ratio;oy=cy-(cy-oy)*ratio;scale=next;draw();
}
function search(q){
 searchText=String(q||'').trim().toLowerCase();
 if(!searchText){draw();return false}
 const f=features.find(x=>(x.name+' '+x.country+' '+x.id).toLowerCase().includes(searchText));
 if(!f){const el=root.document&&root.document.getElementById('neSelected');if(el)el.textContent='Регион не найден в подключённых геоданных.';draw();return false}
 selected=f.id;const c=featureCenter(f),r=canvas&&canvas.getBoundingClientRect();
 if(c&&r){scale=Math.max(scale,2);ox=r.width/2-c[0]*(r.width/W*scale);oy=r.height/2-c[1]*(r.height/H*scale)}
 showFeature(f);return true;
}
function mount(){
 const el=root.document&&root.document.getElementById('neMap');if(!el)return;
 canvas=el;ctx=canvas.getContext('2d');
 load().then(()=>{
  const c=root.document.getElementById('neCount');if(c)c.textContent=`Загружено административных полигонов: ${features.length.toLocaleString('ru-RU')}. Уровень детализации зависит от источника.`;
  resize();
 }).catch(e=>{
  const c=root.document.getElementById('neCount');if(c)c.textContent=`Карта не загружена: ${e.message}. Добавьте проверенный GeoJSON или оригинальные данные AoH2.`;
  draw();
 });
 if(!canvas.dataset.bound){
  canvas.dataset.bound='1';
  canvas.addEventListener('click',pick);
  canvas.addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY<0?1.2:.83,e.clientX,e.clientY)},{passive:false});
  canvas.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,ox,oy,moved:false};canvas.setPointerCapture(e.pointerId)});
  canvas.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.abs(dx)+Math.abs(dy)>4)drag.moved=true;ox=drag.ox+dx;oy=drag.oy+dy;draw()});
  canvas.addEventListener('pointerup',()=>{if(drag&&drag.moved)suppressClick=true;drag=null});
  canvas.addEventListener('pointercancel',()=>drag=null);
  root.addEventListener('resize',resize);
 }
}
function reset(){scale=1;ox=0;oy=0;searchText='';selected=null;draw()}
function zoomIn(){zoom(1.35)}
function zoomOut(){zoom(1/1.35)}
function toggleLabels(){showLabels=!showLabels;draw();return showLabels}
root.NaturalEarthMap={
 panel,mount,reset,zoomIn,zoomOut,toggleLabels,search,validateDataset,loadData:loadFrom,
 get selected(){return selected},get features(){return features.length},
 get status(){return {state:loadState,error:loadError,count:features.length}}
};
})(window);
