/* Novaria Territory System v1.0 (Этап 11). Оригинальная реализация.
 * Захват провинций после победы (этап 10), контроль и полноценное владение, смена границ,
 * передача при мире, недовольство, восстания и возврат независимости, сохранение в S.territory.
 * Различаются: владелец (де-юре, S.territory.owners / S.taken) и контролирующий (de facto, S.territory.controller). */
(function(root){'use strict';
 const VERSION=1,ANNEX_MIN_MONTHS=3,ANNEX_PP=20;
 const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 const AR=()=>root.NovariaArmies,me=S=>S.me||S.name,abs=S=>num(S.year)*12+num(S.month);
 function ensure(S){const t=S.territory;if(!t||t.version!==VERSION)S.territory={version:VERSION,controller:{},owners:{},annexed:{},unrest:{},demand:{},wars:null,log:[]};return S.territory}
 const addLog=(t,x)=>{t.log.unshift(x);t.log.length=Math.min(t.log.length,40)};
 const base=id=>{const C=AR().countryOf(id);return C&&C.name?C.name:null};
 function deJure(S,id){const t=ensure(S);if(t.owners[id])return t.owners[id];if((S.taken||{})[id])return me(S);return base(id)}
 function controllerOf(S,id){const t=ensure(S),c=t.controller[id];return c&&c.by?c.by:deJure(S,id)}
 const pn=id=>AR().provName(id);
 function economyGain(S,id,from){try{const NGx=root.NG;if(!NGx||!NGx.gainRegion)return;const C=AR().countryOf(id),r=AR().regionOf(id),info=NGx.countryInfo&&NGx.countryInfo(from),pop=Math.round(num(info&&info.pop,5)*1e6*num(r&&r.s,100/Math.max(1,(C&&C.regs||[1]).length))/100);
   let name=pn(id);if(S.regions.some(x=>x.name===name))name+=' ('+id+')';NGx.gainRegion({name,pop:Math.max(20000,pop),from,gdp:0})}catch(e){}}
 function economyLose(S,id){try{const NGx=root.NG;if(!NGx||!NGx.loseRegion)return;const n=pn(id),n2=pn(id)+' ('+id+')';const nm=S.regions.some(x=>x.name===n2)?n2:n;NGx.loseRegion(nm,0.03)}catch(e){}}
 function checkWhole(S,id){const C=AR().countryOf(id);if(!C||!C.regs)return;const nm=C.name,m=me(S);
   if(nm&&nm!==m&&C.regs.every(r=>deJure(S,r.id)===m)){const rel=(S.relations||[]).find(x=>x.name===nm);if(rel&&!rel.annexed){rel.annexed=true;S.wars=(S.wars||[]).filter(w=>w.n!==nm);addLog(ensure(S),`🏴 ${nm} полностью присоединена и исчезает с карты`)}}}
 /* Полноценное владение */
 function annex(S,id,free){
   const t=ensure(S),m=me(S);id=String(id);const c=t.controller[id];
   if(!c||c.by!==m)return {ok:false,message:'Провинция не под вашим контролем'};
   if(deJure(S,id)===m)return {ok:false,message:'Провинция уже ваша'};
   if(!free){if(c.months<ANNEX_MIN_MONTHS)return {ok:false,message:`Нужно удерживать провинцию ещё ${ANNEX_MIN_MONTHS-c.months} мес.`};
     if(num(S.pp)<ANNEX_PP)return {ok:false,message:`Нужно ${ANNEX_PP} политической власти`};S.pp-=ANNEX_PP}
   const from=deJure(S,id);t.owners[id]=m;S.taken=S.taken||{};S.taken[id]=1;delete t.controller[id];t.annexed[id]={from,months:0};t.unrest[id]=Math.max(num(t.unrest[id]),15);
   economyGain(S,id,from);addLog(t,`🏴 ${pn(id)} присоединена (было: ${from})`);checkWhole(S,id);return {ok:true,from}}
 /* Вернуть владельца (восстание, мирный договор, освобождение) */
 function restore(S,id,toName){const t=ensure(S),was=deJure(S,id);id=String(id);
   if(toName===base(id))delete t.owners[id];else t.owners[id]=toName;
   if(was===me(S)&&toName!==me(S)){if(S.taken)delete S.taken[id];economyLose(S,id)}
   if(toName===me(S)){S.taken=S.taken||{};S.taken[id]=1}
   delete t.controller[id];delete t.annexed[id];delete t.unrest[id];
   const C=AR().countryOf(id),rel=C&&(S.relations||[]).find(x=>x.name===C.name);if(rel&&rel.annexed&&toName!==me(S))rel.annexed=false}
 function transfer(S,id,toName){const t=ensure(S),from=deJure(S,id);restore(S,id,toName);if(toName===me(S)){S.taken[id]=1;t.owners[id]=toName;t.annexed[id]={from,months:0};economyGain(S,id,from)}addLog(t,`📜 ${pn(id)}: ${from} → ${toName}`);return {ok:true}}
 /* Прибытие армии: занятие прорыва / освобождение */
 function onArrive(S,st){
   const t=ensure(S),B=S.battles,id=st.prov,own=st.owner,cur=controllerOf(S,id);if(cur===own)return;
   const br=B&&B.breach&&B.breach[id];if(!br||br.by!==own)return;
   delete B.breach[id];const dj=deJure(S,id);
   if(dj===own){delete t.controller[id];addLog(t,`🕊 ${pn(id)} освобождена`)}
   else{t.controller[id]={by:own,orig:dj,since:abs(S),months:0};t.unrest[id]=num(t.unrest[id]);addLog(t,`🚩 ${pn(id)} занята (владелец: ${dj})`)}}
 /* Мир: что с занятыми провинциями */
 function settle(S,enemy){
   const t=ensure(S),m=me(S);let won=0,back=0,lost=0;
   Object.keys(t.controller).forEach(id=>{const c=t.controller[id],dj=deJure(S,id);
     if(c.by===m&&dj===enemy){if(t.demand[id]===false){delete t.controller[id];back++}else{annex(S,id,true);won++}}
     else if(c.by===enemy&&dj===m){delete t.controller[id];back++}
     else if(c.by===enemy&&dj!==m){delete t.controller[id]}});
   if(won||back)addLog(t,`📜 Мир с ${enemy}: присоединено ${won}, возвращено ${back}`);return {won,back,lost}}
 function sync(S){const t=ensure(S),now=(S.wars||[]).filter(w=>!w.won).map(w=>w.n);
   if(t.wars===null){t.wars=now;return}
   t.wars.filter(n=>!now.includes(n)).forEach(n=>settle(S,n));t.wars=now}
 function stackMen(S,id){const A=AR().ensure(S),M=S.military;let men=0;A.stacks.forEach(st=>{if(st.prov===id&&st.owner===me(S)&&st.status!=='fighting')men+=AR().ensure(S)&&(M&&M.divisions||[]).filter(d=>st.divs.includes(d.id)).reduce((a,d)=>a+num(d.manpower),0)});return men}
 function monthly(S){
   const t=ensure(S),m=me(S);sync(S);
   Object.keys(t.controller).forEach(id=>{const c=t.controller[id];c.months++;
     if(c.by===m){const u=num(t.unrest[id])+2-Math.min(4,stackMen(S,id)/10000*1.5);t.unrest[id]=clamp(u,0,100);
       if(t.unrest[id]>=100){addLog(t,`🔥 Восстание: контроль над ${pn(id)} потерян`);delete t.controller[id];t.unrest[id]=40}}});
   Object.keys(t.annexed).forEach(id=>{const a=t.annexed[id];a.months++;if(deJure(S,id)!==m){delete t.annexed[id];return}
     const u=num(t.unrest[id])+(a.months<=12?1.5:-1)-Math.min(4,stackMen(S,id)/10000*1.5)-((S.stability||50)>70?.5:0)+((S.stability||50)<35?1.5:0);t.unrest[id]=clamp(u,0,100);
     if(t.unrest[id]>=100){const nm=a.from;restore(S,id,nm);addLog(t,`🔥 Восстание: ${pn(id)} вернула независимость (${nm})`);try{root.NG&&root.NG.toast&&root.NG.toast(`🔥 Восстание: ${pn(id)} вернулась к ${nm}`)}catch(e){}}})}
 function tick(S){if(!S)return;ensure(S);monthly(S)}
 function stats(S){const t=ensure(S),m=me(S),o={};Object.keys(t.controller).forEach(id=>{const b=t.controller[id].by;o[b]=(o[b]||0)+1});
   return {controlled:Object.keys(t.controller).filter(i=>t.controller[i].by===m).length,occupiedFromMe:Object.keys(t.controller).filter(i=>t.controller[i].by!==m&&deJure(S,i)===m).length,annexed:Object.keys(t.annexed).length,byController:o}}
 root.NovariaTerritory={version:VERSION,ensure,deJure,controllerOf,annex,restore,transfer,onArrive,settle,sync,tick,stats,ANNEX_MIN_MONTHS,ANNEX_PP};
 /* ================= Интерфейс ================= */
 if(typeof document==='undefined')return;
 const NG=()=>root.NG,S0=()=>NG()&&NG().S;
 const col=n=>{if(!n)return '#888';let h=2166136261;for(const ch of String(n)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619)}return `hsl(${(h>>>0)%360} 55% 45%)`};
 root.NovariaTerritoryUI={
  annex(id){const s=S0();const r=annex(s,id,false);NG().toast(r.ok?'🏴 Провинция присоединена':r.message);NG().save();root.NovariaArmiesUI&&root.NovariaArmiesUI.redraw()},
  demand(id,on){const s=S0();ensure(s).demand[id]=!!on;NG().save()},
  panelHtml(s,esc,pn2){const t=ensure(s),m=me(s),ids=Object.keys(t.controller);if(!ids.length&&!Object.keys(t.annexed).length)return '';
   let h='<div class="st"><b>🗺 Территории</b>';const sx=stats(s);h+=`<small>Под контролем: ${sx.controlled} · присоединено: ${sx.annexed} · мои провинции у врага: ${sx.occupiedFromMe}</small>`;
   ids.forEach(id=>{const c=t.controller[id],dj=deJure(s,id);if(c.by===m)h+=`<small>🚩 ${esc(pn2(id))} (владелец ${esc(dj)}) · ${c.months} мес. · недовольство ${Math.round(num(t.unrest[id]))}%</small><button onclick="NovariaTerritoryUI.annex('${esc(id)}')">🏴 Присоединить (${ANNEX_PP} ПВ)</button><label><input type="checkbox" ${t.demand[id]===false?'':'checked'} onchange="NovariaTerritoryUI.demand('${esc(id)}',this.checked)"> в мирный договор</label>`;
     else if(dj===m)h+=`<small>⚠ ${esc(pn2(id))} оккупирована: ${esc(c.by)} — освободите атакой</small>`});
   Object.keys(t.annexed).forEach(id=>{h+=`<small>🏛 ${esc(pn2(id))} (бывш. ${esc(t.annexed[id].from)}) · недовольство ${Math.round(num(t.unrest[id]))}%</small>`});
   h+=(t.log.slice(0,3).map(x=>`<small>${esc(x)}</small>`).join(''))+'</div>';return h}};
 /* слой границ на карте */
 setInterval(()=>{const s=S0(),w=root.WMAP&&root.WMAP.node,A=AR();if(!s||!w||!A||!s.territory||!root.GEO||!root.GEO.c)return;sync(s);
  const t=s.territory,m=me(s);let g=w.querySelector('#nvrTerrLayer');if(!g){g=document.createElementNS('http://www.w3.org/2000/svg','g');g.id='nvrTerrLayer';g.setAttribute('pointer-events','none');w.insertBefore(g,w.querySelector('#nvrArmyLayer')||null)}
  const ids=new Set(Object.keys(t.controller).concat(Object.keys(t.owners)));let defs='',body='';const done={};
  ids.forEach(id=>{const r=A.regionOf(id),C=A.countryOf(id);if(!r||!r.d||!C)return;const ctl=controllerOf(s,id),dj=deJure(s,id);if(ctl===m&&dj===m&&(s.taken||{})[id])return;
   const iso=C.iso;if(!done[iso]){done[iso]=1;defs+=`<clipPath id="nvrClip_${iso}"><path d="${C.d}"/></clipPath>`}
   body+=`<g clip-path="url(#nvrClip_${iso})"><path d="${r.d}" fill="${col(ctl)}" fill-opacity="${ctl!==dj?.42:.3}" stroke="${col(dj)}" stroke-width="${(root.GEO.W||1000)*.0016}" ${ctl!==dj?`stroke-dasharray="${(root.GEO.W||1000)*.004}"`:''}/></g>`});
  const sig=defs+body;if(g.__sig!==sig){g.__sig=sig;g.innerHTML=`<defs>${defs}</defs>${body}`}},2000);
})(typeof window!=='undefined'?window:globalThis);
