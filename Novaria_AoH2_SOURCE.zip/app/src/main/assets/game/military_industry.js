/* Novaria Military Industry — Stage 13.
 * Original gameplay module: industrial capacity, equipment production and stockpiles.
 * AI and authoritative multiplayer replication are intentionally integrated in later stages.
 */
(function(root){
 'use strict';
 const VERSION=1, clamp=(v,a,b)=>Math.max(a,Math.min(b,Number.isFinite(+v)?+v:0));
 const TYPES={
  arms:{name:'Завод вооружения',icon:'🏭',cost:1800,steel:3,energy:2,output:{equipment:5,ammo:7}},
  vehicle:{name:'Машиностроительный завод',icon:'🚜',cost:2600,steel:5,energy:3,output:{tanks:2,parts:4}},
  artillery:{name:'Артиллерийский завод',icon:'💥',cost:2200,steel:4,energy:2,output:{artillery:3,ammo:4}}
 };
 function ensure(S){
  if(!S)return null;
  let I=S.militaryIndustry;
  if(!I||I.version!==VERSION){
   const old=I||{};
   I=S.militaryIndustry={version:VERSION,factories:Object.assign({arms:0,vehicle:0,artillery:0},old.factories||{}),
    stock:Object.assign({equipment:0,ammo:0,tanks:0,parts:0,artillery:0},old.stock||{}),
    produced:Object.assign({},old.produced||{}),spent:Number(old.spent)||0,monthKey:null,last:null};
  }
  Object.keys(TYPES).forEach(k=>I.factories[k]=clamp(I.factories[k],0,100));
  Object.keys(I.stock).forEach(k=>I.stock[k]=clamp(I.stock[k],0,1000000));
  return I;
 }
 function build(S,type){
  const I=ensure(S),T=TYPES[type];if(!I||!T)return {ok:false,reason:'unknown'};
  const scale=clamp((+S.gdp||42000)/42000,.5,5),cost=Math.round(T.cost*scale);
  if((+S.money||0)<cost)return {ok:false,reason:'money',cost};
  if((+S.steel||0)<T.steel)return {ok:false,reason:'steel',cost};
  if((+S.energy||0)<T.energy)return {ok:false,reason:'energy',cost};
  S.money-=cost;S.steel=clamp((+S.steel||0)-T.steel,0,100);
  S.energy=clamp((+S.energy||0)-T.energy,0,100);
  I.factories[type]++;I.spent+=cost;
  return {ok:true,cost,factories:I.factories[type]};
 }
 function tick(S){
  const I=ensure(S);if(!I||S.campaignOver)return null;
  const key=`${S.year||0}:${S.month||0}:${S.mpMonth||0}`;
  if(I.monthKey===key)return I.last;
  const produced={equipment:0,ammo:0,tanks:0,parts:0,artillery:0};let cost=0,steel=0,energy=0;
  Object.keys(TYPES).forEach(k=>{
   const count=I.factories[k],T=TYPES[k];if(!count)return;
   const factor=clamp(Math.min((+S.steel||0)/35,(+S.energy||0)/30),0,1);
   const operating=Math.min(1,Math.max(0,(+S.money||0)/(T.cost*count*.12||1)));
   const eff=factor*operating;
   steel+=T.steel*count*.16*eff;energy+=T.energy*count*.18*eff;
   cost+=T.cost*count*.012*eff;
   Object.keys(T.output).forEach(item=>produced[item]+=T.output[item]*count*eff);
  });
  steel=Math.min(steel,Math.max(0,+S.steel||0));energy=Math.min(energy,Math.max(0,+S.energy||0));
  S.steel=clamp((+S.steel||0)-steel,0,100);S.energy=clamp((+S.energy||0)-energy,0,100);
  S.money=Math.max(0,(+S.money||0)-cost);
  Object.keys(produced).forEach(k=>{I.stock[k]=clamp((I.stock[k]||0)+produced[k],0,1000000);I.produced[k]=(I.produced[k]||0)+produced[k]});
  // Legacy army panels read these common readiness stocks; never replace existing values.
  S.equipment=clamp((+S.equipment||0)+produced.equipment*.08,0,100);
  S.ammo=clamp((+S.ammo||0)+produced.ammo*.08,0,100);
  I.monthKey=key;I.last={produced,cost:Math.round(cost),steel:+steel.toFixed(2),energy:+energy.toFixed(2),efficiency:Math.round((Object.values(I.factories).reduce((a,b)=>a+b,0)?Object.values(I.factories).reduce((a,b)=>a+b,0):0)?100:0)};
  return I.last;
 }
 function panel(S){
  const I=ensure(S);if(!I)return '';
  const fmt=n=>Number(n||0).toLocaleString('ru-RU',{maximumFractionDigits:1});
  const rows=Object.keys(TYPES).map(k=>{const T=TYPES[k];return `<div class="mini"><b>${T.icon} ${T.name}</b><strong>${I.factories[k]} шт.</strong><small>Цена нового: ${fmt(T.cost*clamp((+S.gdp||42000)/42000,.5,5))} млн · выпуск: ${Object.entries(T.output).map(([a,b])=>`${a} +${b}/мес.`).join(', ')}</small><button type="button" onclick="NovariaMilitaryIndustry.build('${k}')">Построить завод</button></div>`}).join('');
  const stock=Object.entries(I.stock).map(([k,v])=>`${k}: ${fmt(v)}`).join(' · ');
  const last=I.last?`Последний выпуск: ${Object.entries(I.last.produced).filter(x=>x[1]>0).map(([k,v])=>`${k} +${fmt(v)}`).join(', ')||'нет производства'}; расходы ${fmt(I.last.cost)} млн`:'Ожидание первого месяца';
  return `<section class="panel"><h2>🏭 Военная промышленность · этап 13</h2><p class="muted">Заводы выпускают вооружение, боеприпасы, танки, комплектующие и артиллерию. Производство ограничено запасами стали, энергии и средствами казны.</p><div class="cards">${rows}</div><p><b>Военные склады:</b> ${stock}</p><p class="muted">${last}</p><p class="muted">Всего вложено в строительство: ${fmt(I.spent)} млн.</p></section>`;
 }
 root.NovariaMilitaryIndustry={version:VERSION,types:TYPES,ensure,buildState:build,tick,panel,build:(type)=>{const S=root.NG&&root.NG.S;if(!S)return;const r=build(S,type);if(!r.ok){const msg=r.reason==='money'?'Недостаточно денег':r.reason==='steel'?'Недостаточно стали':r.reason==='energy'?'Недостаточно энергии':'Неизвестный завод';if(root.NG.toast)root.NG.toast(msg);return r;}if(root.NG.log)root.NG.log(`🏭 Построен завод: ${TYPES[type].name}.`);if(root.NG.toast)root.NG.toast(`Завод построен · ${r.cost} млн`);if(root.NG.render)root.NG.render();return r;},tick,panel};
})(typeof window!=='undefined'?window:globalThis);
