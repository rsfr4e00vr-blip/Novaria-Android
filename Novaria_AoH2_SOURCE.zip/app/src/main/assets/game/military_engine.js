/* Novaria Military Engine v1.0
 * Original implementation; no third-party game code copied.
 * Deterministic monthly resolution, persistent divisions, fronts and orders.
 */
(function (root) {
  'use strict';
  const VERSION = 1;
  const TYPES = {
    infantry: { name: 'Пехотная', manpower: 10000, attack: 42, defense: 58, equipment: 35, supply: 1.0 },
    motorized: { name: 'Моторизованная', manpower: 8500, attack: 58, defense: 45, equipment: 55, supply: 1.35 },
    mechanized: { name: 'Механизированная', manpower: 7000, attack: 75, defense: 62, equipment: 78, supply: 1.7 },
    armor: { name: 'Танковая', manpower: 5200, attack: 92, defense: 68, equipment: 95, supply: 2.1 },
    artillery: { name: 'Артиллерийская', manpower: 4200, attack: 82, defense: 28, equipment: 72, supply: 1.6 },
    engineers: { name: 'Инженерная', manpower: 5000, attack: 32, defense: 78, equipment: 42, supply: 1.1 },
    recon: { name: 'Разведывательная', manpower: 3600, attack: 48, defense: 35, equipment: 48, supply: 1.0 },
    airborne: { name: 'Десантная', manpower: 6000, attack: 70, defense: 42, equipment: 68, supply: 1.5 }
  };
  const ORDERS = ['attack', 'defend', 'withdraw', 'encircle', 'hold', 'counter'];
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const num = (v, d = 0) => Number.isFinite(Number(v)) ? Number(v) : d;
  function hash(s) { let h = 2166136261; for (let i = 0; i < String(s).length; i++) { h ^= String(s).charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function roll(seed, lo, hi) { let x = seed >>> 0; x ^= x << 13; x ^= x >>> 17; x ^= x << 5; return lo + (x >>> 0) / 4294967295 * (hi - lo); }
  function ensure(S) {
    if (!S.military || S.military.version !== VERSION) {
      const old = S.military || {};
      S.military = { version: VERSION, nextId: 1, month: 0, divisions: Array.isArray(old.divisions) ? old.divisions : [], fronts: old.fronts || {}, airWings: old.airWings || [], fleets: old.fleets || [], commanders: old.commanders || [], selectedDivision: null, selectedFront: null, log: old.log || [] };
    }
    const M = S.military;
    if (!M.divisions.length && num(S.army) > 0) {
      const count = Math.max(1, Math.min(8, Math.ceil(num(S.army) / 10000)));
      let remaining = Math.floor(num(S.army));
      for (let i = 0; i < count; i++) {
        const manpower = Math.floor(remaining / (count - i)); remaining -= manpower;
        M.divisions.push({ id: M.nextId++, type: 'infantry', name: `Пехотная дивизия ${i + 1}`, manpower, equipment: 55, morale: num(S.morale, 65), experience: 0, supply: 75, readiness: 75, commander: null, front: null, order: 'hold', losses: 0 });
      }
    }
    (S.wars || []).forEach(w => {
      if (!M.fronts[w.n]) M.fronts[w.n] = { id: `front-${hash(w.n).toString(16)}`, enemy: w.n, progress: clamp(num(w.p, 50), 1, 99), order: 'hold', supply: 70, morale: num(S.morale, 65), casualties: 0, battles: 0, sectors: [], created: M.month };
    });
    Object.keys(M.fronts).forEach(n => { if (!(S.wars || []).some(w => w.n === n)) delete M.fronts[n]; });
    return M;
  }
  function addLog(M, text) { M.log.unshift({ month: M.month, text }); M.log.length = Math.min(M.log.length, 30); }
  function availableManpower(S) { const M = ensure(S); return Math.max(0, Math.floor(num(S.army) - M.divisions.reduce((a, d) => a + num(d.manpower), 0))); }
  function createDivision(S, type) {
    const M = ensure(S), T = TYPES[type]; if (!T) return { ok: false, error: 'Неизвестный тип соединения' };
    if (availableManpower(S) < T.manpower) return { ok: false, error: `Нужно ${T.manpower.toLocaleString('ru-RU')} свободных военнослужащих` };
    const cost = Math.round(T.equipment * 2.2 + T.manpower / 1000 * 7);
    if (num(S.money) < cost) return { ok: false, error: `Нужно ${cost} млн на оснащение` };
    S.money -= cost;
    const d = { id: M.nextId++, type, name: `${T.name} дивизия ${M.nextId - 1}`, manpower: T.manpower, equipment: 65, morale: num(S.morale, 65), experience: 0, supply: 80, readiness: 70, commander: null, front: null, order: 'hold', losses: 0 };
    M.divisions.push(d); addLog(M, `Сформировано соединение: ${d.name}`); return { ok: true, division: d };
  }
  function assign(S, id, enemy) {
    const M = ensure(S), d = M.divisions.find(x => x.id === Number(id));
    if (!d || !M.fronts[enemy]) return false;
    d.front = enemy; M.selectedDivision = d.id; M.selectedFront = enemy; return true;
  }
  function setOrder(S, enemy, order) {
    const M = ensure(S); if (!M.fronts[enemy] || !ORDERS.includes(order)) return false;
    M.fronts[enemy].order = order;
    M.divisions.filter(d => d.front === enemy).forEach(d => d.order = order);
    addLog(M, `Фронту против ${enemy} отдан приказ: ${orderLabel(order)}`); return true;
  }
  function orderLabel(o) { return ({ attack: 'наступать', defend: 'обороняться', withdraw: 'отступать', encircle: 'окружать', hold: 'удерживать позиции', counter: 'контрнаступать' })[o] || o; }
  function frontStrength(S, enemy, side) {
    const M = ensure(S), ds = M.divisions.filter(d => d.front === enemy);
    return ds.reduce((sum, d) => {
      const t = TYPES[d.type] || TYPES.infantry;
      const quality = (num(d.equipment, 50) / 100) * .35 + (num(d.morale, 50) / 100) * .25 + (num(d.readiness, 50) / 100) * .2 + (num(d.supply, 50) / 100) * .2;
      return sum + (side === 'attack' ? t.attack : t.defense) * (num(d.manpower) / 1000) * quality;
    }, 0);
  }
  function tick(S) {
    const M = ensure(S); M.month++;
    const wars = S.wars || [];
    wars.forEach(w => {
      const F = M.fronts[w.n]; if (!F) return;
      const enemy = (S.relations || []).find(r => r.name === w.n) || {};
      const assigned = M.divisions.filter(d => d.front === w.n);
      if (!assigned.length) {
        const candidate = M.divisions.filter(d => !d.front).sort((a,b) => b.manpower-a.manpower)[0];
        if (candidate) candidate.front = w.n;
      }
      const ownAttack = frontStrength(S, w.n, 'attack');
      const ownDefense = frontStrength(S, w.n, 'defense');
      const supplyBase = Math.min(num(S.food, 50), num(S.fuel, 50), num(S.ammo, 50), num(S.equipment, 50));
      F.supply = clamp(supplyBase * .72 + assigned.reduce((a,d)=>a+num(d.supply),0) / Math.max(1,assigned.length) * .28, 0, 100);
      F.morale = clamp(assigned.reduce((a,d)=>a+num(d.morale),0) / Math.max(1,assigned.length), 0, 100);
      const enemyPower = Math.max(8, num(enemy.power, 30) * 1.35);
      F.airMission = F.airMission || (num(S.air) > 0 ? 'support' : 'reserve');
      F.navyMission = F.navyMission || (num(S.navy) > 0 ? 'escort' : 'reserve');
      const airBonus = F.airMission === 'support' ? Math.min(.22, num(S.air) * .003) : F.airMission === 'patrol' ? Math.min(.12, num(S.air) * .002) : F.airMission === 'strategic' ? Math.min(.16, num(S.air) * .0025) : 0;
      const navyBonus = F.navyMission === 'escort' ? Math.min(.13, num(S.navy) * .012) : F.navyMission === 'blockade' ? Math.min(.10, num(S.navy) * .009) : 0;
      const order = F.order || 'hold';
      const offensive = ['attack','encircle','counter'].includes(order);
      const defensive = ['defend','hold','withdraw'].includes(order);
      const ownPower = offensive ? ownAttack : ownDefense;
      const supplyFactor = .25 + F.supply / 130;
      const moraleFactor = .45 + F.morale / 180;
      const enemyAI = clamp(num(enemy.aggr, .45), .1, .95);
      const aiBonus = enemyAI > .7 ? 1.12 : enemyAI < .3 ? .92 : 1;
      const seed = hash(`${S.year}:${S.month}:${w.n}:${M.month}`);
      const battleFactor = roll(seed, .92, 1.08);
      const protectedEnemy = enemyPower * aiBonus * (1 - Math.min(.12, num(S.aa) * .004));
      const ratio = (ownPower * supplyFactor * moraleFactor * battleFactor * (1 + airBonus + navyBonus)) / Math.max(1, protectedEnemy);
      let change = clamp((ratio - 1) * (offensive ? 5.2 : 2.4), -3.2, 3.2);
      if (order === 'withdraw') change = Math.min(-.35, change - .6);
      if (order === 'hold') change *= .35;
      if (order === 'encircle' && ratio > 1.15) change *= 1.3;
      if (order === 'counter' && F.progress < 48 && ratio > 1) change *= 1.2;
      F.progress = clamp(F.progress + change, 1, 99); w.p = F.progress;
      if (F.navyMission === 'blockade' && num(S.navy) > 0) { F.enemySupplyPressure = clamp(num(F.enemySupplyPressure) + .8, 0, 30); }
      if (F.airMission === 'strategic' && num(S.air) > 0) { F.enemyIndustryPressure = clamp(num(F.enemyIndustryPressure) + .6, 0, 25); }
      F.battles++;
      const lossBase = Math.max(8, Math.round((enemyPower / Math.max(1, ownPower + enemyPower)) * 180));
      assigned.forEach((d, i) => {
        const loss = Math.min(d.manpower, Math.round(lossBase * (d.type === 'armor' ? 1.15 : 1) * roll(hash(seed + ':' + d.id), .75, 1.25)));
        d.manpower -= loss; d.losses += loss; F.casualties += loss;
        d.experience = clamp(num(d.experience) + .35, 0, 100);
        d.morale = clamp(num(d.morale) + (change > 0 ? .25 : -1.1), 5, 100);
        d.supply = clamp(num(d.supply) - (TYPES[d.type].supply * (F.supply < 30 ? 5 : 2)), 0, 100);
        d.readiness = clamp(num(d.readiness) + (F.supply > 55 ? .3 : -1), 0, 100);
        d.equipment = clamp(num(d.equipment) - (d.type === 'armor' ? .9 : .45), 0, 100);
      });
      const casualties = assigned.reduce((a,d)=>a+num(d.losses),0);
      S.army = Math.max(0, Math.floor(num(S.army) - lossBase * Math.max(1, assigned.length) * .15));
      S.ammo = clamp(num(S.ammo, 50) - (offensive ? 1.5 : .65), 0, 100);
      S.fuel = clamp(num(S.fuel, 50) - (offensive ? 1.2 : .4), 0, 100);
      S.money = Math.max(0, num(S.money) - (18 + assigned.length * 7));
      if (M.month % 3 === 0) addLog(M, `${w.n}: ${orderLabel(order)}; фронт ${Math.round(F.progress)}%, снабжение ${Math.round(F.supply)}%, потери за месяц ${lossBase * Math.max(1, assigned.length)}`);
      if (F.supply < 20) addLog(M, `Критический кризис снабжения на фронте против ${w.n}`);
      if (assigned.some(d => d.manpower <= 0)) {
        M.divisions = M.divisions.filter(d => d.manpower > 0);
        addLog(M, `Одно из соединений на фронте против ${w.n} расформировано после потери личного состава`);
      }
      // Deliberately no automatic victory, capitulation, draw or peace timer.
      w.won = false;
    });
    M.divisions.forEach(d => { if (!d.front) { d.supply = clamp(num(d.supply) + 2, 0, 100); d.morale = clamp(num(d.morale) + .4, 0, 100); } });
    return M;
  }
  function panel(S) {
    const M = ensure(S), wars = S.wars || [];
    const divs = M.divisions.map(d => `<div class="mini"><b>${d.name}</b><small>${(TYPES[d.type]||TYPES.infantry).name} · ${Math.round(d.manpower).toLocaleString('ru-RU')} чел. · опыт ${Math.round(d.experience)}%</small><small>Мораль ${Math.round(d.morale)}% · снабжение ${Math.round(d.supply)}% · готовность ${Math.round(d.readiness)}%</small><label>Фронт <select onchange="NovariaMilitary.assignUI(${d.id},this.value)"><option value="">Резерв</option>${wars.map(w=>`<option value="${esc(w.n)}" ${d.front===w.n?'selected':''}>${esc(w.n)}</option>`).join('')}</select></label></div>`).join('') || '<p class="muted">Соединений пока нет.</p>';
    const fronts = wars.map(w => { const f=M.fronts[w.n]||{};return `<div class="mini"><b>⚔️ Фронт: ${esc(w.n)}</b><small>Положение ${Math.round(f.progress||w.p||50)}% · снабжение ${Math.round(f.supply||0)}% · мораль ${Math.round(f.morale||0)}%</small><div class="actions"><label>Авиация <select onchange="NovariaMilitary.missionUI('${esc(w.n)}','air',this.value)"><option value="support" ${f.airMission==='support'?'selected':''}>Поддержка</option><option value="patrol" ${f.airMission==='patrol'?'selected':''}>Патруль</option><option value="strategic" ${f.airMission==='strategic'?'selected':''}>Удары по промышленности</option><option value="reserve" ${f.airMission==='reserve'?'selected':''}>Резерв</option></select></label><label>Флот <select onchange="NovariaMilitary.missionUI('${esc(w.n)}','navy',this.value)"><option value="escort" ${f.navyMission==='escort'?'selected':''}>Конвои</option><option value="blockade" ${f.navyMission==='blockade'?'selected':''}>Блокада</option><option value="reserve" ${f.navyMission==='reserve'?'selected':''}>Резерв</option></select></label><button onclick="NovariaMilitary.orderUI('${esc(w.n)}','attack')">Наступать</button><button onclick="NovariaMilitary.orderUI('${esc(w.n)}','defend')">Обороняться</button><button onclick="NovariaMilitary.orderUI('${esc(w.n)}','counter')">Контрудар</button><button onclick="NovariaMilitary.orderUI('${esc(w.n)}','encircle')">Окружать</button><button onclick="NovariaMilitary.orderUI('${esc(w.n)}','hold')">Удерживать</button><button onclick="NovariaMilitary.orderUI('${esc(w.n)}','withdraw')">Отступать</button></div></div>`;}).join('') || '<p class="muted">Активных фронтов нет. Война создаёт театр автоматически.</p>';
    const types = Object.keys(TYPES).map(k=>`<option value="${k}">${TYPES[k].name} · ${TYPES[k].manpower.toLocaleString('ru-RU')} чел.</option>`).join('');
    const log = M.log.slice(0,6).map(x=>`<li>${esc(x.text)}</li>`).join('');
    return `<section class="panel wide"><h2>🎖 Военный штаб · новый движок</h2><p class="muted">Дивизионная структура, единые фронты, снабжение, мораль, боевой опыт и приказы. Мирные переговоры не запускаются автоматически.</p><div class="cards"><div class="mini"><b>Дивизии</b>${M.divisions.length}</div><div class="mini"><b>Личный состав</b>${M.divisions.reduce((a,d)=>a+d.manpower,0).toLocaleString('ru-RU')}</div><div class="mini"><b>Фронты</b>${wars.length}</div><div class="mini"><b>Свободный резерв</b>${availableManpower(S).toLocaleString('ru-RU')}</div></div><h3>Формирование соединений</h3><div class="actions"><select id="nvrDivisionType">${types}</select><button class="primary" onclick="NovariaMilitary.createUI()">Создать дивизию</button></div><h3>Фронты и приказы</h3><div class="cards">${fronts}</div><h3>Состав армии</h3><div class="cards">${divs}</div><h3>Журнал штаба</h3><ul>${log || '<li>Записей пока нет.</li>'}</ul></section>`;
  }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  const api = {
    VERSION, TYPES, ORDERS, ensure, tick, createDivision, assign, setOrder, panel,
    assignUI(id, enemy) { const S = root.NG && root.NG.S; if (!S) return; if (enemy) assign(S,id,enemy); else { const M=ensure(S),d=M.divisions.find(x=>x.id===Number(id));if(d)d.front=null; } root.NG?.save?.(); root.NG?.render?.(); },
    orderUI(enemy, order) { const S=root.NG&&root.NG.S;if(S&&setOrder(S,enemy,order)){root.NG?.save?.();root.NG?.render?.();} },
    missionUI(enemy, branch, mission) { const S=root.NG&&root.NG.S,M=S&&ensure(S),F=M&&M.fronts[enemy];if(!F)return;if(branch==='air'&&['support','patrol','strategic','reserve'].includes(mission))F.airMission=mission;if(branch==='navy'&&['escort','blockade','reserve'].includes(mission))F.navyMission=mission;root.NG?.save?.();root.NG?.render?.(); },
    createUI() { const S=root.NG&&root.NG.S,el=root.document&&root.document.getElementById('nvrDivisionType');if(!S||!el)return;const r=createDivision(S,el.value);if(!r.ok)root.NG?.toast?.(r.error);else root.NG?.toast?.('Дивизия сформирована');root.NG?.save?.();root.NG?.render?.(); }
  };
  root.NovariaMilitary = api;
})(window);
