/* Оптимизация: фоновые таймеры не работают, когда вкладка/приложение свёрнуты. */
(function(){var si=window.setInterval;window.setInterval=function(f,t){var a=[].slice.call(arguments,2);if(typeof f!=='function')return si.apply(window,arguments);return si.call(window,function(){if(document.hidden)return;f.apply(null,a)},t)}})();
