/**
 * Age of History 3 style mechanics for Novaria
 * - Province click → side panel
 * - Per-province buildings (slots, costs, time)
 * - Army stacks on provinces + move by click
 * - Multi-select mass build
 */
(function () {
  'use strict';

  // --- связь с ядром игры (game.js скрыт в замыкании, берём то, что оно отдаёт наружу) ---
  if (!Object.getOwnPropertyDescriptor(window, 'S')) {
    Object.defineProperty(window, 'S', { get() { return window.NG && window.NG.S; }, configurable: true });
  }
  const render = () => window.NG && window.NG.render && window.NG.render();
  const toast = t => (window.H && window.H.toast) ? window.H.toast(t) : console.log(t);
  const log = t => { if (window.H && window.H.log) window.H.log(t); };
  const save = () => { if (window.NG && window.NG.save) window.NG.save(); };
  const fmt = n => Math.round(n || 0).toLocaleString('ru-RU');

  // ---------- Config: province-level buildings (AoH3 style) ----------
  const PROV_BUILD = {
    farm:      { n: 'Ферма',          ic: '🌾', c: 80,  m: 4,  slot: 1, fx: r => { r.agriculture = (r.agriculture || 20) + 8; r.wealth = Math.min(100, (r.wealth || 50) + 2); } },
    factory:   { n: 'Завод',          ic: '🏭', c: 180, m: 8,  slot: 1, fx: r => { r.industry = Math.min(100, (r.industry || 40) + 10); r.wealth = Math.min(100, (r.wealth || 50) + 3); } },
    infra:     { n: 'Инфраструктура', ic: '🛣', c: 120, m: 5,  slot: 1, fx: r => { r.infra = Math.min(100, (r.infra || 50) + 12); } },
    mine:      { n: 'Шахта',          ic: '⛏', c: 150, m: 7,  slot: 1, fx: r => { r.industry = Math.min(100, (r.industry || 40) + 6); r.wealth = Math.min(100, (r.wealth || 50) + 2); } },
    barracks:  { n: 'Казармы',        ic: '🏕', c: 140, m: 6,  slot: 1, fx: r => { r.manpower = (r.manpower || 0) + 2500; } },
    fort:      { n: 'Укрепления',     ic: '🧱', c: 160, m: 6,  slot: 1, fx: r => { r.defense = (r.defense || 10) + 15; } },
    hospital:  { n: 'Больница',       ic: '🏥', c: 100, m: 5,  slot: 1, fx: r => { r.loyalty = Math.min(100, (r.loyalty || 60) + 4); r.unrest = Math.max(0, (r.unrest || 15) - 5); } },
    school:    { n: 'Школа',          ic: '🏫', c: 90,  m: 4,  slot: 1, fx: r => { r.loyalty = Math.min(100, (r.loyalty || 60) + 3); r.wealth = Math.min(100, (r.wealth || 50) + 1); } },
    power:     { n: 'Электростанция', ic: '⚡', c: 200, m: 9,  slot: 1, fx: r => { r.industry = Math.min(100, (r.industry || 40) + 5); r.infra = Math.min(100, (r.infra || 50) + 4); } },
    airfield:  { n: 'Аэродром',       ic: '🛫', c: 220, m: 8,  slot: 1, fx: r => { r.airBase = (r.airBase || 0) + 1; } }
  };

  const MAX_SLOTS_BASE = 4;

  // ---------- State helpers ----------
  function ensureProvState() {
    if (!window.S || !Array.isArray(S.regions)) return;
    S.regions.forEach((r, i) => {
      if (!r.buildings) r.buildings = [];
      if (typeof r.slots !== 'number') r.slots = MAX_SLOTS_BASE + Math.floor((r.infra || 50) / 25);
      if (typeof r.manpower !== 'number') r.manpower = Math.floor((r.pop || 500000) * 0.04);
      if (typeof r.defense !== 'number') r.defense = 10 + Math.floor((r.infra || 50) / 10);
      if (!r.queue) r.queue = []; // building queue for this province
    });
    if (!S.armies) {
      // Initial army stacks distributed across regions
      S.armies = S.regions.map((r, i) => ({
        id: 'a' + i,
        region: i,
        size: Math.floor((S.army || 40000) / Math.max(1, S.regions.length)),
        name: 'Армия «' + r.name + '»',
        morale: S.morale || 65,
        training: S.training || 55
      }));
    }
    if (!S.selectedProv && S.selectedProv !== 0) S.selectedProv = null;
    if (!S.selectedArmy) S.selectedArmy = null;
    if (!S.multiSelect) S.multiSelect = [];
  }

  function slotsUsed(r) {
    return (r.buildings || []).length + (r.queue || []).length;
  }

  function freeSlots(r) {
    return Math.max(0, (r.slots || MAX_SLOTS_BASE) - slotsUsed(r));
  }

  // ---------- Build on province ----------
  function buildOnProv(provIdx, key) {
    ensureProvState();
    const r = S.regions[provIdx];
    const B = PROV_BUILD[key];
    if (!r || !B) return toast('Неизвестная постройка');
    if (freeSlots(r) < B.slot) return toast('Нет свободных слотов в провинции');
    if (S.money < B.c) return toast('Недостаточно денег (' + B.c + ' млн)');
    S.money -= B.c;
    r.queue.push({ t: key, left: B.m, m: B.m });
    log(B.ic + ' В провинции «' + r.name + '» начато: ' + B.n + ' (' + B.m + ' мес.)');
    toast(B.ic + ' ' + B.n + ' → ' + r.name);
    save();
    render();
  }

  function massBuild(key) {
    ensureProvState();
    const B = PROV_BUILD[key];
    if (!B) return;
    const targets = (S.multiSelect && S.multiSelect.length) ? S.multiSelect.slice() : (S.selectedProv != null ? [S.selectedProv] : []);
    if (!targets.length) return toast('Сначала выберите провинции');
    let ok = 0;
    targets.forEach(i => {
      const r = S.regions[i];
      if (!r || freeSlots(r) < B.slot || S.money < B.c) return;
      S.money -= B.c;
      r.queue.push({ t: key, left: B.m, m: B.m });
      ok++;
    });
    if (ok) {
      log(B.ic + ' Массовое строительство «' + B.n + '»: ' + ok + ' провинций');
      toast(B.ic + ' Построено заказов: ' + ok);
      save();
      render();
    } else toast('Не удалось построить ни в одной провинции');
  }

  // ---------- Army management ----------
  function selectArmy(id) {
    ensureProvState();
    S.selectedArmy = (S.selectedArmy === id) ? null : id;
    S.selectedProv = null;
    render();
  }

  function moveArmyTo(provIdx) {
    ensureProvState();
    if (!S.selectedArmy) return toast('Сначала выберите армию');
    const a = S.armies.find(x => x.id === S.selectedArmy);
    if (!a) return;
    if (a.region === provIdx) return toast('Армия уже здесь');
    const from = S.regions[a.region];
    const to = S.regions[provIdx];
    a.region = provIdx;
    log('⚔ ' + a.name + ' перемещена: ' + (from ? from.name : '?') + ' → ' + (to ? to.name : '?'));
    toast('⚔ Армия прибыла в «' + (to ? to.name : '') + '»');
    S.selectedArmy = null;
    save();
    render();
  }

  function recruitInProv(provIdx, amount) {
    ensureProvState();
    amount = amount || 5000;
    const r = S.regions[provIdx];
    if (!r) return;
    const cost = Math.floor(amount * 0.08);
    if (S.money < cost) return toast('Нужно ' + cost + ' млн');
    if ((r.manpower || 0) < amount) return toast('Недостаточно резерва в провинции');
    S.money -= cost;
    r.manpower -= amount;
    S.army = (S.army || 0) + amount;
    let a = S.armies.find(x => x.region === provIdx);
    if (a) a.size += amount;
    else {
      a = { id: 'a' + Date.now(), region: provIdx, size: amount, name: 'Корпус «' + r.name + '»', morale: 60, training: 40 };
      S.armies.push(a);
    }
    log('🪖 Призвано ' + amount + ' в «' + r.name + '»');
    toast('🪖 +' + amount + ' войск');
    save();
    render();
  }

  // ---------- Tick: progress province queues ----------
  function provBuildTick() {
    if (!window.S || !Array.isArray(S.regions)) return;
    ensureProvState();
    S.regions.forEach(r => {
      if (!r.queue || !r.queue.length) return;
      r.queue = r.queue.filter(q => {
        q.left--;
        if (q.left > 0) return true;
        const B = PROV_BUILD[q.t];
        if (B) {
          r.buildings.push(q.t);
          if (B.fx) B.fx(r);
          log(B.ic + ' В «' + r.name + '» построено: ' + B.n);
          toast(B.ic + ' ' + B.n + ' готово');
        }
        return false;
      });
      // Extra slots from infra
      r.slots = MAX_SLOTS_BASE + Math.floor((r.infra || 50) / 25);
    });
  }

  // ---------- UI: Province panel (AoH3 style) ----------
  function provincePanelHtml(idx) {
    ensureProvState();
    const r = S.regions[idx];
    if (!r) return '';
    const used = slotsUsed(r);
    const free = freeSlots(r);
    const armiesHere = (S.armies || []).filter(a => a.region === idx);
    const bldList = (r.buildings || []).map(k => {
      const B = PROV_BUILD[k];
      return B ? `<span class="aoh-bld-chip" title="${B.n}">${B.ic}</span>` : '';
    }).join('');
    const queueList = (r.queue || []).map(q => {
      const B = PROV_BUILD[q.t];
      return B ? `<div class="aoh-queue-item">${B.ic} ${B.n} <small>${q.left}/${q.m} мес.</small></div>` : '';
    }).join('');

    let buildBtns = Object.keys(PROV_BUILD).map(k => {
      const B = PROV_BUILD[k];
      const dis = free < B.slot || S.money < B.c;
      return `<button class="aoh-build-btn${dis ? ' dim' : ''}" onclick="AOH.build(${idx},'${k}')" ${dis ? 'disabled' : ''}>
        <span class="ic">${B.ic}</span>
        <span class="nm">${B.n}</span>
        <span class="cost">💰${B.c} · ${B.m}м</span>
      </button>`;
    }).join('');

    const armyBlock = armiesHere.length
      ? armiesHere.map(a => `
          <div class="aoh-army-row ${S.selectedArmy === a.id ? 'on' : ''}" onclick="AOH.selectArmy('${a.id}')">
            <b>⚔ ${a.name}</b>
            <span>${fmt(a.size)} чел. · дух ${a.morale}%</span>
            <small>Клик = выбрать для перемещения</small>
          </div>`).join('')
      : '<p class="muted">Нет войск в провинции</p>';

    return `
      <div class="aoh-prov-panel" id="aohProvPanel">
        <div class="aoh-prov-head">
          <button class="aoh-close" onclick="AOH.closeProv()">✕</button>
          <h3>📍 ${r.name}</h3>
          <div class="aoh-prov-stats">
            <span>👥 ${fmt(r.pop)}</span>
            <span>🏭 ${Math.round(r.industry || 0)}%</span>
            <span>🛣 ${Math.round(r.infra || 0)}%</span>
            <span>❤ ${Math.round(r.loyalty || 0)}%</span>
            <span>🛡 ${Math.round(r.defense || 10)}</span>
            <span>🎖 резерв ${fmt(r.manpower || 0)}</span>
          </div>
          <div class="aoh-slots">Слоты: <b>${used}/${r.slots || MAX_SLOTS_BASE}</b> (свободно ${free})</div>
          <div class="aoh-bld-row">${bldList || '<span class="muted">Нет зданий</span>'}</div>
        </div>
        <div class="aoh-section">
          <h4>🏗 Строительство</h4>
          <div class="aoh-build-grid">${buildBtns}</div>
          ${queueList ? `<div class="aoh-queue"><b>В очереди:</b>${queueList}</div>` : ''}
        </div>
        <div class="aoh-section">
          <h4>⚔ Войска</h4>
          ${armyBlock}
          <div class="aoh-actions">
            <button class="good" onclick="AOH.recruit(${idx},5000)">🪖 Призвать 5 000 · 400 млн</button>
            <button onclick="AOH.recruit(${idx},15000)">🪖 Призвать 15 000 · 1200 млн</button>
          </div>
          ${S.selectedArmy ? `<p class="aoh-hint">Выбрана армия — нажмите на другую провинцию, чтобы переместить</p>` : ''}
        </div>
        <div class="aoh-section">
          <h4>📦 Массовое строительство</h4>
          <p class="muted">Отметьте провинции (чекбоксы на карте) или стройте в текущей</p>
          <div class="aoh-mass">
            ${['factory','farm','infra','barracks','fort'].map(k => {
              const B = PROV_BUILD[k];
              return `<button onclick="AOH.massBuild('${k}')">${B.ic} ${B.n}</button>`;
            }).join('')}
          </div>
        </div>
      </div>`;
  }

  // ---------- UI: Regions map with click ----------
  function aohRegionsHtml() {
    ensureProvState();
    const multi = S.multiSelect || [];
    const cards = S.regions.map((r, i) => {
      const used = slotsUsed(r);
      const free = freeSlots(r);
      const armies = (S.armies || []).filter(a => a.region === i);
      const armySz = armies.reduce((s, a) => s + a.size, 0);
      const sel = S.selectedProv === i;
      const inMulti = multi.indexOf(i) >= 0;
      const bldIcons = (r.buildings || []).slice(0, 6).map(k => (PROV_BUILD[k] || {}).ic || '•').join('');
      return `
        <div class="aoh-region-card ${sel ? 'selected' : ''} ${inMulti ? 'multi' : ''}" data-idx="${i}">
          <label class="aoh-check" onclick="event.stopPropagation()">
            <input type="checkbox" ${inMulti ? 'checked' : ''} onchange="AOH.toggleMulti(${i}, this.checked)">
          </label>
          <div class="aoh-region-body" onclick="AOH.openProv(${i})">
            <div class="aoh-region-title">
              <b>${r.name}</b>
              ${r.enemyOccupied ? '<span class="dn">⚑ оккуп.</span>' : ''}
            </div>
            <div class="aoh-region-meta">
              👥 ${fmt(r.pop)} · 🏭 ${Math.round(r.industry || 0)}% · 🛣 ${Math.round(r.infra || 0)}%
            </div>
            <div class="aoh-region-meta">
              Слоты ${used}/${r.slots || MAX_SLOTS_BASE} · ${bldIcons || '—'}
            </div>
            <div class="aoh-region-army">
              ${armySz ? '⚔ ' + fmt(armySz) : '<span class="muted">нет войск</span>'}
              ${S.selectedArmy && armies.some(a => a.id === S.selectedArmy) ? ' ← выбрана' : ''}
            </div>
          </div>
          ${S.selectedArmy && !armies.some(a => a.id === S.selectedArmy) ? `
            <button class="aoh-move-btn" onclick="event.stopPropagation();AOH.moveArmy(${i})">➡ Переместить сюда</button>
          ` : ''}
        </div>`;
    }).join('');

    const panel = (S.selectedProv != null) ? provincePanelHtml(S.selectedProv) : `
      <div class="aoh-prov-panel aoh-empty">
        <h3>🗺 Карта провинций</h3>
        <p>Нажмите на провинцию, чтобы открыть панель строительства и войск — как в Age of History 3.</p>
        <p class="muted">Отметьте несколько провинций галочками для массового строительства.</p>
        ${S.selectedArmy ? '<p class="aoh-hint">⚔ Армия выбрана — нажмите «Переместить сюда» на нужной провинции</p>' : ''}
      </div>`;

    return `
      <div class="aoh-layout">
        <div class="aoh-map-side">
          <div class="aoh-toolbar">
            <button onclick="AOH.clearMulti()">Сбросить выбор</button>
            <button class="good" onclick="AOH.selectAll()">Выбрать все</button>
            <span class="muted">Выбрано: ${(S.multiSelect || []).length}</span>
          </div>
          <div class="aoh-region-grid">${cards}</div>
        </div>
        <div class="aoh-panel-side">${panel}</div>
      </div>`;
  }

  // ---------- Public API ----------
  window.AOH = {
    openProv(i) {
      ensureProvState();
      if (S.selectedArmy) {
        // If army selected, treat click as move target
        moveArmyTo(i);
        return;
      }
      S.selectedProv = i;
      render();
    },
    closeProv() {
      S.selectedProv = null;
      render();
    },
    build(i, k) { buildOnProv(i, k); },
    massBuild(k) { massBuild(k); },
    selectArmy(id) { selectArmy(id); },
    moveArmy(i) { moveArmyTo(i); },
    recruit(i, n) { recruitInProv(i, n); },
    toggleMulti(i, on) {
      ensureProvState();
      const arr = S.multiSelect || (S.multiSelect = []);
      const pos = arr.indexOf(i);
      if (on && pos < 0) arr.push(i);
      if (!on && pos >= 0) arr.splice(pos, 1);
      render();
    },
    clearMulti() {
      S.multiSelect = [];
      render();
    },
    selectAll() {
      ensureProvState();
      S.multiSelect = S.regions.map((_, i) => i);
      render();
    },
    html: aohRegionsHtml,
    tick: provBuildTick,
    ensure: ensureProvState
  };

  // Hook into monthly tick if possible
  const prevTick = window.buildTick;
  // We call from game loop via patch below

  console.log('[AOH3] Province / army module loaded');
})();
