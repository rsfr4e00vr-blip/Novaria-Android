/* aoh4: механики в духе Age of History 3 поверх существующих (ничего не удаляет) */
(function(){'use strict';
var DEV_MAX=5,NB={
 library:{n:'Библиотека',ic:'📚',c:110,m:5,fx:function(r){r.loyalty=Math.min(100,(r.loyalty||60)+2);r.wealth=Math.min(100,(r.wealth||50)+1)}},
 tower:{n:'Сторожевая башня',ic:'🗼',c:90,m:4,fx:function(r){r.defense=(r.defense||10)+10}},
 market:{n:'Рынок',ic:'🏪',c:130,m:5,fx:function(r){r.wealth=Math.min(100,(r.wealth||50)+5)}}
};
var fmt=function(n){return Math.round(n||0).toLocaleString('ru-RU')};
var toast=function(t){try{H.toast?H.toast(t):NG.toast(t)}catch(e){try{NG.toast(t)}catch(_){}}};
var render=function(){try{NG.render()}catch(e){}};
var save=function(){try{NG.save()}catch(e){}};
var log=function(t){try{NG.log(t)}catch(e){}};
function reg(i){return S.regions&&S.regions[i]}
function ens(){try{AOH.ensure()}catch(e){}
 (S.regions||[]).forEach(function(r){r.b2=r.b2||[];r.q2=r.q2||[];r.dev=r.dev||0});S.armies=S.armies||[]}
function used(r){return (r.buildings||[]).length+(r.queue||[]).length+r.b2.length+r.q2.length}
function armyAt(i){return S.armies.filter(function(a){return a.region===i})}

/* ---------- строительство и развитие ---------- */
function build(i,k){ens();var r=reg(i),B=NB[k];if(!r||!B)return;
 if(used(r)>=(r.slots||4))return toast('Нет свободных слотов');
 if(S.money<B.c)return toast('Недостаточно денег ('+B.c+' млн)');
 S.money-=B.c;r.q2.push({t:k,left:B.m,m:B.m});log(B.ic+' «'+r.name+'»: начато '+B.n);toast(B.ic+' '+B.n+' → '+r.name);save();render()}
function develop(i){ens();var r=reg(i);if(!r)return;if(r.dev>=DEV_MAX)return toast('Максимальное развитие');
 var c=100*(r.dev+1);if(S.money<c)return toast('Нужно '+c+' млн');S.money-=c;r.dev++;
 r.pop=Math.round((r.pop||500000)*1.04);r.wealth=Math.min(100,(r.wealth||50)+3);r.manpower=(r.manpower||0)+Math.round((r.pop||0)*.002);
 log('📈 «'+r.name+'»: развитие '+r.dev+'/'+DEV_MAX);toast('📈 Развитие '+r.dev+'/'+DEV_MAX);save();render()}

/* ---------- мобилизация и армии ---------- */
function mobilize(i,pct){ens();var r=reg(i);if(!r)return;var n=Math.floor((r.manpower||0)*pct/100);
 if(n<500)return toast('В области нет резерва');var c=Math.floor(n*.05);
 if(S.money<c)return toast('Нужно '+c+' млн');
 S.money-=c;r.manpower-=n;S.army=(S.army||0)+n;r.mob=(r.mob||0)+n;
 var a=armyAt(i).find(function(x){return !x.moving});
 if(a){a.size+=n}else S.armies.push({id:'a'+Date.now()+i,region:i,size:n,name:'Корпус «'+r.name+'»',morale:60,training:40});
 log('🪖 Мобилизация '+pct+'% в «'+r.name+'»: '+fmt(n));toast('🪖 +'+fmt(n)+' войск');save();render()}
function demob(id){ens();var a=S.armies.find(function(x){return x.id===id});if(!a||a.moving)return;
 var r=reg(a.region);if(r){r.manpower=(r.manpower||0)+a.size;r.mob=Math.max(0,(r.mob||0)-a.size)}
 S.army=Math.max(0,(S.army||0)-a.size);S.armies=S.armies.filter(function(x){return x!==a});
 if(S.selectedArmy===id)S.selectedArmy=null;log('🏳 Армия распущена: '+a.name);toast('🏳 Армия распущена, люди вернулись в резерв');save();render()}
function split(id){ens();var a=S.armies.find(function(x){return x.id===id});if(!a||a.moving||a.size<2000)return toast('Слишком мала для разделения');
 var h=Math.floor(a.size/2);a.size-=h;S.armies.push({id:'a'+Date.now(),region:a.region,size:h,name:a.name+' II',morale:a.morale,training:a.training});
 toast('✂ Армия разделена');save();render()}
function merge(id){ens();var a=S.armies.find(function(x){return x.id===id});if(!a||a.moving)return;
 var o=armyAt(a.region).find(function(x){return x!==a&&!x.moving});if(!o)return toast('Нет другой армии в области');
 var t=a.size+o.size;a.morale=Math.round((a.morale*a.size+o.morale*o.size)/t);a.training=Math.round((a.training*a.size+o.training*o.size)/t);a.size=t;
 S.armies=S.armies.filter(function(x){return x!==o});toast('🔀 Армии объединены');save();render()}
function eta(from,to){var n=S.regions.length;var d=Math.abs(from-to);return Math.max(1,Math.min(3,Math.round(d*3/Math.max(1,n-1))))}
function march(to){ens();if(!S.selectedArmy)return toast('Сначала выберите армию');
 var a=S.armies.find(function(x){return x.id===S.selectedArmy});if(!a)return;
 if(a.region===to&&!a.moving)return toast('Армия уже здесь');if(a.moving)return toast('Армия уже в пути');
 a.moving={to:to,left:eta(a.region,to)};S.selectedArmy=null;
 log('⚔ '+a.name+' выступила → «'+reg(to).name+'» ('+a.moving.left+' мес.)');toast('⚔ В пути: '+a.moving.left+' мес.');save();render()}

/* ---------- ежемесячный тик ---------- */
function tick(){ens();
 S.regions.forEach(function(r){r.q2=r.q2.filter(function(q){q.left--;if(q.left>0)return true;var B=NB[q.t];if(B){r.b2.push(q.t);B.fx(r);log(B.ic+' «'+r.name+'»: построено '+B.n);toast(B.ic+' '+B.n+' готово')}return false});
  if(r.dev)r.pop=Math.round((r.pop||0)*(1+.0004*r.dev))});
 S.armies.forEach(function(a){if(a.moving&&--a.moving.left<=0){a.region=a.moving.to;a.moving=null;log('🚩 '+a.name+' прибыла в «'+reg(a.region).name+'»');toast('🚩 Армия прибыла')}});
 var mob=S.regions.reduce(function(t,r){return t+(r.mob||0)},0);if(mob)S.money-=Math.round(mob/1000*.5)}

/* ---------- блок в панели области ---------- */
function block(i){var r=reg(i);if(!r)return '';var h='<div class="a4"><h4>📈 Развитие и здания</h4><div class="lvl">Развитие: '+'★'.repeat(r.dev)+'☆'.repeat(DEV_MAX-r.dev)+' · доп. здания: '+(r.b2.map(function(k){return NB[k].ic}).join('')||'—')+(r.q2.length?' · строится: '+r.q2.map(function(q){return NB[q.t].ic+q.left}).join(' '):'')+'</div><div class="row">';
 h+='<button class="good" onclick="AOH4.develop('+i+')" '+(r.dev>=DEV_MAX?'disabled':'')+'>📈 Развитие<small>'+(r.dev>=DEV_MAX?'макс.':100*(r.dev+1)+' млн')+'</small></button>';
 Object.keys(NB).forEach(function(k){var B=NB[k];h+='<button onclick="AOH4.build('+i+",'"+k+'\')" '+((used(r)>=(r.slots||4)||S.money<B.c)?'disabled':'')+'>'+B.ic+' '+B.n+'<small>'+B.c+' млн · '+B.m+' мес</small></button>'});
 h+='</div></div><div class="a4"><h4>🪖 Мобилизация (резерв '+fmt(r.manpower)+')</h4><div class="row">';
 [10,25,50].forEach(function(p){h+='<button onclick="AOH4.mobilize('+i+','+p+')">'+p+'%<small>'+fmt((r.manpower||0)*p/100)+'</small></button>'});
 h+='</div></div><div class="a4"><h4>⚔ Армии в области</h4>';
 var al=armyAt(i);if(!al.length)h+='<div class="lvl">Нет войск</div>';
 al.forEach(function(a){h+='<div class="arm"><b>'+a.name+' · '+fmt(a.size)+'</b>'+(a.moving?'<span class="mv">🚶 в пути → '+reg(a.moving.to).name+', '+a.moving.left+' мес.</span>':'<div class="row"><button onclick="AOH.selectArmy(\''+a.id+'\')">'+(S.selectedArmy===a.id?'✔ выбрана':'➡ Двигать')+'</button><button onclick="AOH4.split(\''+a.id+'\')">✂ Разделить</button><button onclick="AOH4.merge(\''+a.id+'\')">🔀 Слить</button><button onclick="AOH4.demob(\''+a.id+'\')">🏳 Распустить</button></div>')+'</div>'});
 if(S.selectedArmy)h+='<div class="lvl mv">Выбрана армия: нажмите другую область (⚔ на карте или чип сверху)</div>';
 return h+'</div>'}
var oh=AOH.html,ot=AOH.tick,oo=AOH.openProv,om=AOH.moveArmy;
AOH.html=function(){ens();var s=oh();if(S.selectedProv==null)return s;
 var d=document.createElement('div');d.innerHTML=s;var p=d.querySelector('.aoh-panel-side .aoh-prov-panel')||d.querySelector('.aoh-panel-side');
 if(p)p.insertAdjacentHTML('beforeend',block(S.selectedProv));return d.innerHTML};
AOH.tick=function(){ot();tick()};
AOH.openProv=function(i){ens();if(S.selectedArmy){var a=S.armies.find(function(x){return x.id===S.selectedArmy});if(a&&!a.moving)return march(i)}oo(i)};
AOH.moveArmy=function(i){march(i)};
window.AOH4={build:build,develop:develop,mobilize:mobilize,demob:demob,split:split,merge:merge,march:march,tick:tick,NB:NB};

/* ---------- защита от случайных нажатий на страны ---------- */
var chip=document.createElement('div');chip.id='a4chip';chip.hidden=true;document.body.appendChild(chip);
var pend=null,tm=0;function hide(){chip.hidden=true;pend=null;clearTimeout(tm)}
var occ=H.cc;window.__a6occ=function(iso){occ(iso)};
H.cc=function(iso){var nm=iso;try{nm=window.GEO.c[iso].name||iso}catch(e){}
 var own=window.S&&(nm===S.name||iso===S.iso);
 if(!own&&window.A6){hide();return A6.show(iso,nm)}
 if(own){hide();if(window.A5&&A5.active())return;var d=document.getElementById('dock');if(d&&d.hidden)document.getElementById('dockb').click();return}
 if(pend===iso){hide();return occ(iso)}
 pend=iso;chip.innerHTML='<span>🌍 '+nm+'</span><button id="a4go">Открыть</button><button class="x" id="a4x">✕</button>';chip.hidden=false;
 document.getElementById('a4go').onclick=function(e){e.stopPropagation();hide();occ(iso)};document.getElementById('a4x').onclick=function(e){e.stopPropagation();hide()};
 clearTimeout(tm);tm=setTimeout(hide,3500)};
window.A4={hide:hide};

/* подсказка при старте (один раз) */
setTimeout(function(){try{if(localStorage.getItem('a4hint'))return;localStorage.setItem('a4hint','1')}catch(e){}
 toast('Нажмите на свою область на карте — откроется панель: войска, мобилизация, стройка')},4000);
console.log('[AOH4] loaded');
})();
