/* Novaria Stage 19: country events and domestic politics.
 * Works on the existing campaign state; no replacement of economy, elections or diplomacy.
 */
(function(root){
 'use strict';
 const clamp=(v,a=0,b=100)=>Math.max(a,Math.min(b,Number(v)||0));
 const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
 const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const monthOf=S=>Math.max(0,num(S.year,1)*12+num(S.month,0));
 const hash=s=>{let h=2166136261;for(let i=0;i<String(s).length;i++){h^=String(s).charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0};
 const roll=(seed,mod)=>((Math.imul(seed>>>0,1664525)+1013904223)>>>0)%mod;
 function ensurePlayer(S){
  if(!S||typeof S!=='object')throw new Error('Игровое состояние не передано');
  let D=S.domesticPolitics;
  if(!D||typeof D!=='object')D=S.domesticPolitics={};
  D.version=1;D.events=Array.isArray(D.events)?D.events:[];
  D.history=Array.isArray(D.history)?D.history:[];
  D.effects=Array.isArray(D.effects)?D.effects:[];
  D.cooldowns=D.cooldowns&&typeof D.cooldowns==='object'?D.cooldowns:{};
  D.instability=clamp(D.instability==null?100-num(S.stability,60):D.instability);
  D.popularity=clamp(D.popularity==null?num(S.approval,50):D.popularity);
  D.lastEventMonth=num(D.lastEventMonth,-24);
  D.protests=num(D.protests,0);D.strikes=num(D.strikes,0);D.reforms=num(D.reforms,0);
  D.lastDefeatMonth=num(D.lastDefeatMonth,-9999);
  return D;
 }
 function addHistory(D,text,month){D.history.unshift({text:String(text),month});D.history=D.history.slice(0,30)}
 function active(D,type,month){return D.effects.some(e=>e.type===type&&e.until>month)}
 function addEffect(D,type,title,months,mods,month){
  D.effects=D.effects.filter(e=>e.type!==type);
  D.effects.push({type,title,until:month+months,mods:mods||{}});
 }
 function applyEffects(S,D){
  const month=monthOf(S),keep=[];
  D.effects.forEach(e=>{
   if(e.until<=month){addHistory(D,'Завершилось временное событие: '+e.title,month);return}
   keep.push(e);
   if(e.mods.gdp)S.gdp=Math.max(100,num(S.gdp,100)* (1+e.mods.gdp/100));
   if(e.mods.employment)S.employment=clamp(num(S.employment,90)+e.mods.employment);
   if(e.mods.inflation)S.inflation=clamp(num(S.inflation)+e.mods.inflation);
   if(e.mods.stability)S.stability=clamp(num(S.stability,50)+e.mods.stability);
   if(e.mods.approval)S.approval=clamp(num(S.approval,50)+e.mods.approval);
   if(e.mods.money)S.money=num(S.money)+e.mods.money;
   if(e.mods.unrest) (S.regions||[]).forEach(r=>r.unrest=clamp(num(r.unrest)+e.mods.unrest));
  });
  D.effects=keep;
 }
 const UNIQUE=[
  {id:'industrial',title:'Национальная промышленная программа',text:'В стране обсуждается ускоренное развитие промышленности и рабочих мест.',a:'Запустить программу',b:'Сосредоточиться на бюджете',cost:900,mods:[{gdp:1.2,employment:1,approval:1},{stability:1,money:350}]},
  {id:'regional',title:'Требования регионов',text:'Региональные администрации требуют больше инвестиций и полномочий.',a:'Выделить региональные средства',b:'Сохранить централизацию',cost:600,mods:[{stability:2,approval:2,unrest:-5},{money:250,stability:-1,unrest:3}]},
  {id:'education',title:'Образовательная инициатива',text:'Университеты и предприятия предлагают совместную программу подготовки специалистов.',a:'Поддержать инициативу',b:'Отложить финансирование',cost:500,mods:[{employment:1.5,approval:1},{stability:-.5,money:150}]},
  {id:'trade',title:'Внешнеторговое соглашение',text:'Деловые круги предлагают укрепить торговые связи с соседями.',a:'Поддержать переговоры',b:'Сохранить осторожность',cost:300,mods:[{gdp:.5,approval:1},{stability:.5}]}
 ];
 function eventFor(S,D,month){
  const name=S.name||S.me||'Новария',seed=hash(name+':'+month+':'+D.reforms+':'+D.history.length);
  let e=UNIQUE[roll(seed,UNIQUE.length)];
  const title=e.title+' · '+name;
  return {id:'country-'+month+'-'+e.id,kind:'national',title,text:e.text,a:e.a,b:e.b,cost:e.cost,
   choices:e.mods.map((m,i)=>({label:i===0?e.a:e.b,mods:m})),created:month,expires:month+3,seed};
 }
 function queue(S,D,e){
  if(D.events.some(x=>x.id===e.id))return;
  D.events.unshift(e);D.events=D.events.slice(0,8);
  addHistory(D,'Новое событие: '+e.title,monthOf(S));
 }
 function choose(S,id,index,automatic){
  const D=ensurePlayer(S),e=D.events.find(x=>x.id===id);
  if(!e)return {ok:false,reason:'Событие уже завершено'};
  const c=e.choices&&e.choices[index];if(!c)return {ok:false,reason:'Неизвестное решение'};
  const cost=Math.max(0,num(e.cost));
  if(!automatic&&num(S.money)<cost)return {ok:false,reason:'Недостаточно средств в казне'};
  if(cost)S.money=Math.max(0,num(S.money)-cost);
  const m=c.mods||{};
  if(m.gdp)S.gdp=Math.max(100,num(S.gdp,100)*(1+m.gdp/100));
  if(m.employment)S.employment=clamp(num(S.employment,90)+m.employment);
  if(m.inflation)S.inflation=clamp(num(S.inflation)+m.inflation);
  if(m.stability)S.stability=clamp(num(S.stability,50)+m.stability);
  if(m.approval)S.approval=clamp(num(S.approval,50)+m.approval);
  if(m.money)S.money=num(S.money)+m.money;
  if(m.unrest)(S.regions||[]).forEach(r=>r.unrest=clamp(num(r.unrest)+m.unrest));
  D.popularity=clamp(num(S.approval,50));D.instability=clamp(100-num(S.stability,50));
  D.events=D.events.filter(x=>x.id!==id);
  addHistory(D,'Решение: '+e.title+' — '+c.label,monthOf(S));
  if(!automatic&&root.NovariaDomesticPolitics&&root.NovariaDomesticPolitics.onDecision)root.NovariaDomesticPolitics.onDecision(S,e,c);
  return {ok:true,event:e,choice:c};
 }
 function action(S,action){
  const D=ensurePlayer(S),month=monthOf(S),cd=num(D.cooldowns[action]);
  if(cd>month)return {ok:false,reason:'Это решение пока недоступно'};
  const actions={
   reform:{label:'Провести административную реформу',cost:700,cooldown:18,run:()=>{S.tech=clamp(num(S.tech)+3);S.employment=clamp(num(S.employment)+1.5);S.approval=clamp(num(S.approval)-1);S.stability=clamp(num(S.stability)+1);D.reforms++;}},
   welfare:{label:'Расширить социальную поддержку',cost:650,cooldown:12,run:()=>{S.approval=clamp(num(S.approval)+3);S.stability=clamp(num(S.stability)+1);S.money-=0;addEffect(D,'welfare','Социальная программа',6,{money:-45,approval:.25},month)}},
   austerity:{label:'Ввести бюджетную экономию',cost:0,cooldown:12,run:()=>{S.money+=450;S.approval=clamp(num(S.approval)-2);S.stability=clamp(num(S.stability)-1);S.inflation=clamp(num(S.inflation)-.5);}},
   dialogue:{label:'Начать диалог с профсоюзами',cost:250,cooldown:8,run:()=>{S.stability=clamp(num(S.stability)+2);S.approval=clamp(num(S.approval)+1);(S.regions||[]).forEach(r=>r.unrest=clamp(num(r.unrest)-3));D.strikes=Math.max(0,D.strikes-1)}},
   security:{label:'Усилить защиту конституционного строя',cost:400,cooldown:12,run:()=>{S.coupRisk=clamp(num(S.coupRisk)-12);S.stability=clamp(num(S.stability)+1);S.approval=clamp(num(S.approval)-.5)}}
  };
  const a=actions[action];if(!a)return {ok:false,reason:'Неизвестное политическое решение'};
  if(num(S.money)<a.cost)return {ok:false,reason:'Недостаточно средств в казне'};
  S.money-=a.cost;a.run();D.cooldowns[action]=month+a.cooldown;
  addHistory(D,a.label,month);D.popularity=clamp(num(S.approval));D.instability=clamp(100-num(S.stability));
  return {ok:true,label:a.label,cost:a.cost};
 }
 function tickPlayer(S){
  if(!S||S.campaignOver)return null;
  const D=ensurePlayer(S),month=monthOf(S),name=S.name||S.me||'Новария';
  applyEffects(S,D);
  const inflation=num(S.inflation),approval=num(S.approval,50),stability=num(S.stability,50);
  const avgUnrest=(S.regions||[]).length?(S.regions||[]).reduce((a,r)=>a+num(r.unrest),0)/(S.regions||[]).length:0;
  const debtRatio=num(S.debt)/Math.max(1,num(S.gdp,1));
  const deficit=num(S.money)<=0;
  D.instability=clamp(100-stability+Math.max(0,approval<40?40-approval:0)*.35+Math.max(0,inflation-12)*.6+avgUnrest*.12);
  D.popularity=clamp(approval);
  if(inflation>=24&&month%3===0&&!active(D,'inflation-protest',month)){
   queue(S,D,{id:'inflation-protest-'+month,kind:'protest',title:'Протесты из-за роста цен',text:'Рост стоимости жизни вызвал массовые акции недовольства.',a:'Открыть переговоры',b:'Ограничить акции',cost:250,choices:[{label:'Открыть переговоры',mods:{approval:2,stability:1,inflation:-1,unrest:-4}},{label:'Ограничить акции',mods:{stability:-2,approval:-3,unrest:5}}],created:month,expires:month+2});
   addEffect(D,'inflation-protest','Общественное недовольство ценами',3,{approval:-.35,stability:-.2},month);
  } else if((approval<32||avgUnrest>58)&&month%4===0&&!active(D,'protest',month)){
   queue(S,D,{id:'protest-'+month,kind:'protest',title:'Массовые протесты',text:'Недовольство политикой правительства переросло в уличные протесты.',a:'Пойти на уступки',b:'Усилить порядок',cost:300,choices:[{label:'Пойти на уступки',mods:{approval:3,stability:2,unrest:-8,money:-150}},{label:'Усилить порядок',mods:{approval:-2,stability:-1,unrest:4}}],created:month,expires:month+2});
   addEffect(D,'protest','Массовые протесты',2,{approval:-.5,stability:-.35,unrest:1.5},month);
  }
  if((num(S.employment,90)<82||avgUnrest>65)&&month%5===0&&!active(D,'strike',month)){
   queue(S,D,{id:'strike-'+month,kind:'strike',title:'Забастовка работников',text:'Работники ключевых отраслей требуют улучшения условий труда.',a:'Заключить соглашение',b:'Отказать профсоюзам',cost:400,choices:[{label:'Заключить соглашение',mods:{approval:2,stability:1,employment:1,unrest:-6,money:-200}},{label:'Отказать профсоюзам',mods:{gdp:-.8,approval:-2,stability:-2,unrest:6}}],created:month,expires:month+2});
   D.strikes++;addEffect(D,'strike','Забастовка в ключевых отраслях',2,{gdp:-.25,employment:-.2},month);
  }
  if(num(S.warDefeats)>D.lastDefeatMonth&&num(S.warDefeats)>0){
   D.lastDefeatMonth=num(S.warDefeats);
   queue(S,D,{id:'defeat-'+month,kind:'defeat',title:'Политические последствия военного поражения',text:'Поражение на фронте вызвало критику командования и правительства.',a:'Провести расследование',b:'Поддержать командование',cost:350,choices:[{label:'Провести расследование',mods:{approval:2,stability:1,money:-200}},{label:'Поддержать командование',mods:{approval:-1,stability:-1}}],created:month,expires:month+3});
  }
  if(deficit&&debtRatio>.18&&month%4===0&&!active(D,'budget-crisis',month)){
   queue(S,D,{id:'budget-'+month,kind:'crisis',title:'Бюджетный кризис',text:'Дефицит бюджета и растущий долг усиливают давление на правительство.',a:'Сократить расходы',b:'Поддержать экономику',cost:0,choices:[{label:'Сократить расходы',mods:{inflation:-.7,stability:-1,approval:-2,money:500}},{label:'Поддержать экономику',mods:{gdp:.4,approval:1,money:-350}}],created:month,expires:month+2});
   addEffect(D,'budget-crisis','Бюджетный кризис',3,{approval:-.3,stability:-.25},month);
  }
  if(num(S.coupRisk)>84&&stability<38&&month%3===0&&!active(D,'coup',month)&&!D.events.some(e=>e.kind==='coup')){
   queue(S,D,{id:'coup-'+month,kind:'coup',title:'Заговор против правительства',text:'Часть силовых и политических элит обсуждает попытку отстранения правительства.',a:'Провести политический компромисс',b:'Объявить чрезвычайные меры',cost:500,choices:[{label:'Политический компромисс',mods:{stability:3,approval:2}},{label:'Чрезвычайные меры',mods:{stability:-2,approval:-3}}],created:month,expires:month+2});
   addEffect(D,'coup','Политический заговор',2,{stability:-.5},month);
  }
  if(D.events.length===0&&month-D.lastEventMonth>=8){
   const seed=hash(name+':'+month+':'+num(S.gdp)+':'+D.reforms);
   if(roll(seed,100)<23){queue(S,D,eventFor(S,D,month));D.lastEventMonth=month}
  }
  D.events=D.events.filter(e=>{
   if(e.expires>month)return true;
   if(e.kind==='coup'&&num(S.coupRisk)>90&&num(S.stability)<25){
    S.gov='Военное правление';S.martial=true;S.coupRisk=30;
    S.stability=clamp(num(S.stability)-8);S.approval=clamp(num(S.approval)-5);
    addHistory(D,'Переворот: правительство отстранено, установлено военное правление',month);
   }else addHistory(D,'Событие завершилось без решения: '+e.title,month);
   return false;
  });
  // A prolonged domestic crisis raises diplomatic friction and weakens confidence.
  if(D.instability>70&&month%6===0){
   S.trust=clamp(num(S.trust,70)-.6);
   (S.relations||[]).forEach(r=>{if(!r.self)r.value=clamp(num(r.value)-.25,-100,100)});
  }
  D.popularity=clamp(num(S.approval));D.instability=clamp(100-num(S.stability));
  return {instability:D.instability,popularity:D.popularity,events:D.events.length};
 }
 function tickWorld(S,W,A){
  if(!W||!Array.isArray(A))return;
  const month=num(W.month);
  A.forEach(n=>{
   if(!n||n.annexed)return;
   const D=n.domesticPolitics||(n.domesticPolitics={version:1,events:[],effects:[],history:[],lastEventMonth:-24});
   D.events=Array.isArray(D.events)?D.events:[];D.effects=Array.isArray(D.effects)?D.effects:[];
   D.history=Array.isArray(D.history)?D.history:[];D.lastEventMonth=num(D.lastEventMonth,-24);
   const stability=clamp(num(n.stability,55)),debt=num(n.debt),gdp=Math.max(1,num(n.gdp,1));
   D.instability=clamp(100-stability+Math.max(0,25-stability)*.7+num(n.exhaustion)*.15);
   D.popularity=clamp(num(n.approval,stability-5));
   const seed=hash(n.name+':ai:'+month+':'+Math.round(gdp/100));
   if((stability<34||num(n.exhaustion)>65)&&month%5===0&&!D.events.some(e=>e.kind==='protest')){
    D.events.push({id:'ai-protest-'+month,kind:'protest',title:'Протесты в '+n.name,text:'Общественное недовольство усиливает внутреннее давление.',created:month,expires:month+2});
    D.effects.push({type:'ai-protest',until:month+2,mods:{stability:-.5}});
   }
   if(debt>gdp*.35&&month%6===0&&!D.events.some(e=>e.kind==='crisis')){
    D.events.push({id:'ai-crisis-'+month,kind:'crisis',title:'Бюджетный кризис в '+n.name,text:'Рост государственного долга ограничивает действия правительства.',created:month,expires:month+3});
   }
   if(D.events.length===0&&month-D.lastEventMonth>=10&&roll(seed,100)<15){
    const names=['Национальная программа развития','Региональный политический спор','Реформа государственного управления','Кризис доверия к кабинету'];
    D.events.push({id:'ai-national-'+month,kind:'national',title:names[roll(seed>>>1,names.length)]+' · '+n.name,text:'Уникальное внутреннее событие государства.' ,created:month,expires:month+3});
    D.lastEventMonth=month;
   }
   // AI resolves the same event types by weighing treasury, stability and wartime pressure.
   D.events=D.events.filter(e=>{
    if(e.expires<=month)return false;
    if(e.resolved)return false;
    const cautious=num(n.treasury)>gdp*.01&&stability<55;
    if(e.kind==='protest'){if(cautious){n.treasury=Math.max(0,num(n.treasury)-gdp*.001);n.stability=clamp(num(n.stability)+1,5,96)}else n.stability=clamp(num(n.stability)-1,5,96)}
    else if(e.kind==='crisis'){if(num(n.treasury)>gdp*.005){n.treasury=Math.max(0,num(n.treasury)-gdp*.002);n.debt=Math.max(0,debt-gdp*.001)}else{n.gdp=Math.max(1,gdp*.995);n.stability=clamp(num(n.stability)-1,5,96)}}
    else if(e.kind==='national'){if(num(n.treasury)>gdp*.008&&!n.war){n.gdp=Math.max(1,gdp*1.002);n.industry=clamp(num(n.industry,1)+.01,.3,3)}else n.stability=clamp(num(n.stability)+.3,5,96)}
    e.resolved=true;D.history.unshift({text:'ИИ принял решение: '+e.title,month});return false;
   });
   D.history=D.history.slice(0,12);
   D.effects=D.effects.filter(e=>e.until>month);
  });
 }
 function panel(S){
  const D=ensurePlayer(S),month=monthOf(S),events=D.events;
  const activeEffects=D.effects.filter(e=>e.until>month);
  const metric=(name,val)=>`<div class="mini"><small>${name}</small><b>${Math.round(val)}%</b><div class="bar"><i style="width:${clamp(val)}%"></i></div></div>`;
  const eventHtml=events.length?events.map(e=>`<div class="choice"><b>${esc(e.title)}</b><p>${esc(e.text)}</p><small class="muted">Срок решения: ещё ${Math.max(0,e.expires-month)} мес.</small><div class="actions"><button class="primary" onclick="domesticChoose('${esc(e.id)}',0)"> ${esc(e.a||'Принять решение')}</button><button onclick="domesticChoose('${esc(e.id)}',1)">${esc(e.b||'Альтернативное решение')}</button></div></div>`).join(''):'<p class="muted">Новых событий нет. События возникают из экономической и политической ситуации страны.</p>';
  const effectsHtml=activeEffects.length?activeEffects.map(e=>`<div class="mini"><b>${esc(e.title)}</b><small>Осталось ${Math.max(0,e.until-month)} мес.</small></div>`).join(''):'<p class="muted">Временных кризисов и программ сейчас нет.</p>';
  const buttons=[['reform','Реформа · 700 млн'],['welfare','Социальная программа · 650 млн'],['austerity','Бюджетная экономия'],['dialogue','Диалог с профсоюзами · 250 млн'],['security','Защита строя · 400 млн']];
  const actions=buttons.map(([id,label])=>`<button onclick="domesticAction('${id}')">${label}</button>`).join('');
  const section=(title,body)=>`<section class="panel"><h2>${title}</h2>${body}</section>`;
  return `<div class="grid">${section('🏛 Внутренняя политика и события',`<p class="muted">Уникальные события страны: <b>${esc(S.name||'Новария')}</b>. Все решения меняют показатели действующей кампании.</p><div class="cards">${metric('Популярность правительства',D.popularity)}${metric('Внутренняя нестабильность',D.instability)}</div><h3>Политические решения</h3><div class="actions">${actions}</div>`)}${section('📰 События государства',eventHtml)}${section('⏳ Временные события',effectsHtml)}${section('📚 История решений',D.history.slice(0,8).map(h=>`<div class="mini">${esc(h.text)}</div>`).join('')||'<p class="muted">История пока пуста.</p>')}</div>`;
 }
 function notify(S,e,c){
  if(typeof root.log==='function')root.log('Внутренняя политика: '+e.title+' — '+c.label);
 }
 root.NovariaDomesticPolitics={ensurePlayer,tickPlayer,tickWorld,choose,action,panel,onDecision:notify};
})(window);
