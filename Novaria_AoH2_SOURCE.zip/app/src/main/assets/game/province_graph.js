/* Novaria province graph v2.0 (Этап 9).
 * Два источника соседства:
 *  1) 'geo'  — строится в браузере из геометрии, которую игра реально рисует (GEO.c[iso].rings + GEO.c[iso].regs).
 *              Провинция = область Вороного вокруг центра региона внутри контура страны (так же, как на карте).
 *              Соседи = провинции, у которых есть общая граница ненулевой длины (касание углом не считается).
 *  2) 'ne'   — готовый Natural Earth Admin-1 (генерируется в CI, если он есть).
 * Синтетических рёбер нет. Это НЕ оригинальные провинции AoH2. */
(function(root){'use strict';
 const ne=()=>root.NATURAL_EARTH_ADMIN1_ADJACENCY;
 let geoG=null,forced=null;
 const neReady=()=>{const g=ne();return !!(g&&g.version===1&&g.source!=='not-generated'&&g.neighbors&&typeof g.neighbors==='object')};
 const active=()=>forced==='ne'?(neReady()?ne():null):forced==='geo'?geoG:(geoG||(neReady()?ne():null));
 function ready(){return !!active()}
 function neighbors(id){const g=active();if(!g)return [];const a=g.neighbors[String(id)];return Array.isArray(a)?a.slice():[]}
 function areAdjacent(a,b){return neighbors(a).includes(String(b))}
 function moveCheck(from,to,ownerByProvince,armyOwner){
   if(!ready())return {ok:false,code:'MAP_GRAPH_MISSING',message:'Граф соседства провинций ещё не загружен'};
   if(!areAdjacent(from,to))return {ok:false,code:'NOT_ADJACENT',message:'Армия может перейти только в соседнюю провинцию'};
   const owner=ownerByProvince&&ownerByProvince[String(to)];
   if(owner!=null&&String(owner)!==String(armyOwner))return {ok:false,code:'ENEMY_TERRITORY',message:'Чужая провинция требует отдельного разрешения или приказа атаки'};
   return {ok:true,from:String(from),to:String(to)};
 }
 function findPath(from,to,maxNodes=20000){
   if(!ready())return {ok:false,code:'MAP_GRAPH_MISSING',path:[]};
   from=String(from);to=String(to);if(from===to)return {ok:true,path:[from]};
   const queue=[from],prev=new Map([[from,null]]);let head=0;
   while(head<queue.length&&prev.size<=maxNodes){const cur=queue[head++];for(const n of neighbors(cur)){if(prev.has(n))continue;prev.set(n,cur);if(n===to){const path=[];let p=to;while(p!==null){path.push(p);p=prev.get(p)}path.reverse();return {ok:true,path}}queue.push(n)}}
   return {ok:false,code:'NO_LAND_ROUTE',path:[]};
 }
 /* Растеризация карты: каждая клетка сетки получает индекс провинции, затем считаются общие границы. */
 function buildFromGeo(GEO,opts){
   opts=opts||{};
   if(!GEO||!GEO.c||!GEO.W||!GEO.H)return {ok:false,code:'NO_GEO'};
   const W=GEO.W,H=GEO.H,cols=opts.cols||720,step=W/cols,rows=Math.ceil(H/step),minContact=opts.minContact||2,smallPx=opts.smallPx||30;
   const grid=new Int32Array(cols*rows).fill(-1),ids=[],cnt=[];
   const countries=Object.keys(GEO.c).map(k=>GEO.c[k]).filter(C=>C&&C.rings&&C.rings.length&&C.regs&&C.regs.length);
   for(const C of countries){
     const base=ids.length;C.regs.forEach(r=>{ids.push(r.id);cnt.push(0)});
     const regs=C.regs,n=regs.length,bb=C.bb,r0=Math.max(0,Math.floor(bb[1]/step)),r1=Math.min(rows-1,Math.ceil(bb[3]/step));
     /* список рёбер по строкам: простой проход, фильтр по y */
     const edges=[];C.rings.forEach(ring=>{for(let i=0,j=ring.length-1;i<ring.length;j=i++){const a=ring[j],b=ring[i];if(a[1]!==b[1])edges.push(a[1]<b[1]?[a[0],a[1],b[0],b[1]]:[b[0],b[1],a[0],a[1]])}});
     for(let ry=r0;ry<=r1;ry++){
       const py=(ry+.5)*step,xs=[];
       for(let e=0;e<edges.length;e++){const E=edges[e];if(py>=E[1]&&py<E[3])xs.push(E[0]+(py-E[1])*(E[2]-E[0])/(E[3]-E[1]))}
       if(xs.length<2)continue;xs.sort((p,q)=>p-q);
       for(let k=0;k+1<xs.length;k+=2){
         const cx0=Math.max(0,Math.ceil(xs[k]/step-.5)),cx1=Math.min(cols-1,Math.floor(xs[k+1]/step-.5));
         for(let cx=cx0;cx<=cx1;cx++){
           const gi=ry*cols+cx;if(grid[gi]!==-1)continue;
           const px=(cx+.5)*step;let bi=0,bd=Infinity;
           for(let s=0;s<n;s++){const dx=px-regs[s].cx,dy=py-regs[s].cy,d=dx*dx+dy*dy;if(d<bd){bd=d;bi=s}}
           grid[gi]=base+bi;cnt[base+bi]++;
         }
       }
     }
   }
   const pair=new Map();
   const add=(a,b)=>{if(a<0||b<0||a===b)return;const k=a<b?a*65536+b:b*65536+a;pair.set(k,(pair.get(k)||0)+1)};
   for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){const a=grid[y*cols+x];if(a<0)continue;if(x+1<cols)add(a,grid[y*cols+x+1]);if(y+1<rows)add(a,grid[(y+1)*cols+x])}
   const nb={};ids.forEach(id=>nb[id]=[]);let borders=0;
   pair.forEach((c,k)=>{const a=Math.floor(k/65536),b=k%65536;if(c>=minContact||((cnt[a]<smallPx||cnt[b]<smallPx)&&c>=1)){nb[ids[a]].push(ids[b]);nb[ids[b]].push(ids[a]);borders++}});
   Object.keys(nb).forEach(k=>nb[k].sort());
   const isolated=ids.filter(id=>!nb[id].length).length;
   geoG={version:1,source:'novaria-geo-raster',cols,step,neighbors:nb,borders,isolated,generated:Date.now()};
   return {ok:true,regions:ids.length,borders,isolated};
 }
 root.NovariaProvinceGraph={version:2,ready,neighbors,areAdjacent,moveCheck,findPath,buildFromGeo,
   use(src){forced=(src==='ne'||src==='geo')?src:null},source(){const g=active();return g?g.source:null},
   stats(){const g=active();if(!g)return {ready:false,regions:0,borders:0};const ids=Object.keys(g.neighbors);return {ready:true,source:g.source,regions:ids.length,borders:ids.reduce((n,id)=>n+g.neighbors[id].length,0)/2,isolated:ids.filter(i=>!g.neighbors[i].length).length}},
   _reset(){geoG=null;forced=null}};
})(typeof window!=='undefined'?window:globalThis);
