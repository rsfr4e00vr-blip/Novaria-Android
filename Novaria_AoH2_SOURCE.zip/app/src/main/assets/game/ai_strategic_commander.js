/* Novaria Strategic Commander — этап 16.
 * Дополнительный стратегический слой ИИ: оценка угроз, готовности, фронта,
 * снабжения, мобилизации и условий мира. Не заменяет существующую нейросеть,
 * дипломатию или экономику; формирует объяснимые приказы поверх них.
 */
(function(root){'use strict';
 const VERSION=1, C=(v,a,b)=>Math.max(a,Math.min(b,Number(v)||0));
 const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
 const live=(n)=>n&&!n.annexed;
 const find=(A,name)=>A.find(n=>n.name===name);
 function ensure(W){
   if(!W||!Array.isArray(W.nations))return null;
   W.commander=W.commander&&W.commander.version===VERSION?W.commander:{version:VERSION,month:0,decisions:0,history:[]};
   const K=W.commander;K.history=Array.isArray(K.history)?K.history:[];
   W.nations.forEach(n=>{
     n.aiCommand=n.aiCommand&&typeof n.aiCommand==='object'?n.aiCommand:{};
     const c=n.aiCommand;
     c.posture=c.posture||'balanced'; c.readiness=C(c.readiness??50,0,100);
     c.target=c.target||null; c.lastReason=c.lastReason||'Оценка общей обстановки';
     c.lastUpdated=num(c.lastUpdated,0); c.mobilization=C(c.mobilization??0,0,3);
     c.doctrine=c.doctrine||'flexible';
   });
   return K;
 }
 function alliesPower(n,A){
   return (n.allies||[]).reduce((sum,name)=>{const a=find(A,name);return sum+(live(a)?num(a.power)*.28:0)},0);
 }
 function threatOf(n,A){
   const rivals=A.filter(x=>live(x)&&x!==n&&!((n.allies||[]).includes(x.name)))
     .map(x=>({n:x,score:num(x.power)/Math.max(1,num(n.power)) + Math.max(0,num(n.rivals&&n.rivals[x.name]))/250}))
     .sort((a,b)=>b.score-a.score);
   return rivals[0]||null;
 }
 function readiness(n){
   const treasury=C(num(n.treasury)/Math.max(1,num(n.gdp))/.025,0,1);
   const manpower=C(num(n.manpower)/Math.max(1,num(n.pop)*.035),0,1);
   const morale=C(num(n.morale,65)/100,0,1);
   const exhaustion=1-C(num(n.exhaustion)/100,0,1);
   const debt=1-C(num(n.debt)/Math.max(1,num(n.gdp))/.8,0,1);
   const supply=treasury*.25+manpower*.2+morale*.2+exhaustion*.2+debt*.15;
   return Math.round(C(supply*100,0,100));
 }
 function activeWar(W,n){
   const id=n.war;
   return (W.wars||[]).find(w=>w&&(w.id===id||w.a===n.name||w.b===n.name));
 }
 function planWar(W,n,A,w){
   const sideA=w.a===n.name, ownScore=sideA?num(w.score):-num(w.score);
   const ownFront=sideA?num(w.front,50):100-num(w.front,50);
   const enemy=find(A,sideA?w.b:w.a);
   const ratio=(num(n.power)+alliesPower(n,A))/Math.max(1,num(enemy&&enemy.power)+alliesPower(enemy||{},A));
   const ready=readiness(n), treasury=num(n.treasury)/Math.max(1,num(n.gdp));
   const losing=ownScore<=-28||ownFront<32||ratio<.68;
   const critical=ownScore<=-58||ownFront<16||ready<18||num(n.exhaustion)>88;
   const canSustain=treasury>.008&&num(n.exhaustion)<78&&ready>38;
   let posture='hold',doctrine='defensive',reason='Удержание фронта и сохранение резервов';
   if(critical){posture='withdraw';doctrine='preserve';reason='Критическое положение: сохранение армии и подготовка к миру';}
   else if(losing){posture='defend';doctrine='elastic_defense';reason='Неблагоприятное соотношение сил: укрепление обороны';}
   else if(ownScore>22&&ownFront>62&&ratio>1.12&&canSustain){posture='attack';doctrine='offensive';reason='Преимущество на фронте: развитие наступления';}
   else if(!canSustain){posture='hold';doctrine='attrition_avoidance';reason='Ограниченные ресурсы: экономия сил и снабжения';}
   else if(ownScore>0){posture='counter';doctrine='counteroffensive';reason='Положительная динамика: подготовка контрудара';}
   n.aiCommand.posture=posture;n.aiCommand.doctrine=doctrine;n.aiCommand.target=enemy?enemy.name:null;
   n.aiCommand.readiness=ready;n.aiCommand.lastReason=reason;n.aiCommand.lastUpdated=W.month;
   n.warPlan=posture==='attack'?2:posture==='counter'?1:0;
   if(critical&&num(w.months)>=3&&ownScore< -42)w.peaceReq=true;
   // Мобилизация не создаёт солдат из воздуха: она конвертирует доступный резерв и казну.
   if((posture==='defend'||posture==='withdraw'||posture==='counter')&&ready<62&&num(n.manpower)>Math.max(1,num(n.pop)*.004)){
     const cost=Math.min(num(n.treasury),num(n.gdp)*.0012);
     const recruits=Math.min(num(n.manpower)*.025,Math.max(.05,num(n.pop)*.00008));
     if(cost>num(n.gdp)*.00015&&recruits>.01){
       n.treasury=Math.max(0,num(n.treasury)-cost);n.manpower=Math.max(0,num(n.manpower)-recruits*.18);
       n.power=C(num(n.power)+recruits*.22,1,150);n.morale=C(num(n.morale,65)-.35,15,100);
       n.aiCommand.mobilization=C(num(n.aiCommand.mobilization)+.2,0,3);
     }
   }
   return {posture,reason,ready,ownScore,ratio};
 }
 function planPeaceOrDefense(W,n,A){
   const threat=threatOf(n,A), ready=readiness(n), rival=threat&&threat.n;
   let posture='balanced',reason='Сбалансированная оборонная готовность',target=null;
   if(num(n.stability)<32){posture='internal';reason='Внутренняя нестабильность: приоритет внутреннему порядку';}
   else if(num(n.debt)>num(n.gdp)*.55||num(n.treasury)<num(n.gdp)*.004){posture='economy';reason='Финансовые ограничения: отказ от рискованных военных действий';}
   else if(rival&&threat.score>1.25){
     posture='defend';target=rival.name;reason=`Угроза со стороны ${rival.name}: усиление обороны`;
     if(ready<70&&num(n.manpower)>num(n.pop)*.006&&num(n.treasury)>num(n.gdp)*.008){
       const spend=Math.min(num(n.treasury),num(n.gdp)*.0007);
       n.treasury=Math.max(0,num(n.treasury)-spend);
       n.power=C(num(n.power)+Math.min(.8,num(n.manpower)*.0008),1,150);
       n.manpower=Math.max(0,num(n.manpower)-Math.min(num(n.manpower)*.003,.2));
     }
   } else if(ready<35){posture='rebuild';reason='Низкая готовность: восстановление резервов и морали';}
   n.aiCommand.posture=posture;n.aiCommand.doctrine=posture==='defend'?'deterrence':'flexible';
   n.aiCommand.target=target;n.aiCommand.readiness=ready;n.aiCommand.lastReason=reason;n.aiCommand.lastUpdated=W.month;
   n.warPlan=posture==='defend'?0:num(n.warPlan);
   return {posture,reason,ready,target};
 }
 function tick(W,A){
   const K=ensure(W);if(!K)return;
   const month=num(W.month);
   if(K.month===month)return K;
   K.month=month;
   const nations=(A||W.nations).filter(live);
   nations.forEach(n=>{
     const w=activeWar(W,n),result=w?planWar(W,n,nations,w):planPeaceOrDefense(W,n,nations);
     if(result&&n.aiCommand){
       K.decisions++;
       if(n.aiCommand.lastLogged!==month){
         K.history.unshift({month,country:n.name,posture:result.posture,reason:result.reason,readiness:result.ready,target:result.target||null});
         n.aiCommand.lastLogged=month;
       }
     }
   });
   K.history=K.history.slice(0,120);
   return K;
 }
 function inspect(W,name){const n=find(W&&W.nations||[],name);return n?{name:n.name,...n.aiCommand}:null}
 root.NovariaStrategicAI={VERSION,ensure,tick,readiness,inspect};
})(typeof window!=='undefined'?window:globalThis);
