/* Stage 22: expandable panels for narrow Android screens. */
(function(){
 'use strict';
 var body=document.body,btn=document.createElement('button');
 btn.id='panelExpand';btn.type='button';btn.textContent='⛶';btn.title='Развернуть панель';btn.setAttribute('aria-label','Развернуть панель');
 btn.addEventListener('click',function(){
  var expanded=body.classList.toggle('panel-expanded');
  btn.textContent=expanded?'↙':'⛶';btn.title=expanded?'Свернуть панель':'Развернуть панель';
  btn.setAttribute('aria-label',btn.title);
 });
 document.body.appendChild(btn);
 function reset(){body.classList.remove('panel-expanded');btn.textContent='⛶';btn.title='Развернуть панель';btn.setAttribute('aria-label',btn.title)}
 document.querySelectorAll('#tabs [data-tab]').forEach(function(el){el.addEventListener('click',reset)});
 document.addEventListener('keydown',function(e){if(e.key==='Escape'&&body.classList.contains('panel-expanded'))reset()});
})();
