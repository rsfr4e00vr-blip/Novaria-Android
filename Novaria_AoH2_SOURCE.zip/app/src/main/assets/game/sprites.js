/* Новария: 2D-модельки солдат и вооружения (оригинальные силуэты, SVG).
   NVSPR.svg(key,px)  — строка <svg> для HTML
   NVSPR.inner(key)   — содержимое для вложенного <svg> (карта)
   NVSPR.img(key)     — Image для canvas (Театр войны)
   Ключи: soldier, tank, cannon, howitzer, mlrs, aa, drone, heli, bomber, rocket, cruise, bomb, petard */
(function () {
  'use strict';
  var O = '#1b2230', G = '#6f8450', G2 = '#566a3d', S = '#8d9bad', S2 = '#c3ccd8', Y = '#e0b64f', R = '#c9434f', K = '#2d3647';
  var st = 'stroke="' + O + '" stroke-width="1.3" stroke-linejoin="round" stroke-linecap="round"';
  var M = {
    soldier: ['0 0 32 40',
      '<ellipse cx="16" cy="38" rx="9" ry="1.6" fill="#0006"/>' +
      '<path d="M11 21l-3 14h5l3-9 3 9h5l-3-14z" fill="' + G2 + '" ' + st + '/>' +
      '<path d="M9 12q7-4 14 0l1 11q-8 3-16 0z" fill="' + G + '" ' + st + '/>' +
      '<circle cx="16" cy="9" r="4.4" fill="#e3b995" ' + st + '/>' +
      '<path d="M10.6 8.6q0-6 5.4-6t5.4 6z" fill="' + G2 + '" ' + st + '/>' +
      '<rect x="19" y="15" width="12" height="3" rx="1" fill="' + K + '" ' + st + ' transform="rotate(-18 19 16)"/>' +
      '<rect x="22" y="12" width="4" height="2" fill="' + K + '" transform="rotate(-18 19 16)"/>'],
    tank: ['0 0 48 32',
      '<rect x="3" y="20" width="42" height="9" rx="4.5" fill="' + K + '" ' + st + '/>' +
      '<circle cx="9" cy="24.5" r="2.4" fill="' + S + '"/><circle cx="17" cy="24.5" r="2.4" fill="' + S + '"/><circle cx="25" cy="24.5" r="2.4" fill="' + S + '"/><circle cx="33" cy="24.5" r="2.4" fill="' + S + '"/><circle cx="40" cy="24.5" r="2.4" fill="' + S + '"/>' +
      '<path d="M7 20l3-6h28l4 6z" fill="' + G + '" ' + st + '/>' +
      '<path d="M15 14l3-6h13l3 6z" fill="' + G2 + '" ' + st + '/>' +
      '<rect x="30" y="9.4" width="17" height="2.8" rx="1" fill="' + K + '" ' + st + '/>' +
      '<circle cx="24" cy="9" r="1.6" fill="' + Y + '"/>'],
    cannon: ['0 0 48 32',
      '<circle cx="19" cy="23" r="7" fill="' + K + '" ' + st + '/><circle cx="19" cy="23" r="2.4" fill="' + S + '"/><path d="M19 16v14M12 23h14M14 18l10 10M24 18L14 28" stroke="' + S + '" stroke-width=".9"/>' +
      '<path d="M19 23L5 29h-3" fill="none" stroke="' + O + '" stroke-width="2.6" stroke-linecap="round"/>' +
      '<rect x="18" y="12.5" width="28" height="4.6" rx="1.6" fill="' + S + '" ' + st + ' transform="rotate(-8 18 15)"/>' +
      '<path d="M14 21l3-10 5 1-1 10z" fill="' + G + '" ' + st + '/>'],
    howitzer: ['0 0 48 32',
      '<circle cx="15" cy="24" r="5" fill="' + K + '" ' + st + '/><circle cx="26" cy="24" r="5" fill="' + K + '" ' + st + '/><circle cx="15" cy="24" r="1.8" fill="' + S + '"/><circle cx="26" cy="24" r="1.8" fill="' + S + '"/>' +
      '<rect x="8" y="17" width="26" height="6" rx="2" fill="' + G + '" ' + st + '/>' +
      '<rect x="20" y="10" width="26" height="4.2" rx="1.6" fill="' + S + '" ' + st + ' transform="rotate(-24 20 13)"/>' +
      '<rect x="40" y="2.5" width="5" height="5.4" rx="1" fill="' + K + '" ' + st + ' transform="rotate(-24 20 13)"/>' +
      '<path d="M8 23l-6 5" stroke="' + O + '" stroke-width="2.4" stroke-linecap="round"/>'],
    mlrs: ['0 0 48 32',
      '<rect x="2" y="17" width="44" height="8" rx="2" fill="' + G + '" ' + st + '/>' +
      '<path d="M32 17v-6l8 0 4 6z" fill="' + G2 + '" ' + st + '/><rect x="35" y="12.5" width="4" height="3.4" fill="' + S2 + '"/>' +
      '<g transform="rotate(-24 22 16)"><rect x="4" y="9" width="26" height="9" rx="1.5" fill="' + K + '" ' + st + '/>' +
      '<circle cx="31" cy="11.3" r="1.6" fill="' + Y + '"/><circle cx="31" cy="15.7" r="1.6" fill="' + Y + '"/><circle cx="26" cy="11.3" r="1.1" fill="' + S + '"/><circle cx="26" cy="15.7" r="1.1" fill="' + S + '"/></g>' +
      '<circle cx="10" cy="27" r="3.6" fill="' + K + '" ' + st + '/><circle cx="20" cy="27" r="3.6" fill="' + K + '" ' + st + '/><circle cx="38" cy="27" r="3.6" fill="' + K + '" ' + st + '/>'],
    aa: ['0 0 48 32',
      '<rect x="3" y="20" width="42" height="6" rx="2" fill="' + G + '" ' + st + '/>' +
      '<circle cx="10" cy="28" r="3.4" fill="' + K + '" ' + st + '/><circle cx="22" cy="28" r="3.4" fill="' + K + '" ' + st + '/><circle cx="38" cy="28" r="3.4" fill="' + K + '" ' + st + '/>' +
      '<g transform="rotate(-50 20 18)"><rect x="8" y="10" width="20" height="3.2" rx="1.4" fill="' + S2 + '" ' + st + '/><rect x="8" y="14.6" width="20" height="3.2" rx="1.4" fill="' + S2 + '" ' + st + '/><path d="M28 10l3 1.6-3 1.6zM28 14.6l3 1.6-3 1.6z" fill="' + R + '"/></g>' +
      '<path d="M32 19v-5" stroke="' + O + '" stroke-width="1.6"/><ellipse cx="33.5" cy="11" rx="6" ry="2.4" fill="' + S + '" ' + st + ' transform="rotate(-25 33.5 11)"/>'],
    drone: ['0 0 48 32',
      '<path d="M22 16L8 6l5-1 15 9zM22 16L8 26l5 1 15-9z" fill="' + S + '" ' + st + '/>' +
      '<path d="M8 15l-5-6 3-1 6 6zM8 17l-5 6 3 1 6-6z" fill="' + S + '" ' + st + '/>' +
      '<path d="M4 16h26q10 0 14 2-4 3-14 3H4z" fill="' + S2 + '" ' + st + '/>' +
      '<path d="M36 17q4 0 6 1-2 1.4-6 1.4z" fill="#9fd3ff"/><circle cx="31" cy="21.6" r="1.6" fill="' + R + '"/>'],
    heli: ['0 0 48 32',
      '<path d="M4 7h40" stroke="' + O + '" stroke-width="2" stroke-linecap="round"/><path d="M24 7v4" stroke="' + O + '" stroke-width="2"/>' +
      '<path d="M6 17q0-6 10-6h10q8 0 9 6l-2 5H12z" fill="' + G + '" ' + st + '/>' +
      '<path d="M32 15l14-3v4l-14 4z" fill="' + G2 + '" ' + st + '/><path d="M44 8v10" stroke="' + O + '" stroke-width="2"/>' +
      '<path d="M12 15q3-3 8-3v5h-8z" fill="#9fd3ff" ' + st + '/>' +
      '<path d="M10 26h24M16 22v4M28 22v4" stroke="' + O + '" stroke-width="1.8" stroke-linecap="round"/><rect x="20" y="22" width="10" height="2.6" fill="' + K + '"/>'],
    bomber: ['0 0 48 32',
      '<path d="M2 16l6-2h30l8 2-8 2H8z" fill="' + S2 + '" ' + st + '/>' +
      '<path d="M24 16L12 4h6l12 12zM24 16l-12 12h6l12-12z" fill="' + S + '" ' + st + '/>' +
      '<path d="M8 14l-4-8h4l5 8zM8 18l-4 8h4l5-8z" fill="' + S + '" ' + st + '/>' +
      '<path d="M36 15.4q6 .4 8 .6-2 .4-8 .8z" fill="#9fd3ff"/><circle cx="20" cy="9" r="1.5" fill="' + K + '"/><circle cx="20" cy="23" r="1.5" fill="' + K + '"/>'],
    rocket: ['0 0 48 32',
      '<path d="M4 16l-2-6 8 3v6l-8 3z" fill="' + Y + '" ' + st + '/><path d="M10 12l6-1h18q9 0 13 5-4 5-13 5H16l-6-1z" fill="' + S2 + '" ' + st + '/>' +
      '<path d="M34 11q9 0 13 5-4 5-13 5z" fill="' + R + '" ' + st + '/><path d="M14 11l-3-6h6l3 6zM14 21l-3 6h6l3-6z" fill="' + S + '" ' + st + '/>' +
      '<rect x="22" y="12.4" width="3" height="7.2" fill="' + K + '"/><circle cx="30" cy="16" r="2" fill="#9fd3ff" ' + st + '/>'],
    cruise: ['0 0 48 32',
      '<path d="M6 16l-3-3h5l3 3-3 3H3z" fill="' + Y + '" ' + st + '/><rect x="9" y="12.5" width="28" height="7" rx="3.5" fill="' + S2 + '" ' + st + '/>' +
      '<path d="M37 12.8q9 .4 10 3.2-1 2.8-10 3.2z" fill="' + S + '" ' + st + '/><path d="M20 12.5l7-7h3l-4 7zM20 19.5l7 7h3l-4-7z" fill="' + S + '" ' + st + '/>' +
      '<path d="M10 12.5l-2-5h4l2 5zM10 19.5l-2 5h4l2-5z" fill="' + S + '" ' + st + '/>'],
    bomb: ['0 0 32 40',
      '<path d="M16 3l-5 9h10z" fill="' + S + '" ' + st + '/><path d="M8 4l4 8M24 4l-4 8" stroke="' + O + '" stroke-width="1.6"/>' +
      '<path d="M16 8q10 0 10 15 0 12-10 14C6 35 6 23 6 23 6 8 16 8 16 8z" fill="' + K + '" ' + st + '/>' +
      '<path d="M7 20h18" stroke="' + Y + '" stroke-width="3"/><circle cx="16" cy="26.5" r="2.2" fill="' + Y + '"/>' +
      '<path d="M10 14q0-3 4-3" stroke="#fff6" stroke-width="1.6" fill="none"/>'],
    petard: ['0 0 32 40',
      '<rect x="10" y="16" width="12" height="20" rx="2" fill="' + R + '" ' + st + '/><path d="M10 22h12M10 30h12" stroke="' + Y + '" stroke-width="2"/>' +
      '<path d="M16 16V9" stroke="' + O + '" stroke-width="1.6"/><path d="M16 8l-3-4M16 8l3-4M16 8V2M16 8l-6-1M16 8l6-1" stroke="' + Y + '" stroke-width="1.6" stroke-linecap="round"/><circle cx="16" cy="8" r="1.6" fill="#fff"/>']
  };
  var A = { soldier: 1, tank: 1.5, cannon: 1.5, howitzer: 1.5, mlrs: 1.5, aa: 1.5, drone: 1.5, heli: 1.5, bomber: 1.5, rocket: 1.5, cruise: 1.5, bomb: .8, petard: .8 };
  function inner(k) { return (M[k] || M.soldier)[1]; }
  function vb(k) { return (M[k] || M.soldier)[0]; }
  function svg(k, px, cls) {
    px = px || 28; var v = vb(k).split(' '), w = +v[2], h = +v[3], H = px, W = Math.round(px * w / h);
    return '<svg class="nvspr ' + (cls || '') + '" width="' + W + '" height="' + H + '" viewBox="' + vb(k) + '" aria-hidden="true">' + inner(k) + '</svg>';
  }
  var cache = {};
  function img(k, onload) {
    if (cache[k]) return cache[k];
    var im = new Image(); im.onload = function () { im._ok = true; if (onload) onload(); };
    im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + vb(k) + '" width="96" height="' + Math.round(96 * (+vb(k).split(' ')[3]) / (+vb(k).split(' ')[2])) + '">' + inner(k) + '</svg>');
    cache[k] = im; return im;
  }
  window.NVSPR = { svg: svg, inner: inner, viewBox: vb, img: img, keys: Object.keys(M), ratio: function (k) { var v = vb(k).split(' '); return +v[2] / +v[3]; } };
})();
