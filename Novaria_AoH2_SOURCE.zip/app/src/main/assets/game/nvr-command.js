/* Novaria · Штаб, дипломатический кризис на основной карте, ИИ-тактик, отношения, анимация арсенала */
(function(){'use strict';
if(!window.H||!window.S)return;
var PRE=[['assault','⚡ Блицкриг'],['balanced','⚖ Баланс'],['defense','🛡 Оборона'],['economy','💰 Экономия'],['pressure','🚢 Давление']];
var MP=function(){return !!window.__NG_MP};
var el=function(t,id){var e=document.createElement(t);if(id)e.id=id;return e};
var q=function(s){return String(s).replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/"/g,'&quot;')};
function toast(t){try{NG.toast(t)}catch(e){}}
function save(){try{NG.save()}catch(e){}}
function isoOf(name){try{var c=WORLD.list.find(function(x){return x.name===name});return c&&c.iso}catch(e){}}
function regsOf(name){try{var C=GEO.c[isoOf(name)];return C&&C.regs||[]}catch(e){return[]}}
var fly=el('div','nvrFly');document.body.appendChild(fly);
/* ================= ШТАБ ================= */
var P=el('div','cmd');P.hidden=true;document.body.appendChild(P);
var more=document.getElementById('moreb'),b=el('button','cmdb');b.title='Штаб: армия и тактика';b.textContent='🎖';
if(more&&more.parentNode)more.parentNode.insertBefore(b,more);
var last='';
b.onclick=function(){P.hidden=!P.hidden;last='';if(!P.hidden)paint()};
setInterval(function(){var a=document.querySelector('#tabs button.active[data-tab]');if(a&&(a.dataset.tab==='diplomacy'||a.dataset.tab==='military')){var m=document.querySelector('#tabs [data-tab=map]');m&&m.click()}},500);
window.NVRC={
 gather:function(n){H.wcmd(n,'troopsPct',70);toast('🪖 Армия собрана: 70% сил на фронт')},
 pre:function(n,k){H.warPreset(n,k);if(k==='assault')try{armyAttack(n)}catch(e){}last='';paint()},
 order:function(n,o){H.warOrder(n,o);last='';paint()},
 reg:function(n,r){H.wcmd(n,'addReg',r);try{tgtSet(S.wars.findIndex(function(w){return w.n===n}),r)}catch(e){}last='';paint()},
 auto:function(n){S.cmdAuto=S.cmdAuto||{};S.cmdAuto[n]=!S.cmdAuto[n];last='';paint()},
 close:function(){P.hidden=true}
};
function paint(){if(P.hidden)return;var ws=S.wars||[],h='<h4><span>🎖 Штаб · армия '+Math.round(S.army||0).toLocaleString('ru')+'</span><button class="x" onclick="NVRC.close()">✕</button></h4>';
 if(!ws.length)h+='<p>Войны нет. Коснитесь страны на карте → «⚔ Война…».</p>';
 ws.forEach(function(w){var cm=w.command||{},auto=(S.cmdAuto||{})[w.n],n=q(w.n),regs=regsOf(w.n).filter(function(x){return !(S.taken||{})[x.id]}).slice(0,12);
  h+='<div class="w"><b>⚔ '+w.n+'</b> · фронт '+Math.round(w.p)+'% · '+({attack:'наступление',defend:'оборона',balanced:'баланс'}[w.order||'balanced'])+(cm.troops?' · на фронте '+Math.round(cm.troops).toLocaleString('ru'):'')+'<div class="bar"><i style="width:'+Math.max(2,Math.min(100,w.p))+'%"></i></div>'+
  '<div class="r"><button class="c" onclick="NVRC.gather(\''+n+'\')">🪖 Собрать армию</button><button class="c hot" onclick="NVRC.order(\''+n+'\',\'attack\')">⚔ Наступать</button><button class="c" onclick="NVRC.order(\''+n+'\',\'defend\')">🛡 Держать</button>'+
  (MP()?'':'<button class="c '+(auto?'on':'')+'" onclick="NVRC.auto(\''+n+'\')">🧠 ИИ-тактик: '+(auto?'вкл':'выкл')+'</button>')+'</div>'+
  '<div class="r">'+PRE.map(function(p){return '<button class="c" onclick="NVRC.pre(\''+n+'\',\''+p[0]+'\')">'+p[1]+'</button>'}).join('')+'</div>'+
  (regs.length?'<div class="r">🎯 '+regs.map(function(r){var on=(cm.regions||[]).indexOf(r.n)>=0;return '<button class="c '+(on?'on':'')+'" onclick="NVRC.reg(\''+n+'\',\''+q(r.n)+'\')">'+r.n+'</button>'}).join('')+'</div>':'')+'</div>'});
 if(h!==last){P.innerHTML=h;last=h}}
setInterval(paint,900);
/* ================= ИИ-ТАКТИК (нейросеть) ================= */
function feat(w){return[w.p/100,Math.min(1,S.money/5000),S.ammo/100,S.fuel/100,S.morale/100,S.food/100,Math.min(1,S.army/1e5)]}
function tactic(){if(MP()||!window.NN||!S.cmdAuto)return;var net=NN.get(S,'nnTact',7,10,5,[.2,.25,.1,0,0]),mem=S.tactMem=S.tactMem||[],pv=S.tactPrev=S.tactPrev||{};
 (S.wars||[]).forEach(function(w){if(!S.cmdAuto[w.n])return;var x=feat(w),p=pv[w.n];
  if(p){var r=(w.p-p.p)/20-(S.ammo<20?.2:0)-(S.morale<30?.2:0),nq=Math.max.apply(null,NN.predict(net,x)),t=r+.8*nq;NN.train(net,p.x,p.k,t,.05);NN.remember(mem,{x:p.x,k:p.k,t:t},60);NN.replay(net,mem,4,.03)}
  var qv=NN.predict(net,x),k=NN.choose(qv,null,.1);if(k<0)return;pv[w.n]={x:x,k:k,p:w.p};
  H.warPreset(w.n,PRE[k][0]);if(PRE[k][0]==='assault')try{armyAttack(w.n)}catch(e){}})}
if(window.AOH){var ot=AOH.tick;AOH.tick=function(){ot.apply(this,arguments);try{tactic()}catch(e){console.warn(e)}}}
/* ================= ДИПЛОМАТИЧЕСКИЙ КРИЗИС: панель страны + выбор областей на карте ================= */
var CP=el('div','nvrWar');CP.hidden=true;document.body.appendChild(CP);
var W=null,lastShow=null,lastCP='';
var GD=function(){return window.GrandDiplomacy};
function relIdx(n){return (S.relations||[]).findIndex(function(r){return r.name===n})}
function causeOK(id,r){var v=+r.value||0,mine=S.ideology||'прагматизм',th=r.ideology||(GD()?GD().orientation(r):'');
 return id==='territorial'?1:id==='border'?v<=15:id==='ideology'?(mine!==th&&v<=-15):id==='economic'?!!(S.sanc&&S.sanc[r.name]&&S.sanc[r.name].left>0):id==='security'?v<=-10:0}
function openCP(iso,nm){var i=relIdx(nm);if(i<0)return toast('Нет данных о стране');try{A6.close()}catch(e){}
 var first=['territorial','border','ideology','economic','security'].find(function(c){return causeOK(c,S.relations[i])})||'territorial';
 W={iso:iso,name:nm,i:i,cause:first,goal:GD()?GD().defaultGoal(first):'tribute',sel:[]};CP.hidden=false;CP.classList.remove('min');lastCP='';drawCP()}
function closeCP(){W=null;CP.hidden=true;clearHL()}
window.NVRW={
 close:closeCP,
 min:function(){CP.classList.toggle('min');lastCP='';drawCP()},
 cause:function(c){W.cause=c;W.goal=GD().defaultGoal(c);lastCP='';drawCP()},
 goal:function(g){W.goal=g;lastCP='';drawCP()},
 del:function(id){W.sel=W.sel.filter(function(x){return x!==id});lastCP='';drawCP()},
 clr:function(){W.sel=[];lastCP='';drawCP()},
 start:function(){var r=S.relations[W.i],regs=W.sel.map(function(id){return regName(id)}),need=W.cause==='territorial'||W.goal==='territory';
  if(W.cause==='territorial'&&!regs.length)return toast('Коснитесь на карте области, на которую предъявляете претензию');
  H.justify(W.i,W.cause,regs[0]||'',W.goal);
  if(S.justCause&&S.justCause[W.name]){S.nvrTargets=S.nvrTargets||{};S.nvrTargets[W.name]=regs;save()}lastCP='';drawCP()},
 declare:function(){H.declare(W.i);lastCP='';drawCP()},
 hq:function(){closeCP();P.hidden=false;last='';paint()}
};
function regName(id){try{var C=GEO.c[W.iso];var r=C.regs.find(function(x){return x.id===id});return r?r.n:id}catch(e){return id}}
function drawCP(){if(!W||CP.hidden)return;var r=S.relations[W.i];if(!r){closeCP();return}var G=GD(),v=Math.round(r.value||0),nm=W.name,atWar=(S.wars||[]).some(function(w){return w.n===nm}),cs=S.justCause&&S.justCause[nm];
 var h='<h4><span onclick="NVRW.min()">⚔ '+nm+' · отношения '+(v>0?'+':'')+v+' '+(CP.classList.contains('min')?'▴':'▾')+'</span>'+((!atWar&&!cs)?'<button class="c hot" onclick="NVRW.start()">🌐 Начать кризис</button>':'')+'<button class="x" onclick="NVRW.close()">✕</button></h4>';
 if(atWar)h+='<p>Идёт война.</p><div class="r"><button class="c hot" onclick="NVRW.hq()">🎖 Открыть Штаб</button></div>';
 else if(cs){h+='<p>🌐 Кризис: <b>'+(G&&G.CAUSES[cs]?G.CAUSES[cs].label:cs)+'</b>'+((S.nvrTargets&&S.nvrTargets[nm]&&S.nvrTargets[nm].length)?' · цели: '+S.nvrTargets[nm].join(', '):'')+'</p><div class="r"><button class="c hot" onclick="NVRW.declare()">⚔ Объявить войну</button></div>'}
 else{h+='<div class="r">'+Object.keys(G.CAUSES).map(function(c){var ok=causeOK(c,r);return '<button class="c '+(W.cause===c?'on':'')+'" '+(ok?'':'disabled ')+'onclick="NVRW.cause(\''+c+'\')">'+G.CAUSES[c].icon+' '+G.CAUSES[c].label.split(' / ')[0].replace('Кризис защиты граждан и дипломатической миссии','Защита граждан')+'</button>'}).join('')+'</div>'+
  '<div class="r">'+G.GOAL_IDS.map(function(g){var ok=G.goalAllowed(g,{ideology:S.ideology||'прагматизм'},r,W.cause,r.value);return '<button class="c '+(W.goal===g?'on':'')+'" '+(ok?'':'disabled ')+'onclick="NVRW.goal(\''+g+'\')">'+G.GOALS[g].icon+' '+G.GOALS[g].label+'</button>'}).join('')+'</div>'+
  '<div class="hint">🎯 Коснитесь на карте областей '+nm+', которые вам нужны'+(W.cause==='territorial'?' (обязательно для территориальных претензий)':'')+'</div>'+
  '<div class="r">'+(W.sel.length?W.sel.map(function(id){return '<button class="c on" onclick="NVRW.del(\''+q(id)+'\')">'+regName(id)+' ✕</button>'}).join('')+'<button class="c" onclick="NVRW.clr()">Сбросить</button>':'<small>Области не выбраны</small>')+'</div>'+
  ''}
 if(h!==lastCP){CP.innerHTML=h;lastCP=h}}
setInterval(drawCP,500);
/* как только война началась — применяем выбранные области как цели фронта */
setInterval(function(){var T=S.nvrTargets;if(!T)return;(S.wars||[]).forEach(function(w){var t=T[w.n];if(t&&t.length){delete T[w.n];t.forEach(function(n){try{H.wcmd(w.n,'addReg',n)}catch(e){}});toast('🎯 Цели фронта заданы: '+t.join(', '))}})},1000);
/* карточка страны (A6): запоминаем страну, «Война» открывает нашу панель, а не отдельное окно */
if(window.A6){var os=A6.show;A6.show=function(iso,nm){lastShow={iso:iso,nm:nm};if(W&&W.iso===iso)return;if(W)closeCP();return os.apply(A6,arguments)};
 A6.war=function(){if(lastShow)openCP(lastShow.iso,lastShow.nm)}}
/* подсветка областей-целей на карте */
var hl=[];function clearHL(){hl.forEach(function(o){o.e.setAttribute('stroke',o.s);o.e.setAttribute('stroke-width',o.w)});hl=[]}
setInterval(function(){clearHL();if(!W||CP.hidden||(S.justCause&&S.justCause[W.name]))return;var svg=document.querySelector('#mapbg svg');if(!svg)return;
 svg.querySelectorAll('path[data-c="'+W.iso+'"][data-r]').forEach(function(e){var on=W.sel.indexOf(e.getAttribute('data-r'))>=0;hl.push({e:e,s:e.getAttribute('stroke'),w:e.getAttribute('stroke-width')});e.setAttribute('stroke',on?'#ffe066':'rgba(255,224,102,.55)');e.setAttribute('stroke-width',on?'1.6':'.7')})},450);
/* ================= УДОБНОЕ НАЖАТИЕ: мелкие области ловятся пальцем ================= */
var ofp=document.elementFromPoint.bind(document),snapEl=null,flag=false,down=null;
function snap(x,y){var svg=document.querySelector('#mapbg svg');if(!svg)return null;var ex=ofp(x,y),er=ex&&ex.closest&&ex.closest('[data-r]'),exSmall=true;
 if(er){var rr=er.getBoundingClientRect();exSmall=rr.width<=56&&rr.height<=56}
 var lim=exSmall?44:22,best=null,bd=1e9,ps=svg.querySelectorAll('path[data-r]');
 for(var i=0;i<ps.length;i++){var r=ps[i].getBoundingClientRect();if(r.width>56||r.height>56)continue;if(x<r.left-lim||x>r.right+lim||y<r.top-lim||y>r.bottom+lim)continue;
  var d=Math.hypot((r.left+r.right)/2-x,(r.top+r.bottom)/2-y);if(d<=lim&&d<bd){bd=d;best=ps[i]}}
 return best||er}
document.elementFromPoint=function(x,y){return(flag&&snapEl)?snapEl:ofp(x,y)};
addEventListener('pointerdown',function(e){down=[e.clientX,e.clientY]},true);
addEventListener('pointerup',function(e){if(!down)return;var mv=Math.hypot(e.clientX-down[0],e.clientY-down[1])>8;down=null;if(mv||!(e.target.closest&&e.target.closest('#mapbg')))return;
 snapEl=snap(e.clientX,e.clientY);flag=true;setTimeout(function(){flag=false},0);
 if(W&&!CP.hidden&&snapEl&&snapEl.getAttribute('data-c')===W.iso&&!(S.justCause&&S.justCause[W.name])){var id=snapEl.getAttribute('data-r'),k=W.sel.indexOf(id);
  if(k>=0)W.sel.splice(k,1);else if(W.sel.length<6){W.sel.push(id);if(W.goal==='tribute'&&W.cause==='territorial')W.goal='territory'}else toast('Не больше 6 областей');lastCP='';drawCP()}},true);
/* ================= Отношения в карточке страны ================= */
function rels(){var a=document.getElementById('a6');if(!a||a.hidden||a.querySelector('.nvr-rel'))return;
 var nm=null,all=a.querySelectorAll('*');for(var i=0;i<all.length&&!nm;i++){var e=all[i];if(e.children.length)continue;var t=e.textContent.trim();if((S.relations||[]).some(function(r){return r.name===t}))nm=t}
 if(!nm)return;var r=S.relations.find(function(r){return r.name===nm}),v=Math.round(r.value||0),tr=(S.tr||{})[nm]||{};
 var d=el('div');d.className='nvr-rel';d.innerHTML='Отношения: <b>'+(v>0?'+':'')+v+'</b>'+((S.allies||[]).indexOf(nm)>=0?' · 🛡 союзник':'')+(tr.nap>0?' · 📜 пакт':'')+(tr.trade?' · 💱 торговля':'')+'<div class="b"><i style="left:'+((v+100)/2)+'%"></i></div>';
 a.insertBefore(d,a.firstChild)}
setInterval(rels,600);
/* ================= Анимация арсенала ================= */
var prev=null;
setInterval(function(){var st=S.stock;if(!st||typeof st!=='object')return;var cur={};Object.keys(st).forEach(function(k){cur[k]=+st[k]||0});
 if(prev){Object.keys(cur).forEach(function(k){var d=cur[k]-(prev[k]||0);if(d>0){var A=(window.ARMS&&ARMS[k])||{ic:'🔧',n:k},s=el('span');s.textContent=(A.ic||'🔧')+' +'+d+' '+(A.n||k);fly.appendChild(s);setTimeout(function(){s.remove()},1700);document.querySelectorAll('#content .mini,#content .card').forEach(function(c){if(c.textContent.indexOf(A.n)>=0){c.classList.remove('nvr-pulse');void c.offsetWidth;c.classList.add('nvr-pulse')}})}})}
 prev=cur},800);
console.log('[NVR command] loaded');
})();
