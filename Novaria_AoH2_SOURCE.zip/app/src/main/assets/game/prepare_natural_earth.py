#!/usr/bin/env python3
"""Build Natural Earth Admin-1 geometry and province adjacency graph.
The source is Natural Earth Admin-1 via datasets/geo-ne-admin1. Adjacency means
sharing a non-zero-length polygon boundary; point-only contacts are excluded.
"""
import json
import urllib.request
from pathlib import Path
from shapely.geometry import shape
from shapely.strtree import STRtree

URL = "https://raw.githubusercontent.com/datasets/geo-ne-admin1/main/data/admin1.geojson"
HERE = Path(__file__).resolve().parent
GEOMETRY_OUT = HERE / "natural_earth_admin1_data.js"
ADJACENCY_OUT = HERE / "natural_earth_admin1_adjacency.js"
MIN_SHARED_BOUNDARY_DEGREES = 1e-5

req = urllib.request.Request(URL, headers={"User-Agent": "Novaria-map-builder/2.0"})
with urllib.request.urlopen(req, timeout=180) as response:
    source = json.load(response)

features, geoms, ids = [], [], []
used = set()
for feature in source.get("features", []):
    props = feature.get("properties") or {}
    geom_data = feature.get("geometry")
    if not geom_data or geom_data.get("type") not in ("Polygon", "MultiPolygon"):
        continue
    name = props.get("name") or "Region"
    iso = props.get("iso_3166_2") or ""
    adm0 = props.get("adm0_a3") or "UNK"
    base_id = iso or f"{adm0}-{name}"
    region_id = base_id
    suffix = 2
    while region_id in used:
        region_id = f"{base_id}#{suffix}"
        suffix += 1
    used.add(region_id)
    clean_props = {"name": name, "admin": props.get("admin") or "Unknown",
                   "iso_3166_2": iso, "adm0_a3": adm0, "novaria_id": region_id}
    features.append({"type": "Feature", "properties": clean_props, "geometry": geom_data})
    geoms.append(shape(geom_data))
    ids.append(region_id)

if len(features) < 3000:
    raise SystemExit(f"Unexpectedly few Admin-1 features: {len(features)}")

# Shapely 2 STRtree returns integer indices. Build undirected graph deterministically.
tree = STRtree(geoms)
neighbors = {rid: set() for rid in ids}
for i, geom in enumerate(geoms):
    candidates = tree.query(geom)
    for raw_j in candidates:
        j = int(raw_j)
        if j <= i:
            continue
        # Bounding-box candidates are cheap; exact shared-boundary check avoids
        # treating islands/point-only corner contacts as land adjacency.
        shared = geom.boundary.intersection(geoms[j].boundary)
        if shared.length > MIN_SHARED_BOUNDARY_DEGREES:
            neighbors[ids[i]].add(ids[j])
            neighbors[ids[j]].add(ids[i])

geometry_payload = {"type": "FeatureCollection", "features": features}
adjacency_payload = {"version": 1, "source": "Natural Earth Admin-1",
                     "rule": "shared polygon boundary length > 1e-5 degrees",
                     "neighbors": {k: sorted(v) for k, v in sorted(neighbors.items())}}
GEOMETRY_OUT.write_text("window.NATURAL_EARTH_ADMIN1=" + json.dumps(geometry_payload, ensure_ascii=False, separators=(",", ":")) + ";\n", encoding="utf-8")
ADJACENCY_OUT.write_text("window.NATURAL_EARTH_ADMIN1_ADJACENCY=" + json.dumps(adjacency_payload, ensure_ascii=False, separators=(",", ":")) + ";\n", encoding="utf-8")
edge_count = sum(map(len, neighbors.values())) // 2
print(f"Wrote {len(features)} regions and {edge_count} undirected land borders")
