window.NATURAL_EARTH_ADMIN1_ADJACENCY={version:1,source:"not-generated",neighbors:{}};
