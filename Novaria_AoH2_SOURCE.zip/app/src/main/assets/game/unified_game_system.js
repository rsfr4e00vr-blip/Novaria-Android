/* Novaria Stage 20: shared cross-system integration.
 * Reconciles economy, provinces, diplomacy, resources and military readiness
 * on the same monthly state for the player and AI. It does not emulate
 * multiplayer synchronization; strategic multiplayer is a separate, skipped stage 18.
 */
(function(root){
 'use strict';
 const N=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
 const C=(v,a,b)=>Math.max(a,Math.min(b,N(v)));
 const monthOf=S=>Math.max(0,N(S.year,1)*12+N(S.month,0));
 const avg=(a,d)=>a.length?a.reduce((x,y)=>x+y,0)/a.length:d;
 const clamp01=x=>C(x,0,1);
 function diplomacy(S,month){
  const rel=Array.isArray(S.relations)?S.relations.filter(x=>x&&!x.self&&!x.annexed):[];
  const open=rel.filter(x=>N(x.value,0)>=30&&N(x.embargo,0)<=month).length;
  const embargo=rel.filter(x=>N(x.embargo,0)>month).length;
  const pacts=Object.values(S.pacts||{}).filter(x=>N(x,0)>month).length;
  const allies=Array.isArray(S.allies)?S.allies.length:0;
  const sanctions=C(N(S.sanctionsCount,0)+embargo,0,12);
  const wars=(Array.isArray(S.wars)?S.wars.filter(w=>w&&!w.ended).length:0)+(Array.isArray(S.mpWars)?S.mpWars.length:0);
  const access=C(.28+open*.075+pacts*.055+allies*.035-sanctions*.085-wars*.025,.05,1);
  return {open,embargo,pacts,allies,sanctions,wars,access};
 }
 function provinces(S){
  const rows=Array.isArray(S.regions)?S.regions:[];
  const pop=Math.max(1,N(S.pop,1));
  let weighted=0,weight=0;
  rows.forEach(r=>{
   const p=Math.max(1,N(r.pop,1)),w=p/pop;
   const infra=C(N(r.infra,50)/100,.2,1.5);
   const industry=C(N(r.industry,50)/100,.2,1.6);
   const productivity=C(N(r.productivity,.75),.35,1.5);
   const unrest=C(N(r.unrest,10)/100,0,1);
   const factor=C(productivity*(.72+infra*.16+industry*.12)*(1-unrest*.22),.35,1.5);
   weighted+=factor*w;weight+=w;
  });
  return {count:rows.length,index:C(weight?weighted/weight:1,.5,1.35),coverage:C(weight,0,1.5)};
 }
 function stockTrade(S,d){
  const stocks=['food','fuel','energy','steel'];
  let imported=0,exported=0,cost=0;
  stocks.forEach(k=>{
   const v=C(N(S[k],50),0,100);
   if(v<42&&d.access>.32){
    const qty=Math.min(1.1,(42-v)*.045*d.access);
    S[k]=C(v+qty,0,100); imported+=qty;cost+=qty*1.8;
   }else if(v>88&&d.access>.55){
    const qty=Math.min(.45,(v-88)*.018*d.access);
    S[k]=C(v-qty,0,100);exported+=qty;
   }
  });
  if(cost>0&&N(S.money,0)>cost)S.money-=cost;
  return {imported:+imported.toFixed(3),exported:+exported.toFixed(3),cost:+cost.toFixed(2)};
 }
 function military(S,province,d){
  const I=root.InterDep&&S.idp?root.InterDep.effects(S):null;
  const stocks=avg([N(S.food,50),N(S.fuel,50),N(S.energy,50),N(S.steel,50)].map(x=>C(x,0,100)/100),.5);
  const equipment=C(N(S.equipment,65)/100,.1,1.15);
  const ammo=C(N(S.ammo,65)/100,.1,1.15);
  const industry=C(N(S.mil,1)/Math.max(1,N(S.mil,1)+1),.2,1);
  const network=I?C(I.arms,.05,1):1;
  const supply=C(stocks*.48+equipment*.18+ammo*.14+industry*.08+network*.12,.08,1.1);
  const readiness=C(supply*(.82+province.index*.12)*(.82+d.access*.18),.08,1.1);
  if(readiness<.55)S.morale=C(N(S.morale,65)-.12,0,100);
  else if(readiness>.88)S.morale=C(N(S.morale,65)+.035,0,100);
  return {supply:+supply.toFixed(3),readiness:+readiness.toFixed(3),effectivePower:Math.round(Math.max(0,N(S.army,0))*readiness)};
 }
 function record(holder,key,row){
  holder.last=row;holder.history=Array.isArray(holder.history)?holder.history:[];
  holder.history.push(row);if(holder.history.length>24)holder.history.shift();
  holder.monthKey=key;
 }
 function tickPlayer(S){
  if(!S||typeof S!=='object')return null;
  const key=monthOf(S);let U=S.unifiedSystems;
  if(!U||U.version!==1)U=S.unifiedSystems={version:1,months:0,history:[]};
  if(U.monthKey===key)return U.last;
  const d=diplomacy(S,key),p=provinces(S),trade=stockTrade(S,d),m=military(S,p,d);
  const atWar=!!S.war||(Array.isArray(S.wars)&&S.wars.some(w=>w&&!w.ended));
  const mobilization=C(N(S.army,0)/Math.max(1,N(S.pop,1)*.47),0,.22);
  const row={month:key,diplomacy:d,provinces:p,trade,military:m,atWar,mobilization:+mobilization.toFixed(4),
   feedback:{tradeAccess:d.access,provinceProduction:p.index,militaryReadiness:m.readiness}};
  U.months=N(U.months)+1;
  record(U,key,row);
  S.effectiveMilitaryPower=m.effectivePower;
  return row;
 }
 function tickNation(world,n){
  if(!n||typeof n!=='object')return null;
  const key=N(world&&world.month,0);let U=n.unifiedSystems;
  if(!U||U.version!==1)U=n.unifiedSystems={version:1,months:0,history:[]};
  if(U.monthKey===key)return U.last;
  const partners=Array.isArray(n.tradePartners)?n.tradePartners.length:0;
  const allies=Array.isArray(n.allies)?n.allies.length:0;
  const access=C(.3+partners*.07+allies*.035-(n.war?.06:0),.05,1);
  const stocks=['food','fuel','energy','steel'];
  let shortage=0;
  stocks.forEach(k=>{
   const v=C(N(n[k],55),0,100);
   if(v<35&&access>.35)n[k]=C(v+Math.min(.75,(35-v)*.035*access),0,100);
   if(v<20)shortage++;
  });
  const provinceRows=Array.isArray(n.regions)?n.regions:[];
  const pIndex=provinceRows.length?C(avg(provinceRows.map(r=>C(N(r.productivity,1)*(.75+N(r.infrastructure,1)*.12+N(r.industry,1)*.13),.35,1.5)),1),.5,1.35):C(N(n.infrastructure,1)*.5+N(n.industry,1)*.5,.5,1.35);
  const supply=avg(stocks.map(k=>C(N(n[k],55)/100,0,1)),.5);
  const readiness=C(supply*.55+C(N(n.morale,70)/100,.1,1)*.2+C(N(n.manpower,10)/Math.max(1,N(n.pop,1)*.035),.1,1)*.1+C(N(n.industry,1)/1.5,.1,1)*.15,.08,1.05);
  if(readiness<.5)n.morale=C(N(n.morale,70)-.1,0,100);
  else if(readiness>.85)n.morale=C(N(n.morale,70)+.025,0,100);
  const row={month:key,diplomacy:{partners,allies,access:+access.toFixed(3)},provinces:{count:provinceRows.length,index:+pIndex.toFixed(3)},trade:{shortage},military:{supply:+supply.toFixed(3),readiness:+readiness.toFixed(3),effectivePower:Math.round(N(n.power,0)*readiness)},atWar:!!n.war};
  U.months=N(U.months)+1;record(U,key,row);
  n.effectivePower=row.military.effectivePower;
  return row;
 }
 function validate(S){
  const U=S&&S.unifiedSystems;
  return !!(U&&U.version===1&&Number.isFinite(U.monthKey)&&U.last&&U.last.military&&U.last.provinces&&U.last.diplomacy);
 }
 root.UnifiedGameSystem={tickPlayer,tickNation,validate,diplomacy,provinces};
})(typeof window!=='undefined'?window:globalThis);
