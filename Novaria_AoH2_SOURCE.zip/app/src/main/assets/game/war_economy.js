/* NOVARIA WAR ECONOMY — Этап 12.
 * Связывает армии, мобилизацию, боевые потери, разрушения и послевоенное восстановление
 * с общей экономикой. Расчёт детерминированный: один вызов на игровой месяц.
 */
(function(root){
 'use strict';
 const n=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
 const c=(v,a,b)=>Math.max(a,Math.min(b,n(v)));
 const round=v=>Math.round(n(v));
 const clamp01=v=>c(v,0,1);
 function ensure(S){
  const W=S.warEconomy||(S.warEconomy={version:1,months:0,wasAtWar:false,processedBattles:[],mobilized:0,
   totalMaintenance:0,totalMobilization:0,totalDamage:0,totalRecovery:0,totalTaxLoss:0,last:null,recovery:0});
  if(W.version!==1){S.warEconomy={version:1,months:0,wasAtWar:false,processedBattles:[],mobilized:0,totalMaintenance:0,totalMobilization:0,totalDamage:0,totalRecovery:0,totalTaxLoss:0,last:null,recovery:0};}
  const X=S.warEconomy;
  if(!Array.isArray(X.processedBattles))X.processedBattles=[];
  return X;
 }
 function atWar(S){
  return (Array.isArray(S.wars)&&S.wars.some(w=>w&&!w.won&&!w.ended)) ||
         (Array.isArray(S.mpWars)&&S.mpWars.some(w=>w&&!w.won&&!w.ended));
 }
 function armyStats(S){
  const divs=(S.military&&Array.isArray(S.military.divisions))?S.military.divisions:[];
  const manpower=divs.reduce((a,d)=>a+Math.max(0,n(d.manpower)),0);
  const deployed=(S.armies&&Array.isArray(S.armies.stacks)?S.armies.stacks:[])
   .reduce((a,st)=>a+divs.filter(d=>(st.divs||[]).includes(d.id)).reduce((x,d)=>x+Math.max(0,n(d.manpower)),0),0);
  const types={};divs.forEach(d=>{types[d.type]=(types[d.type]||0)+Math.max(0,n(d.manpower))});
  return {manpower,deployed,divisions:divs.length,types};
 }
 function regionForBattle(S,b){
  const A=root.NovariaArmies;
  try{
   const geo=A&&A.regionOf?A.regionOf(b.target):null;if(!geo)return null;
   const name=String(geo.n||geo.name||'');
   return (S.regions||[]).find(r=>String(r.name||'')===name||String(r.id||'')===String(b.target))||null;
  }catch(_){return null}
 }
 function recordBattleDamage(S,W){
  const hist=S.battles&&Array.isArray(S.battles.history)?S.battles.history:[];
  let damage=0,repairs=0,losses=0,processed=0;
  hist.forEach(b=>{
   const id=String(b.id);
   if(W.processedBattles.includes(id))return;
   W.processedBattles.push(id);processed++;
   const total=Math.max(0,n(b.attLost)+n(b.defLost));losses+=total;
   if(total<=0)return;
   const severity=c(total/120000,0,1);
   const cost=round(total*0.012);damage+=cost;repairs+=cost;
   const r=regionForBattle(S,b);
   if(r){
    r.industry=c(n(r.industry,50)-severity*1.8,0,100);
    r.infra=c(n(r.infra,50)-severity*1.2,0,100);
    r.unrest=c(n(r.unrest,0)+severity*1.1,0,100);
    r.warDamage=round(n(r.warDamage)+cost);
   }
  });
  if(W.processedBattles.length>500)W.processedBattles=W.processedBattles.slice(-300);
  W.totalDamage+=damage;
  return {damage,repairs,losses,processed};
 }
 function taxBase(S){return Math.max(0,n(S.gdp))*c(n(S.tax,20)/100,0,1)*0.012;}
 function tick(S,g0){
  if(!S||typeof S!=='object')return null;
  const W=ensure(S),war=atWar(S),A=armyStats(S),gdp=Math.max(100,n(S.gdp,100));
  const battle=recordBattleDamage(S,W);
  const scale=c(gdp/42000,.25,8);
  const activeRatio=clamp01(A.manpower/Math.max(1,n(S.pop,1)*.035));
  const deployedRatio=clamp01(A.deployed/Math.max(1,A.manpower));
  let maintenance=0,mobilization=0,productionLoss=0,taxLoss=0,fxPressure=0;
  if(war){
   // Содержание армии: базовая ставка на каждого реально существующего военнослужащего.
   maintenance=round(A.manpower*.00042*scale);
   // Разовая мобилизационная нагрузка начисляется только при росте численности.
   const newlyMobilized=Math.max(0,A.manpower-n(W.mobilized));
   mobilization=round(newlyMobilized*.0009*scale);
   W.mobilized=A.manpower;
   productionLoss=c(activeRatio*.85+deployedRatio*.35,0,2.5);
   taxLoss=round(taxBase(S)*c(.025+activeRatio*.16,0,.22));
   fxPressure=c(.00015+activeRatio*.0008,0,.0012);
   S.money=n(S.money)-maintenance-mobilization-battle.damage-taxLoss;
   if(S.money<0){S.debt=n(S.debt)-S.money;S.money=0}
   S.employment=c(n(S.employment,90)-activeRatio*.08-deployedRatio*.04,0,100);
   S.gdp=Math.max(100,n(S.gdp)*(1-productionLoss/10000));
   S.inflation=c(n(S.inflation)+.025+activeRatio*.045+(maintenance+mobilization)/Math.max(1,gdp)*100,0,100);
   S.stability=c(n(S.stability,50)-.025-activeRatio*.035,0,100);
   if(S.fx&&typeof S.fx==='object'){
    const old=n(S.fx.rate);if(old>0)S.fx.rate=old*(1+fxPressure);
    S.fx.warPressure=n(S.fx.warPressure)+fxPressure*100;
   }
   W.totalMaintenance+=maintenance;W.totalMobilization+=mobilization;W.totalTaxLoss+=taxLoss;
   W.recovery=n(W.recovery)+battle.repairs;
  }else{
   W.mobilized=0;
   // Восстановление после войны финансируется постепенно, не мгновенным списанием.
   const outstanding=Math.max(0,n(W.recovery));
   if(outstanding>0){
    const budget=Math.min(outstanding,Math.max(0,n(S.money))*0.025,round(gdp*.00018));
    if(budget>0){
     S.money-=budget;W.recovery-=budget;W.totalRecovery+=budget;
     const regions=Array.isArray(S.regions)?S.regions.filter(r=>n(r.warDamage)>0):[];
     if(regions.length){
      const per=budget/regions.length;
      regions.forEach(r=>{r.industry=c(n(r.industry,50)+Math.min(1.2,per/Math.max(1,n(r.warDamage))*.8),0,100);r.infra=c(n(r.infra,50)+Math.min(.8,per/Math.max(1,n(r.warDamage))*.55),0,100);r.warDamage=Math.max(0,n(r.warDamage)-per)});
     }
    }
   }
   // Налоговая база возвращается по мере восстановления занятости и производства.
   S.employment=c(n(S.employment,90)+(n(S.employment,90)<94?.025:0),0,100);
  }
  let outcome=null;
  if(W.pendingOutcome){
   outcome=W.pendingOutcome;delete W.pendingOutcome;
   if(outcome==='victory'){
    S.stability=c(n(S.stability,50)+.45,0,100);
    S.approval=c(n(S.approval,50)+.35,0,100);
    W.recovery=Math.max(0,n(W.recovery)*.9);
   }else if(outcome==='defeat'){
    S.stability=c(n(S.stability,50)-1.2,0,100);
    S.approval=c(n(S.approval,50)-.9,0,100);
    S.trust=c(n(S.trust,60)-.7,0,100);
    S.debt=n(S.debt)+Math.round(gdp*.0005);
   }
  }
  W.months++;
  W.wasAtWar=war;
  const result={war,outcome,manpower:A.manpower,deployed:A.deployed,maintenance,mobilization,battleDamage:battle.damage,battleLosses:battle.losses,
   productionLoss:+productionLoss.toFixed(3),taxLoss,recoveryPaid:round(W.totalRecovery-(W._recoveryBefore||0)),recoveryLeft:round(W.recovery),
   gdp:round(S.gdp),money:round(S.money),debt:round(S.debt),inflation:+n(S.inflation).toFixed(3),employment:+n(S.employment).toFixed(3)};
  W._recoveryBefore=W.totalRecovery;
  W.last=result;
  return result;
 }
 function panel(S){
  const W=ensure(S),L=W.last||{},A=armyStats(S),fmt=v=>Math.round(n(v)).toLocaleString('ru-RU');
  const item=(name,val,sub)=>`<div class="mini"><b>${name}</b><strong>${val}</strong><small>${sub}</small></div>`;
  const status=atWar(S)?'Военная нагрузка активна':'Мирное время';
  return `<section class="panel"><h2>⚔️ Военная экономика · этап 12</h2><p class="muted">${status}. Расходы, потери и восстановление учитываются в общей экономике и сохраняются в партии.</p><div class="cards">
   ${item('Военнослужащие',fmt(A.manpower),`Размещено в армиях: ${fmt(A.deployed)}`)}
   ${item('Содержание за месяц',fmt(L.maintenance),'Списывается из казны')}
   ${item('Мобилизация',fmt(L.mobilization),'Дополнительные расходы')}
   ${item('Боевые разрушения',fmt(L.battleDamage),`Потери в боях: ${fmt(L.battleLosses)} человек`)}
   ${item('Потери производства',`${n(L.productionLoss).toFixed(3)}%`,'Месячное давление на ВВП')}
   ${item('Восстановление',fmt(L.recoveryLeft),`Оплачено: ${fmt(W.totalRecovery)} млн`)}
  </div><p class="muted">Накопленные расходы на содержание: ${fmt(W.totalMaintenance)} млн · мобилизацию: ${fmt(W.totalMobilization)} млн · ущерб: ${fmt(W.totalDamage)} млн · налоговые потери: ${fmt(W.totalTaxLoss)} млн.</p></section>`;
 }
 root.NovariaWarEconomy={version:1,ensure,atWar,armyStats,tick,panel};
})(typeof window!=='undefined'?window:globalThis);
