/* Novaria Army Movement v1.0 (Этап 9). Оригинальная реализация.
 * Армии стоят в конкретных провинциях, ходят по графу соседства (NovariaProvinceGraph),
 * время хода зависит от расстояния и типа войск, проход проверяется по владельцу/союзу/доступу.
 * Бои и захват — этапы 10–11: вход в вражескую провинцию здесь намеренно запрещён. */
(function(root){'use strict';
 const VERSION=1,DAYS_PER_MONTH=30,ROAD=1.25;
 const SPEED={infantry:25,motorized:80,mechanized:70,armor:60,artillery:20,engineers:22,recon:90,airborne:25}; /* км/сутки */
 const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
 const G=()=>root.GEO,PG=()=>root.NovariaProvinceGraph;
 const mer=l=>Math.log(Math.tan(Math.PI/4+Math.max(-85,Math.min(85,l))*Math.PI/360));
 function ensure(S){
   if(!S.armies||S.armies.version!==VERSION)S.armies={version:VERSION,nextId:1,stacks:[],access:{},log:[]};
   const A=S.armies;A.stacks.forEach(s=>{if(!Array.isArray(s.path))s.path=[]});return A}
 const addLog=(A,t)=>{A.log.unshift(t);A.log.length=Math.min(A.log.length,30)};
 function regionOf(id){const g=G();if(!g||!g.c||!id)return null;const s=String(id),i=s.lastIndexOf(':'),C=g.c[s.slice(0,i)];return C&&C.regs?C.regs[+s.slice(i+1)]||null:null}
 function countryOf(id){const g=G();if(!g||!g.c)return null;const s=String(id),i=s.lastIndexOf(':');return g.c[s.slice(0,i)]||null}
 const provName=id=>{const r=regionOf(id),C=countryOf(id);return r?((r.n||(C&&C.name)||id)):String(id)};
 function me(S){return S.me||S.name}
 function ownerOf(S,id){
   if(root.NovariaTerritory)return root.NovariaTerritory.controllerOf(S,id);
   const t=S.taken||{};if(t[id])return me(S);
   const C=countryOf(id);if(C&&C.name)return C.name;return null}
 function ownProvinces(S){const g=G();if(!g||!g.c)return [];const out=[];Object.keys(g.c).forEach(k=>{const C=g.c[k];(C.regs||[]).forEach(r=>{if(r.id&&ownerOf(S,r.id)===me(S)&&(r.d||C.regs.length===1))out.push(r.id)})});return out}
 function relValue(S,n){const r=(S.relations||[]).find(x=>x.name===n);return r?num(r.value):0}
 const atWarWith=(S,n)=>(S.wars||[]).some(w=>w.n===n&&!w.won);
 const isAlly=(S,n)=>(S.allies||[]).includes(n);
 /* Проверка входа армии в провинцию */
 function canEnter(S,stack,id){
   const owner=ownerOf(S,id),br=S.battles&&S.battles.breach&&S.battles.breach[id];
   if(br&&br.by===stack.owner&&owner!==stack.owner)return {ok:true,kind:'breach'};
   if(owner==null)return {ok:false,code:'NO_OWNER',message:'Провинция не принадлежит ни одному государству'};
   if(owner===stack.owner)return {ok:true,kind:'own'};
   if(stack.owner!==me(S))return {ok:false,code:'FORBIDDEN',message:'Проход через чужую территорию запрещён'};
   if(atWarWith(S,owner))return {ok:false,code:'ENEMY_TERRITORY',message:`${owner} — противник. Вторжение — только приказом атаки из соседней провинции`};
   if(isAlly(S,owner)){if(ensure(S).access[owner])return {ok:true,kind:'allied'};return {ok:false,code:'NO_ACCESS',message:`Нужно разрешение ${owner} на военный доступ`,country:owner}}
   return {ok:false,code:'FORBIDDEN',message:`Проход через территорию ${owner} запрещён`,country:owner}}
 function requestAccess(S,name){
   const A=ensure(S);if(A.access[name])return {ok:true,already:true};
   if(atWarWith(S,name))return {ok:false,message:`${name} находится с вами в состоянии войны`};
   if(isAlly(S,name)||relValue(S,name)>=60){A.access[name]=true;addLog(A,`🤝 ${name} разрешила проход армий`);return {ok:true}}
   return {ok:false,message:`${name} не даёт военный доступ: нужен союз или отношения от 60`}}
 function revokeAccess(S,name){const A=ensure(S);delete A.access[name];return {ok:true}}
 /* Расстояние и время */
 function latOf(y){const g=G(),m=mer(80)-y/g.W*2*Math.PI;return (2*Math.atan(Math.exp(m))-Math.PI/2)*180/Math.PI}
 function distKm(a,b){const g=G(),la=latOf(a.cy),lb=latOf(b.cy),dlon=(b.cx-a.cx)/g.W*360,mid=(la+lb)/2*Math.PI/180;
   return Math.hypot(dlon*Math.cos(mid)*111.32,(lb-la)*111.32)}
 function stackSpeed(S,stack){const M=S.military,ds=(M&&M.divisions||[]).filter(d=>stack.divs.includes(d.id));let v=Infinity;ds.forEach(d=>{v=Math.min(v,SPEED[d.type]||25)});if(!isFinite(v))v=25;
   const sup=ds.length?ds.reduce((a,d)=>a+num(d.supply,75),0)/ds.length:75;return v*(sup<25?.6:1)}
 function legDays(S,stack,from,to){const a=regionOf(from),b=regionOf(to);if(!a||!b)return 1;return Math.max(1,Math.ceil(distKm(a,b)*ROAD/stackSpeed(S,stack)))}
 /* Маршрут: Дейкстра по времени, только через допустимые провинции */
 function plan(S,stack,dest){
   const P=PG();if(!P||!P.ready())return {ok:false,code:'MAP_GRAPH_MISSING',message:'Карта ещё загружается. Подождите несколько секунд.'};
   dest=String(dest);const from=stack.prov;if(from===dest)return {ok:false,code:'SAME',message:'Армия уже в этой провинции'};
   const dc=canEnter(S,stack,dest);if(!dc.ok)return dc;
   const dist=new Map([[from,0]]),prev=new Map(),done=new Set();let guard=0;
   while(guard++<20000){let cur=null,cd=Infinity;dist.forEach((d,k)=>{if(!done.has(k)&&d<cd){cd=d;cur=k}});if(cur===null)break;if(cur===dest)break;done.add(cur);
     for(const n of P.neighbors(cur)){if(done.has(n))continue;if(!canEnter(S,stack,n).ok)continue;const nd=cd+legDays(S,stack,cur,n);if(nd<(dist.has(n)?dist.get(n):Infinity)){dist.set(n,nd);prev.set(n,cur)}}}
   if(!dist.has(dest))return {ok:false,code:'NO_ROUTE',message:'Нет сухопутного маршрута через разрешённые территории'};
   const path=[];let p=dest;while(p!==from){path.push(p);p=prev.get(p)}path.reverse();
   let t=0,cur=from;const legs=path.map(id=>{const d=legDays(S,stack,cur,id);t+=d;cur=id;return {to:id,days:d}});
   return {ok:true,path,legs,days:t}}
 /* Формирование и управление */
 function stackManpower(S,stack){const M=S.military;return (M&&M.divisions||[]).filter(d=>stack.divs.includes(d.id)).reduce((a,d)=>a+num(d.manpower),0)}
 function freeDivisions(S){const M=S.military;if(!M)return [];const A=ensure(S),used=new Set();A.stacks.forEach(s=>{s.divs.forEach(i=>used.add(i));(s.incoming||[]).forEach(x=>used.add(x.id))});return M.divisions.filter(d=>!used.has(d.id))}
 function deploy(S,divIds,provId,name){
   const A=ensure(S);provId=String(provId);
   if(ownerOf(S,provId)!==me(S))return {ok:false,message:'Армию можно разместить только в своей провинции'};
   const free=new Set(freeDivisions(S).map(d=>d.id)),ids=(divIds||[]).map(Number).filter(i=>free.has(i));
   if(!ids.length)return {ok:false,message:'Нет свободных дивизий для размещения'};
   const st={id:A.nextId++,owner:me(S),name:name||`Армия ${A.nextId-1}`,divs:ids,prov:provId,home:provId,path:[],leg:null,status:'idle',created:(S.year||0)*12+(S.month||0)};
   A.stacks.push(st);addLog(A,`🪖 ${st.name} размещена в провинции ${provName(provId)}`);return {ok:true,stack:st}}
 function disband(S,id){const A=ensure(S),i=A.stacks.findIndex(s=>s.id===Number(id));if(i<0)return {ok:false,message:'Армия не найдена'};if(A.stacks[i].status==='fighting')return {ok:false,message:'Армия в бою — сначала отступите'};const s=A.stacks[i];A.stacks.splice(i,1);addLog(A,`↩️ ${s.name} распущена, дивизии возвращены в резерв`);return {ok:true}}
 const find=(S,id)=>ensure(S).stacks.find(s=>s.id===Number(id));
 function order(S,id,dest){
   const st=find(S,id);if(!st)return {ok:false,message:'Армия не найдена'};if(st.status==='fighting')return {ok:false,message:'Армия в бою'};
   /* если армия в пути — отсчёт идёт от ближайшей достигнутой провинции; текущий переход завершается */
   const r=plan(S,st,dest);if(!r.ok)return r;
   if(st.status==='idle')st.home=st.prov;
   st.path=r.path.slice();st.leg=null;st.status='moving';st.dest=String(dest);
   const A=ensure(S);addLog(A,`➡️ ${st.name}: ${provName(st.prov)} → ${provName(dest)}, ${r.days} сут.`);return {ok:true,plan:r}}
 function stop(S,id){const st=find(S,id);if(!st)return {ok:false};if(st.status==='fighting')return {ok:false,message:'Армия в бою'};st.path=[];st.leg=null;st.status='idle';delete st.dest;return {ok:true}}
 function recall(S,id){const st=find(S,id);if(!st)return {ok:false,message:'Армия не найдена'};if(st.status==='fighting')return {ok:false,message:'Армия в бою — используйте «Отступить»'};if(!st.home||st.home===st.prov){return {ok:false,message:'Армия уже на исходной позиции'}}
   const r=plan(S,st,st.home);if(!r.ok)return r;st.path=r.path.slice();st.leg=null;st.status='returning';st.dest=st.home;return {ok:true,plan:r}}
 /* Время: идёт по суткам, переходы дискретны */
 function advance(S,days){
   const A=ensure(S);
   A.stacks.forEach(st=>{
     let left=days;
     while(left>0&&(st.status==='moving'||st.status==='returning')){
       if(!st.leg){const next=st.path[0];if(!next){st.status='idle';delete st.dest;break}
         const ck=canEnter(S,st,next);if(!ck.ok){addLog(A,`⛔ ${st.name} остановлена у ${provName(next)}: ${ck.message}`);st.path=[];st.status='idle';delete st.dest;break}
         st.leg={to:next,left:legDays(S,st,st.prov,next),total:0};st.leg.total=st.leg.left}
       const use=Math.min(left,st.leg.left);st.leg.left-=use;left-=use;
       if(st.leg.left<=0){st.prov=st.leg.to;st.path.shift();st.leg=null;if(root.NovariaTerritory)root.NovariaTerritory.onArrive(S,st);
         if(!st.path.length){const was=st.status;st.status='idle';delete st.dest;if(was==='returning')st.home=st.prov;addLog(A,`✅ ${st.name} прибыла в ${provName(st.prov)}`)}}
     }
   });
 }
 function tick(S){if(!S)return;ensure(S);advance(S,DAYS_PER_MONTH)}
 function summary(S,st){const left=(st.leg?st.leg.left:0)+st.path.slice(st.leg?1:0).reduce((a,id,i,arr)=>a+legDays(S,st,i===0?(st.leg?st.leg.to:st.prov):arr[i-1],id),0);return {eta:left,speed:Math.round(stackSpeed(S,st)),men:stackManpower(S,st)}}
 root.NovariaArmies={version:VERSION,ensure,ownerOf,ownProvinces,canEnter,requestAccess,revokeAccess,plan,deploy,disband,order,stop,recall,advance,tick,freeDivisions,legDays,distKm,stackSpeed,summary,provName,find,SPEED,regionOf,countryOf,latOf,atWarWith};
 /* ================= Интерфейс (телефон) ================= */
 if(typeof document==='undefined')return;
 const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const U={open:false,sel:null,pick:false,pending:null,sig:''};
 const NG=()=>root.NG,S=()=>NG()&&NG().S;
 const css=`#nvrArBtn{position:fixed;left:8px;bottom:56px;z-index:9997;padding:8px 12px;border-radius:10px;border:1px solid #e0b64f;background:#101c2bee;color:#f2c14e;font:600 14px system-ui}
 #nvrArPanel{position:fixed;left:0;right:0;bottom:0;max-height:62vh;overflow:auto;z-index:9998;background:#101c2bf5;color:#e8edf4;border-top:2px solid #e0b64f;padding:10px 12px 14px;font:14px system-ui;display:none}
 #nvrArPanel button,#nvrArPanel select{margin:3px 4px 3px 0;padding:7px 10px;border-radius:8px;border:1px solid #3a4b63;background:#1b2a40;color:#e8edf4;font:13px system-ui}
 #nvrArPanel button.on{border-color:#e0b64f;color:#f2c14e}#nvrArPanel .st{border:1px solid #2c3d57;border-radius:10px;padding:8px;margin:6px 0}#nvrArPanel small{color:#9fb0c7;display:block}`;
 function ui(){
   if(!document.getElementById('nvrArCss')){const st=document.createElement('style');st.id='nvrArCss';st.textContent=css;document.head.appendChild(st)}
   let b=document.getElementById('nvrArBtn');if(!b){b=document.createElement('button');b.id='nvrArBtn';b.textContent='🪖 Армии';b.onclick=()=>{U.open=!U.open;draw()};document.body.appendChild(b)}
   let p=document.getElementById('nvrArPanel');if(!p){p=document.createElement('div');p.id='nvrArPanel';document.body.appendChild(p)}return p}
 const stLabel=s=>({idle:'стоит',moving:'в пути',returning:'возвращается',fighting:'в бою'}[s.status]||s.status);
 function draw(){
   const p=ui(),s=S();p.style.display=U.open?'block':'none';if(!U.open||!s){layerDraw();return}
   const A=ensure(s),P=PG(),ready=P&&P.ready(),free=freeDivisions(s);
   let h=`<b>🪖 Армии на карте</b> <button onclick="NovariaArmiesUI.close()">✕</button>`;
   h+=ready?'':'<small>Карта провинций загружается… откройте карту мира и подождите.</small>';
   h+=`<div class="st"><b>Размещение</b><small>Свободных дивизий: ${free.length}</small>`;
   if(free.length&&ready){const own=ownProvinces(s);h+=`<select id="nvrArProv">${own.map(id=>`<option value="${esc(id)}">${esc(provName(id))}</option>`).join('')}</select><button onclick="NovariaArmiesUI.deployAll()">Разместить все резервы</button>`}
   h+='</div>';
   A.stacks.forEach(st=>{const sm=summary(s,st),on=U.sel===st.id;
     h+=`<div class="st"><b>${esc(st.name)}</b> · ${esc(stLabel(st))}<small>Провинция: ${esc(provName(st.prov))} · ${sm.men.toLocaleString('ru-RU')} чел. · ${sm.speed} км/сут.${st.dest?` · до ${esc(provName(st.dest))}: ${sm.eta} сут.`:''}</small>
     <button class="${on?'on':''}" onclick="NovariaArmiesUI.select(${st.id})">${on?'Выбрана':'Выбрать'}</button>${on?`<button class="${U.pick?'on':''}" onclick="NovariaArmiesUI.pick()">📍 Выбрать цель на карте</button>`:''}
     <button onclick="NovariaArmiesUI.stop(${st.id})">Стоп</button><button onclick="NovariaArmiesUI.recall(${st.id})">↩ Вернуть</button><button onclick="NovariaArmiesUI.disband(${st.id})">Распустить</button></div>`});
   if(U.pending&&U.pending.plan){const r=U.pending.plan;h+=`<div class="st"><b>Маршрут:</b> ${r.path.map(provName).map(esc).join(' → ')}<small>Время: ${r.days} сут. (${(r.days/30).toFixed(1)} мес.)</small><button class="on" onclick="NovariaArmiesUI.confirm()">✔ Подтвердить</button><button onclick="NovariaArmiesUI.cancel()">Отмена</button></div>`}
   else if(U.pending&&U.pending.err){h+=`<div class="st">⛔ ${esc(U.pending.err.message||'Маршрут недоступен')}${(U.pending.err.code==='ENEMY_TERRITORY'&&root.NovariaBattles)?`<br><button class="on" onclick="NovariaBattlesUI.attack(${U.sel},'${esc(U.pending.dest)}')">⚔ Атаковать</button>`:''}${U.pending.err.code==='NO_ACCESS'?`<br><button onclick="NovariaArmiesUI.access('${esc(U.pending.err.country)}')">Запросить военный доступ</button>`:''}</div>`}
   if(root.NovariaTerritoryUI)h+=root.NovariaTerritoryUI.panelHtml(s,esc,provName);if(root.NovariaBattlesUI)h+=root.NovariaBattlesUI.panelHtml(s,U.sel,esc,provName);const acc=Object.keys(A.access);if(acc.length)h+=`<small>Военный доступ: ${acc.map(esc).join(', ')}</small>`;
   h+=`<small>${A.log.slice(0,4).map(esc).join('<br>')}</small>`;
   p.innerHTML=h;layerDraw()}
 /* Слой на карте мира */
 function layer(){const w=root.WMAP&&root.WMAP.node;if(!w)return null;let g=w.querySelector('#nvrArmyLayer');if(!g){g=document.createElementNS('http://www.w3.org/2000/svg','g');g.id='nvrArmyLayer';w.appendChild(g)}else if(g!==w.lastChild)w.appendChild(g);return g}
 function layerDraw(){
   const s=S(),g=layer();if(!g||!s)return;const A=ensure(s),ns='http://www.w3.org/2000/svg',W=(G()||{}).W||1000,r=W*.0065;let h='';
   const sel=A.stacks.find(x=>x.id===U.sel);
   const route=(U.pending&&U.pending.plan&&sel)?[sel.prov].concat(U.pending.plan.path):(sel&&sel.path.length?[sel.prov].concat(sel.path):null);
   if(route){const pts=route.map(id=>regionOf(id)).filter(Boolean).map(q=>q.cx.toFixed(1)+','+q.cy.toFixed(1)).join(' ');h+=`<polyline points="${pts}" fill="none" stroke="#f2c14e" stroke-width="${r*.35}" stroke-dasharray="${r*.8} ${r*.5}" pointer-events="none"/>`}
   A.stacks.forEach(st=>{const q=regionOf(st.prov);if(!q)return;const on=st.id===U.sel;
     h+=`<g data-army="${st.id}" style="cursor:pointer"><circle cx="${q.cx}" cy="${q.cy}" r="${r*(on?1.25:1)}" fill="${on?'#f2c14e':'#b5504a'}" stroke="#fff" stroke-width="${r*.15}"/><text x="${q.cx}" y="${q.cy+r*.35}" text-anchor="middle" font-size="${r*.95}" fill="#101c2b" font-weight="700" pointer-events="none">${st.divs.length}</text></g>`;
     if(st.leg&&st.leg.to){const dest=regionOf(st.leg.to);if(dest){h+=`<g pointer-events="none"><circle r="${r*.72}" fill="#f2c14e" stroke="#fff" stroke-width="${r*.18}"><animateMotion dur="2.8s" repeatCount="indefinite" path="M ${q.cx} ${q.cy} L ${dest.cx} ${dest.cy}"/></circle><text x="${q.cx}" y="${q.cy-r*1.1}" font-size="${r*.7}" fill="#ffe08a">➤</text></g>`}}});
   g.innerHTML=h}
 document.addEventListener('click',ev=>{
   const s=S();if(!s)return;const a=ev.target.closest&&ev.target.closest('[data-army]');
   if(a){ev.preventDefault();ev.stopPropagation();U.sel=+a.getAttribute('data-army');U.open=true;U.pending=null;draw();return}
   if(U.pick&&U.sel!=null){const t=ev.target.closest&&ev.target.closest('[data-r]');if(!t)return;ev.preventDefault();ev.stopPropagation();
     const id=t.getAttribute('data-r'),st=find(s,U.sel);if(!st)return;const r=plan(s,st,id);U.pending=r.ok?{dest:id,plan:r}:{err:r,dest:id};U.pick=false;draw()}},true);
 root.NovariaArmiesUI={
   close(){U.open=false;U.pick=false;draw()},
   select(id){U.sel=id;U.pending=null;U.pick=false;draw()},
   pick(){U.pick=!U.pick;if(U.pick){U.open=true;const p=document.getElementById('nvrArPanel');if(p)p.style.maxHeight='28vh';NG()&&NG().toast&&NG().toast('Нажмите на провинцию-цель на карте')}draw()},
   deployAll(){const s=S(),el=document.getElementById('nvrArProv');if(!s||!el)return;const r=deploy(s,freeDivisions(s).map(d=>d.id),el.value);if(!r.ok)NG().toast(r.message);else U.sel=r.stack.id;NG().save();draw()},
   confirm(){const s=S();if(!s||!U.pending||!U.pending.plan)return;const r=order(s,U.sel,U.pending.dest);if(!r.ok)NG().toast(r.message);U.pending=null;NG().save();draw()},
   cancel(){U.pending=null;draw()},
   stop(id){const s=S();stop(s,id);NG().save();draw()},
   recall(id){const s=S();const r=recall(s,id);if(!r.ok)NG().toast(r.message);NG().save();draw()},
   disband(id){const s=S();disband(s,id);if(U.sel===id)U.sel=null;NG().save();draw()},
   access(n){const s=S();const r=requestAccess(s,n);NG().toast(r.ok?'Доступ получен':r.message);NG().save();U.pending=null;draw()},
   redraw:draw};
 setInterval(()=>{const s=S();if(!s||!document.body)return;ui();const A=s.armies;const sig=JSON.stringify([A&&A.stacks.map(x=>[x.id,x.prov,x.status,x.leg&&x.leg.left]),U.sel,U.open,!!(root.WMAP&&root.WMAP.node)]);if(sig!==U.sig){U.sig=sig;draw()}},1500);
})(typeof window!=='undefined'?window:globalThis);
