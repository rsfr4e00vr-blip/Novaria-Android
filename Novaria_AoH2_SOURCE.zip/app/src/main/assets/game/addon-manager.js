/* Novaria Add-on Manager — native Android + browser-local mod packages */
(function(){
  'use strict';
  const $=(s,r=document)=>r.querySelector(s), KEY='novaria_web_addons_v1';
  let panel=null,loaded=new Set();
  const safePath=p=>typeof p==='string'&&p.length>0&&!p.startsWith('/')&&!p.split(/[\\/]/).some(x=>x==='..'||x==='');
  function webItems(){try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(_){return[]}}
  function saveWeb(items){localStorage.setItem(KEY,JSON.stringify(items))}
  function ensure(){
    if(panel)return panel;
    panel=document.createElement('section');panel.id='nvrAddonPanel';panel.innerHTML=`
      <div class="nvr-addon-head"><div><small>NOVARIA WORKSHOP</small><h2>🧩 Дополнения</h2></div><button id="nvrAddonClose" aria-label="Закрыть">✕</button></div>
      <p class="nvr-addon-intro">Устанавливай новые страны, события, интерфейсы и игровые механики пакетами. Дополнения можно включать и отключать без переустановки игры.</p>
      <div class="nvr-addon-actions"><button id="nvrAddonImport" class="nvr-addon-primary">＋ Импортировать пакет</button><button id="nvrAddonRefresh">↻ Обновить список</button><input id="nvrAddonFile" type="file" accept=".novaria,.zip,application/zip" hidden></div>
      <div class="nvr-addon-format"><b>Формат пакета:</b> ZIP / .novaria с файлом <code>manifest.json</code>, JS и необязательными CSS-файлами.</div>
      <div id="nvrAddonList" class="nvr-addon-list"><div class="nvr-addon-empty">Загрузка дополнений…</div></div>
      <div class="nvr-addon-foot">Пакеты устанавливаются локально на этом устройстве. Перед установкой используй дополнения только из доверенных источников.</div>`;
    document.body.appendChild(panel);
    $('#nvrAddonClose',panel).onclick=close;
    $('#nvrAddonImport',panel).onclick=()=>{if(window.NovariaNative&&NovariaNative.chooseAddon)NovariaNative.chooseAddon();else $('#nvrAddonFile',panel).click()};
    $('#nvrAddonFile',panel).onchange=async e=>{const f=e.target.files&&e.target.files[0];if(!f)return;try{installPackage(await readZip(f));toastMsg('Пакет импортирован. Перезапусти игру для применения.')}catch(err){toastMsg('Ошибка пакета: '+err.message)}e.target.value=''};
    $('#nvrAddonRefresh',panel).onclick=refresh;
    return panel;
  }
  function toastMsg(t){if(typeof window.toast==='function')window.toast(t);else console.log(t)}
  function open(){ensure();panel.classList.add('open');refresh()}
  function close(){if(panel)panel.classList.remove('open')}
  function installPackage(files){
    if(!files||typeof files['manifest.json']!=='string')throw Error('В архиве отсутствует manifest.json');
    const m=JSON.parse(files['manifest.json']);
    if(!m||! /^[a-zA-Z0-9._-]{1,64}$/.test(m.id||'')||m.id==='.'||m.id==='..'||!String(m.name||'').trim())throw Error('Неверные ID или название мода');
    if(!safePath(m.entry)||!m.entry.endsWith('.js')||typeof files[m.entry]!=='string')throw Error('Не найден JS-файл entry');
    const styles=Array.isArray(m.styles)?m.styles:[];
    styles.forEach(p=>{if(!safePath(p)||!p.endsWith('.css')||typeof files[p]!=='string')throw Error('Не найден CSS-файл: '+p)});
    const total=Object.values(files).reduce((n,v)=>n+String(v).length,0);if(total>4*1024*1024)throw Error('Для браузерной версии размер мода ограничен 4 МБ');
    const item={id:m.id,name:String(m.name).slice(0,80),version:String(m.version||'1.0.0'),description:String(m.description||'Дополнение Novaria').slice(0,240),entry:m.entry,styles,multiplayerCompatible:!!m.multiplayerCompatible,enabled:true,files};
    if(window.NovariaNative&&NovariaNative.installAddonPackage){throw Error('Встроенный Android-установщик используется отдельно')}
    const items=webItems(),i=items.findIndex(x=>x.id===item.id);if(i>=0)items[i]=item;else items.push(item);saveWeb(items);refresh(false);return item;
  }
  async function readZip(file){
    const b=await file.arrayBuffer(),v=new DataView(b),u=new Uint8Array(b),dec=new TextDecoder();let eocd=-1;
    for(let i=u.length-22;i>=Math.max(0,u.length-65557);i--){if(v.getUint32(i,true)===0x06054b50){eocd=i;break}}
    if(eocd<0)throw Error('Не найден ZIP-каталог');
    const count=v.getUint16(eocd+10,true),start=v.getUint32(eocd+16,true),files={};let p=start;
    for(let i=0;i<count;i++){
      if(v.getUint32(p,true)!==0x02014b50)throw Error('Повреждён ZIP-каталог');
      const method=v.getUint16(p+10,true),cs=v.getUint32(p+20,true),nl=v.getUint16(p+28,true),el=v.getUint16(p+30,true),cl=v.getUint16(p+32,true),off=v.getUint32(p+42,true),name=dec.decode(u.slice(p+46,p+46+nl));
      if(!safePath(name)){p+=46+nl+el+cl;continue}
      if(v.getUint32(off,true)!==0x04034b50)throw Error('Повреждён файл '+name);
      const ln=v.getUint16(off+26,true),le=v.getUint16(off+28,true),from=off+30+ln+le,raw=u.slice(from,from+cs);let data;
      if(method===0)data=raw;else if(method===8&&typeof DecompressionStream!=='undefined'){const stream=new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'));data=new Uint8Array(await new Response(stream).arrayBuffer())}else throw Error('Не поддерживается ZIP-сжатие '+method);
      files[name]=dec.decode(data);p+=46+nl+el+cl;
    }
    return files;
  }
  function renderItems(items,isNative){
    const list=$('#nvrAddonList',ensure());
    if(!items.length){list.innerHTML='<div class="nvr-addon-empty">Пока нет установленных дополнений.<br>Нажми «Импортировать пакет» или создай мод во вкладке «Мастерская модов».</div>';return}
    list.innerHTML='';items.forEach(item=>{
      const card=document.createElement('article');card.className='nvr-addon-card';
      const info=document.createElement('div');info.className='nvr-addon-info';
      const name=document.createElement('b');name.textContent=item.name;
      const ver=document.createElement('span');ver.className='nvr-addon-version';ver.textContent='v'+item.version+(item.multiplayerCompatible?' · MP':' · одиночная');
      const desc=document.createElement('p');desc.textContent=item.description||'Дополнение Novaria';info.append(name,ver,desc);
      const controls=document.createElement('div');controls.className='nvr-addon-controls';
      const toggle=document.createElement('button');toggle.className=item.enabled?'nvr-addon-toggle enabled':'nvr-addon-toggle';toggle.textContent=item.enabled?'Включено':'Выключено';
      toggle.onclick=()=>{if(isNative){const ok=NovariaNative.setEnabled(item.id,!item.enabled);if(ok){refresh();toastMsg('Настройка сохранена. Перезапусти игру для применения.')}}else{const a=webItems(),x=a.find(z=>z.id===item.id);if(x){x.enabled=!x.enabled;saveWeb(a);refresh();toastMsg('Настройка сохранена. Перезапусти игру для применения.')}}};
      const del=document.createElement('button');del.className='nvr-addon-delete';del.textContent='Удалить';
      del.onclick=()=>{if(confirm('Удалить дополнение «'+item.name+'»?')){if(isNative){if(NovariaNative.deleteAddon(item.id)){loaded.delete(item.id);refresh();toastMsg('Дополнение удалено.')}}else{saveWeb(webItems().filter(x=>x.id!==item.id));loaded.delete(item.id);refresh();toastMsg('Дополнение удалено. Перезапусти игру, чтобы отключить его код.')}}};
      controls.append(toggle,del);card.append(info,controls);list.append(card);if(item.enabled&&!loaded.has(item.id)&&item._loadNow)loadAddon(item);
    });
  }
  function refresh(loadEnabled=false){
    const list=$('#nvrAddonList',ensure());
    if(loadEnabled)document.querySelectorAll('[data-nvr-addon]').forEach(el=>{if(el.tagName==='LINK')el.remove()});
    try{
      if(!window.NovariaNative){const items=webItems();renderItems(items,false);if(loadEnabled)items.filter(x=>x.enabled).forEach(loadAddon);return}
      const items=JSON.parse(NovariaNative.listAddons()||'[]');renderItems(items,true);if(loadEnabled)items.filter(x=>x.enabled).forEach(loadAddon);
    }catch(e){list.innerHTML='<div class="nvr-addon-empty">Ошибка чтения списка: '+String(e.message||e)+'</div>'}
  }
  function checkMultiplayer(){
    try{
      const items=window.NovariaNative?JSON.parse(NovariaNative.listAddons()||'[]'):webItems();
      const bad=items.filter(x=>x.enabled&&!x.multiplayerCompatible);
      if(bad.length)toastMsg('⚠ Для мультиплеера отключи одиночные моды: '+bad.map(x=>x.name).join(', ')+'. У всех игроков должны быть одинаковые MP-совместимые версии.');
      return bad.length===0;
    }catch(_){return true}
  }
  function loadAddon(item){
    if(loaded.has(item.id))return;
    if(item.files){
      (item.styles||[]).forEach(file=>{const style=document.createElement('style');style.dataset.nvrAddon=item.id;style.textContent=item.files[file]||'';document.head.appendChild(style)});
      const script=document.createElement('script');script.dataset.nvrAddon=item.id;script.textContent=item.files[item.entry]||'';document.body.appendChild(script);loaded.add(item.id);window.dispatchEvent(new CustomEvent('novaria-addon-loaded',{detail:item}));return;
    }
    if(!item.basePath)return;
    (item.styles||[]).forEach(file=>{const l=document.createElement('link');l.rel='stylesheet';l.href=item.basePath+file.split('/').map(encodeURIComponent).join('/');l.dataset.nvrAddon=item.id;document.head.appendChild(l)});
    if(item.entry){const script=document.createElement('script');script.src=item.basePath+item.entry.split('/').map(encodeURIComponent).join('/');script.dataset.nvrAddon=item.id;script.onload=()=>{loaded.add(item.id);window.dispatchEvent(new CustomEvent('novaria-addon-loaded',{detail:item}))};script.onerror=()=>toastMsg('Не удалось загрузить дополнение '+item.name);document.body.appendChild(script)}else loaded.add(item.id);
  }
  document.addEventListener('click',e=>{if(e.target.closest('#addonsMenuBtn')){e.preventDefault();open()}});
  window.addEventListener('novaria-addons-changed',e=>{if(e.detail&&e.detail.success){refresh(false);toastMsg('Пакет установлен. Перезапусти игру, чтобы применить обновление.')}});
  window.NovariaAddons={open,close,refresh,installPackage,checkMultiplayer};
  try{refresh(true)}catch(e){console.warn('[Novaria Add-ons]',e)}
})();
