/* Novaria Battle System v1.0 (Этап 10). Оригинальная реализация.
 * Бой за соседнюю вражескую провинцию: посуточные раунды, численность, типы войск, атака/оборона,
 * местность, укрепления, мораль, потери, отступление, разгром, подкрепления, история.
 * Победа НЕ меняет владельца провинции (это этап 11): она ставит отметку прорыва S.battles.breach[провинция]. */
(function(root){'use strict';
 const VERSION=1,DAYS=30,MAX_DAYS=40;
 const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
 const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
 const hash=s=>{let h=2166136261;s=String(s);for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0};
 const roll=(seed,lo,hi)=>{let x=seed>>>0||1;x^=x<<13;x>>>=0;x^=x>>>17;x^=x<<5;x>>>=0;return lo+x/4294967295*(hi-lo)};
 /* атака, оборона на 1000 чел.; бонус местности для атакующего */
 const UNIT={infantry:{a:42,d:58,t:{mountains:.9,forest:.95,urban:.9}},motorized:{a:58,d:45,t:{mountains:.75,forest:.8,urban:.85,plain:1.1}},mechanized:{a:75,d:62,t:{mountains:.65,forest:.75,urban:.8,plain:1.12}},armor:{a:92,d:68,t:{mountains:.55,forest:.7,urban:.65,hills:.85,plain:1.18,desert:1.1}},artillery:{a:82,d:28,t:{mountains:.8,hills:.9}},engineers:{a:32,d:78,t:{urban:1.15,forest:1.05}},recon:{a:48,d:35,t:{}},airborne:{a:70,d:42,t:{mountains:1.05,urban:1.1}}};
 const TERRAIN={plain:{n:'равнина',def:1},forest:{n:'лес',def:1.15},hills:{n:'холмы',def:1.25},mountains:{n:'горы',def:1.45},urban:{n:'город',def:1.3},desert:{n:'пустыня',def:1}};
 const AR=()=>root.NovariaArmies;
 const mer=l=>Math.log(Math.tan(Math.PI/4+l*Math.PI/360));
 function ensure(S){if(!S.battles||S.battles.version!==VERSION)S.battles={version:VERSION,nextId:1,active:[],history:[],breach:{}};return S.battles}
 /* Местность и укрепления: приближение, не реальные карты высот — детерминированно по id провинции, широте и роли города */
 function terrainOf(id){const A=AR(),r=A.regionOf(id),C=A.countryOf(id);if(!r)return 'plain';const h=hash('t'+id)%100,lat=Math.abs(A.latOf(r.cy));
   const big=C&&C.regs&&C.regs.length>1&&C.regs.every(x=>num(x.s)<=num(r.s));if(big&&h<55)return 'urban';
   if(h<16)return 'mountains';if(h<38)return 'hills';if(h<58)return 'forest';if(h<72&&lat<35)return 'desert';return 'plain'}
 function fortOf(id){const t=terrainOf(id),h=hash('f'+id)%4;return clamp((t==='urban'?2:(t==='mountains'||t==='hills')?1:0)+(h===0?1:0),0,3)}
 function garrisonOf(S,id){const A=AR(),C=A.countryOf(id),r=A.regionOf(id),own=A.ownerOf(S,id),rel=(S.relations||[]).find(x=>x.name===own),pw=num(rel&&rel.power,40),n=C&&C.regs?C.regs.length:1,f=clamp(num(r&&r.s,100/n)/(100/n),.5,2);
   return Math.round(clamp(pw*400*f,8000,300000)/100)*100}
 const divsOf=(S,st)=>((S.military&&S.military.divisions)||[]).filter(d=>st.divs.includes(d.id));
 const avg=(a,f,d)=>a.length?a.reduce((s,x)=>s+f(x),0)/a.length:d;
 function attackPower(S,st,terr,fortEff){const ds=divsOf(S,st);let P=0,men=0,art=0;
   ds.forEach(d=>{const u=UNIT[d.type]||UNIT.infantry,m=num(d.manpower);men+=m;if(d.type==='artillery'||d.type==='engineers')art+=m;
     P+=m/1000*u.a*(u.t[terr]||1)*(.6+num(d.equipment,60)/250)*(.7+num(d.experience)/200)});
   const mor=avg(ds,d=>num(d.morale,60),50),sup=avg(ds,d=>num(d.supply,75),75);
   return {P:P*(.55+mor/220)*(sup<25?.7:1),men,artShare:men?art/men:0}}
 /* ---- начало боя ---- */
 function targets(S,st){const P=root.NovariaProvinceGraph,A=AR();if(!P||!P.ready())return [];return P.neighbors(st.prov).filter(id=>{const o=A.ownerOf(S,id);if((ensure(S).breach[id]||{}).by===st.owner)return false;return o&&o!==st.owner&&A.atWarWith(S,o)})}
 function attack(S,stackId,target){
   const A=AR(),B=ensure(S),st=A.find(S,stackId);target=String(target);
   if(!st)return {ok:false,message:'Армия не найдена'};
   if(st.status!=='idle')return {ok:false,message:st.status==='fighting'?'Армия уже в бою':'Дождитесь остановки армии'};
   if(!divsOf(S,st).length)return {ok:false,message:'В армии нет дивизий'};
   const P=root.NovariaProvinceGraph;if(!P||!P.ready())return {ok:false,message:'Карта ещё загружается'};
   if(!P.areAdjacent(st.prov,target))return {ok:false,message:'Атаковать можно только соседнюю провинцию: сначала подведите армию к границе'};
   if((B.breach[target]||{}).by===st.owner)return {ok:false,message:'Прорыв уже достигнут — займите провинцию'};
   const owner=A.ownerOf(S,target);if(!owner||owner===st.owner)return {ok:false,message:'Это не вражеская провинция'};
   if(!A.atWarWith(S,owner))return {ok:false,message:`Нет войны с ${owner}: нападать нельзя`};
   if(B.active.some(b=>b.target===target&&b.attackerStack===st.id||b.target===target))return {ok:false,message:'За эту провинцию уже идёт бой'};
   const ds=divsOf(S,st),g=garrisonOf(S,target),terr=terrainOf(target),fort=fortOf(target);
   ds.forEach(d=>{d.front=null}); /* вне абстрактного фронта, иначе потери считались бы дважды */
   const b={id:B.nextId++,attackerStack:st.id,attackerName:st.name,attacker:st.owner,defender:owner,from:st.prov,target,terrain:terr,fort,day:0,started:num(S.year)*12+num(S.month),
     att0:ds.reduce((a,d)=>a+num(d.manpower),0),attMor:avg(ds,d=>num(d.morale,60),60),def0:g,def:g,defMor:65,attLost:0,defLost:0,log:[]};
   b.attMor=clamp(b.attMor,25,100);st.status='fighting';B.active.push(b);
   S.military&&S.military.log&&S.military.log.unshift(`⚔ Начат бой за ${AR().provName(target)} (${st.name})`);
   return {ok:true,battle:b}}
 /* ---- ход боя ---- */
 function finish(S,b,result,st){
   const B=ensure(S),A=AR(),dsAll=(S.military&&S.military.divisions)||[];
   b.result=result;b.ended=num(S.year)*12+num(S.month);
   if(st){st.status='idle';delete st.dest;st.path=[];st.leg=null;delete st.incoming}
   if(result==='attacker_victory'){B.breach[b.target]={by:b.attacker,from:b.from,defender:b.defender,year:S.year,month:S.month};if(st)st.home=st.prov}
   else if(st){const ds=divsOf(S,st);ds.forEach(d=>{d.morale=clamp(num(d.morale)-10,5,100)})}
   B.active=B.active.filter(x=>x.id!==b.id);
   B.history.unshift({id:b.id,year:S.year,month:S.month,days:b.day,attacker:b.attacker,defender:b.defender,army:b.attackerName,from:b.from,target:b.target,terrain:b.terrain,fort:b.fort,att0:b.att0,def0:b.def0,attLost:Math.round(b.attLost),defLost:Math.round(b.defLost),result});B.history.length=Math.min(B.history.length,50);if(root.NovariaMilitaryVisuals&&root.NovariaMilitaryVisuals.battleResult)root.NovariaMilitaryVisuals.battleResult(B.history[0]);
   S.military&&S.military.log&&S.military.log.unshift(`${{attacker_victory:'🏆 Победа',defender_victory:'🛡 Отступление',stalemate:'⏳ Затяжной бой, отход',ceasefire:'🕊 Бой прекращён (мир)',rout:'💥 Разгром армии'}[result]||result}: ${A.provName(b.target)}`)}
 function day(S,b){
   const A=AR(),st=A.find(S,b.attackerStack);
   if(!st){finish(S,b,'rout',null);return}
   if(!A.atWarWith(S,b.defender)){finish(S,b,'ceasefire',st);return}
   const own=A.ownerOf(S,b.target);if(own!==b.defender){finish(S,b,'ceasefire',st);return}
   b.day++;
   (st.incoming||[]).forEach(x=>{x.left--});const arr=(st.incoming||[]).filter(x=>x.left<=0);if(arr.length){st.incoming=st.incoming.filter(x=>x.left>0);arr.forEach(x=>st.divs.push(x.id));b.log.unshift(`День ${b.day}: подошли подкрепления (${arr.length} див.)`)}
   const ds=divsOf(S,st);if(!ds.length){finish(S,b,'rout',st);return}
   const T=TERRAIN[b.terrain]||TERRAIN.plain;
   const ap=attackPower(S,st,b.terrain,0);
   const cut=Math.floor((ap.artShare+0)/.12);const fortEff=Math.max(0,b.fort-cut);
   const dP=b.def/1000*58*T.def*(1+.18*fortEff)*(.55+b.defMor/220);
   const aP=ap.P,seed=hash(`${b.id}:${b.day}:${b.target}`);
   const fa=clamp(.035*dP/Math.max(1,aP),.002,.12)*roll(seed,.8,1.2),fd=clamp(.035*aP/Math.max(1,dP),.002,.12)*roll(seed^0x9e3779b9,.8,1.2);
   /* потери */
   let aLost=0;ds.forEach(d=>{const l=Math.min(num(d.manpower),Math.round(num(d.manpower)*fa*roll(hash(seed+':'+d.id),.85,1.15)));d.manpower-=l;d.losses=num(d.losses)+l;aLost+=l;d.experience=clamp(num(d.experience)+.3,0,100);d.equipment=clamp(num(d.equipment)-.3,0,100);d.supply=clamp(num(d.supply)-1,0,100)});
   const dLost=Math.round(b.def*fd);b.def=Math.max(0,b.def-dLost);b.attLost+=aLost;b.defLost+=dLost;
   if(aLost)S.army=Math.max(0,num(S.army)-aLost);
   /* мораль */
   b.attMor=clamp(b.attMor-fa*100*1.3+(aP>dP*1.15?.6:-.2),0,100);b.defMor=clamp(b.defMor-fd*100*1.3+(dP>aP*1.15?.6:-.2),0,100);
   ds.forEach(d=>{d.morale=b.attMor});
   /* подкрепления обороны: +1.5% в сутки до 120% исходного */
   if(b.defMor>20)b.def=Math.min(Math.round(b.def0*1.2),b.def+Math.round(b.def0*.015));
   /* убрать уничтоженные дивизии */
   const M=S.military;if(M){const dead=ds.filter(d=>d.manpower<=0).map(d=>d.id);if(dead.length){M.divisions=M.divisions.filter(d=>!dead.includes(d.id));st.divs=st.divs.filter(i=>!dead.includes(i))}}
   const left=divsOf(S,st).reduce((a,d)=>a+num(d.manpower),0);
   if(left<=0){finish(S,b,'rout',st);A.disband&&A.disband(S,st.id);return}
   const attBroken=b.attMor<20||left<b.att0*.12,defBroken=b.defMor<15||b.def<b.def0*.1;
   if(defBroken&&(!attBroken||b.defMor<=b.attMor)){b.def=0;finish(S,b,'attacker_victory',st);return}
   if(attBroken){ /* отступление: часть потерь в бегстве; при полном крахе — разгром */
     const rout=b.attMor<8||left<b.att0*.06;const fl=rout?.4:.03;let extra=0;
     divsOf(S,st).forEach(d=>{const l=Math.round(d.manpower*fl);d.manpower-=l;extra+=l});S.army=Math.max(0,num(S.army)-extra);b.attLost+=extra;
     finish(S,b,rout?'rout':'defender_victory',st);return}
   if(b.day>=MAX_DAYS){finish(S,b,'stalemate',st)}
 }
 function advance(S,days){const B=ensure(S);for(let k=0;k<days&&B.active.length;k++)B.active.slice().forEach(b=>{if(B.active.includes(b))day(S,b)})}
 function tick(S){if(!S)return;ensure(S);advance(S,DAYS)}
 function retreat(S,stackId){const B=ensure(S),b=B.active.find(x=>x.attackerStack===Number(stackId)),st=AR().find(S,stackId);if(!b||!st)return {ok:false,message:'Бой не найден'};
   let extra=0;divsOf(S,st).forEach(d=>{const l=Math.round(d.manpower*.03);d.manpower-=l;extra+=l});S.army=Math.max(0,num(S.army)-extra);b.attLost+=extra;finish(S,b,'defender_victory',st);return {ok:true}}
 function reinforce(S,stackId,divIds){const B=ensure(S),A=AR(),b=B.active.find(x=>x.attackerStack===Number(stackId)),st=A.find(S,stackId);if(!b||!st)return {ok:false,message:'Бой не найден'};
   const free=new Set(A.freeDivisions(S).map(d=>d.id)),ids=(divIds||[]).map(Number).filter(i=>free.has(i));if(!ids.length)return {ok:false,message:'Нет свободных дивизий'};
   st.incoming=(st.incoming||[]).concat(ids.map(id=>({id,left:3})));ids.forEach(id=>{const d=((S.military||{}).divisions||[]).find(x=>x.id===id);if(d)d.front=null});return {ok:true,count:ids.length,days:3}}
 function preview(S,stackId,target){const A=AR(),st=A.find(S,stackId);if(!st)return null;const t=terrainOf(target),f=fortOf(target),ap=attackPower(S,st,t,0),g=garrisonOf(S,target),T=TERRAIN[t];
   const dP=g/1000*58*T.def*(1+.18*Math.max(0,f-Math.floor(ap.artShare/.12)))*1.2;return {terrain:T.n,fort:f,garrison:g,men:ap.men,ratio:+(ap.P/Math.max(1,dP)).toFixed(2)}}
 root.NovariaBattles={version:VERSION,ensure,attack,advance,tick,retreat,reinforce,preview,targets,terrainOf,fortOf,garrisonOf,UNIT,TERRAIN};
 /* ================= Интерфейс ================= */
 if(typeof document==='undefined')return;
 const NG=()=>root.NG,S0=()=>NG()&&NG().S;
 const bar=v=>`<span style="display:inline-block;width:70px;height:7px;background:#2c3d57;border-radius:4px;vertical-align:middle"><i style="display:block;height:7px;width:${clamp(v,0,100)}%;background:${v>50?'#55c58a':v>25?'#f0bd58':'#ef6d72'};border-radius:4px"></i></span>`;
 const RES={attacker_victory:'победа (прорыв)',defender_victory:'отступление',stalemate:'затяжной бой',ceasefire:'мир',rout:'разгром'};
 root.NovariaBattlesUI={
  attack(id,target){const s=S0();const r=attack(s,id,target);NG().toast(r.ok?'⚔ Бой начался':r.message);if(r.ok&&root.NovariaMilitaryVisuals&&root.NovariaMilitaryVisuals.battleStart)root.NovariaMilitaryVisuals.battleStart(r.battle);NG().save();root.NovariaArmiesUI&&root.NovariaArmiesUI.cancel&&root.NovariaArmiesUI.cancel()},
  retreat(id){const s=S0();const r=retreat(s,id);NG().toast(r.ok?'Армия отступила':r.message);NG().save();root.NovariaArmiesUI.redraw()},
  reinforce(id){const s=S0(),A=AR(),r=reinforce(s,id,A.freeDivisions(s).map(d=>d.id));NG().toast(r.ok?`Подкрепления прибудут через ${r.days} сут.`:r.message);NG().save();root.NovariaArmiesUI.redraw()},
  panelHtml(s,sel,esc,pn){const B=ensure(s),A=AR();let h='';const st=sel!=null&&A.find(s,sel);
   if(st&&st.status==='idle'){const ts=targets(s,st);if(ts.length)h+=`<div class="st"><b>⚔ Цели для атаки</b>${ts.map(t=>{const p=preview(s,st.id,t);return `<small>${esc(pn(t))} (${esc(A.ownerOf(s,t))}) · ${p.terrain}, укрепл. ${p.fort} · гарнизон ~${p.garrison.toLocaleString('ru-RU')} · соотношение сил ${p.ratio}:1</small><button onclick="NovariaBattlesUI.attack(${st.id},'${esc(t)}')">⚔ Атаковать</button>`}).join('')}</div>`}
   B.active.forEach(b=>{h+=`<div class="st"><b>⚔ Бой за ${esc(pn(b.target))}</b><small>${esc(b.attackerName)} против ${esc(b.defender)} · день ${b.day} · ${(TERRAIN[b.terrain]||{}).n}, укрепл. ${b.fort}</small>
    <small>Наши: ${Math.round(b.att0-b.attLost).toLocaleString('ru-RU')} чел. ${bar(b.attMor)} мораль ${Math.round(b.attMor)}% · потери ${Math.round(b.attLost).toLocaleString('ru-RU')}</small><small>Враг: ${Math.round(b.def).toLocaleString('ru-RU')} чел. ${bar(b.defMor)} мораль ${Math.round(b.defMor)}% · потери ${Math.round(b.defLost).toLocaleString('ru-RU')}</small>
    <button onclick="NovariaBattlesUI.reinforce(${b.attackerStack})">➕ Подкрепления</button><button onclick="NovariaBattlesUI.retreat(${b.attackerStack})">↩ Отступить</button>${b.log.slice(0,2).map(x=>`<small>${esc(x)}</small>`).join('')}</div>`});
   if(B.history.length)h+=`<div class="st"><b>📜 История битв</b>${B.history.slice(0,5).map(x=>`<small>${x.year}.${(num(x.month)+1)} · ${esc(pn(x.target))}: ${RES[x.result]||x.result} · ${x.days} сут. · потери ${x.attLost.toLocaleString('ru-RU')} / ${x.defLost.toLocaleString('ru-RU')}</small>`).join('')}<small>Прорывы ждут захвата (этап 11): ${Object.keys(B.breach).length}</small></div>`;
   return h}};
 /* значки боёв на карте */
 setInterval(()=>{const s=S0(),w=root.WMAP&&root.WMAP.node;if(!s||!w||!s.battles)return;let g=w.querySelector('#nvrBattleLayer');if(!g){g=document.createElementNS('http://www.w3.org/2000/svg','g');g.id='nvrBattleLayer';g.setAttribute('pointer-events','none');w.appendChild(g)}
  const W=(root.GEO||{}).W||1000,r=W*.007,A=AR();g.innerHTML=s.battles.active.map(b=>{const q=A.regionOf(b.target);return q?`<g class="nvr-battle-marker"><circle cx="${q.cx}" cy="${q.cy}" r="${r*1.5}" fill="none" stroke="#ff705f" stroke-width="${r*.22}"><animate attributeName="r" values="${r*.8};${r*2.2};${r*.8}" dur="1.8s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;.25;1" dur="1.8s" repeatCount="indefinite"/></circle><text x="${q.cx}" y="${q.cy+r*.55}" text-anchor="middle" font-size="${r*1.8}">⚔</text></g>`:''}).join('')},2000);
})(typeof window!=='undefined'?window:globalThis);
