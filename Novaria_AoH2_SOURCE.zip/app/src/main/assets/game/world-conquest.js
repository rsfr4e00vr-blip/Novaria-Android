/* World Conquest 2019 — режим для Новарии (порт Kivy-версии). Самодостаточный модуль. */
(function(){
'use strict';
if(window.__WC2019)return; window.__WC2019=true;
var DATA=[["Россия",0.62,0.28,170],["Германия",0.5,0.3,36],["Франция",0.46,0.34,55],["Великобритания",0.44,0.28,24],["Италия",0.5,0.38,30],["Испания",0.44,0.4,50],["Португалия",0.41,0.41,9],["Польша",0.53,0.3,31],["Украина",0.57,0.32,60],["Беларусь",0.55,0.28,20],["Румыния",0.55,0.36,24],["Болгария",0.56,0.39,11],["Греция",0.55,0.43,13],["Сербия",0.53,0.38,8],["Хорватия",0.52,0.37,6],["Венгрия",0.53,0.34,9],["Австрия",0.51,0.34,8],["Швейцария",0.49,0.35,4],["Чехия",0.51,0.32,8],["Словакия",0.53,0.33,5],["Нидерланды",0.48,0.29,4],["Бельгия",0.47,0.31,3],["Дания",0.49,0.26,4],["Швеция",0.51,0.22,45],["Норвегия",0.48,0.2,38],["Финляндия",0.56,0.2,34],["Эстония",0.56,0.24,4],["Латвия",0.55,0.25,6],["Литва",0.54,0.26,7],["Молдова",0.56,0.35,3],["Ирландия",0.41,0.29,7],["Исландия",0.38,0.18,10],["Словения",0.51,0.36,2],["Босния",0.53,0.38,5],["Черногория",0.53,0.4,1],["Македония",0.54,0.41,3],["Албания",0.54,0.4,3],["Люксембург",0.47,0.31,1],["Мальта",0.5,0.43,1],["Кипр",0.58,0.44,1],["Китай",0.72,0.34,260],["Индия",0.66,0.45,90],["Япония",0.82,0.34,38],["Южная Корея",0.8,0.36,10],["Северная Корея",0.8,0.34,12],["Монголия",0.72,0.3,40],["Казахстан",0.62,0.3,70],["Узбекистан",0.6,0.37,45],["Туркменистан",0.58,0.38,49],["Таджикистан",0.62,0.39,14],["Кыргызстан",0.63,0.37,20],["Афганистан",0.62,0.41,65],["Пакистан",0.64,0.44,88],["Иран",0.6,0.42,165],["Ирак",0.57,0.42,44],["Сирия",0.56,0.41,18],["Турция",0.54,0.4,78],["Саудовская Аравия",0.57,0.47,215],["Йемен",0.59,0.51,52],["Оман",0.61,0.49,31],["ОАЭ",0.6,0.47,8],["Катар",0.59,0.46,1],["Кувейт",0.58,0.45,2],["Иордания",0.55,0.44,9],["Ливан",0.55,0.42,1],["Израиль",0.55,0.44,2],["Грузия",0.56,0.38,7],["Армения",0.56,0.39,3],["Азербайджан",0.58,0.38,9],["Вьетнам",0.75,0.44,33],["Лаос",0.73,0.43,24],["Камбоджа",0.72,0.46,18],["Таиланд",0.72,0.45,51],["Мьянма",0.7,0.43,68],["Бангладеш",0.69,0.44,15],["Бутан",0.69,0.42,4],["Непал",0.67,0.42,15],["Шри-Ланка",0.66,0.49,6],["Малайзия",0.75,0.49,33],["Сингапур",0.75,0.5,1],["Индонезия",0.77,0.52,190],["Филиппины",0.79,0.46,30],["Бруней",0.76,0.48,1],["Тимор-Лесте",0.79,0.53,2],["Мальдивы",0.66,0.5,1],["Алжир",0.48,0.44,238],["Марокко",0.44,0.42,45],["Тунис",0.48,0.4,16],["Ливия",0.5,0.44,175],["Египет",0.53,0.45,100],["Судан",0.53,0.49,190],["Южный Судан",0.53,0.52,62],["Эфиопия",0.56,0.51,110],["Эритрея",0.56,0.48,12],["Джибути",0.57,0.49,2],["Сомали",0.58,0.51,64],["Кения",0.56,0.54,58],["Уганда",0.55,0.53,24],["Танзания",0.56,0.56,95],["Руанда",0.54,0.54,3],["Бурунди",0.54,0.55,3],["ДР Конго",0.52,0.55,234],["Конго",0.51,0.54,34],["ЦАР",0.52,0.52,62],["Чад",0.51,0.49,128],["Камерун",0.5,0.52,48],["Нигерия",0.48,0.51,92],["Нигер",0.49,0.47,127],["Мали",0.44,0.47,124],["Мавритания",0.42,0.46,103],["Сенегал",0.41,0.48,20],["Гамбия",0.4,0.48,1],["Гвинея-Бисау",0.4,0.49,4],["Гвинея",0.41,0.49,25],["Сьерра-Леоне",0.41,0.5,7],["Либерия",0.41,0.51,11],["Кот-д'Ивуар",0.43,0.51,32],["Гана",0.44,0.51,24],["Того",0.45,0.51,6],["Бенин",0.46,0.51,11],["Буркина-Фасо",0.46,0.49,27],["Габон",0.5,0.54,27],["Экв. Гвинея",0.49,0.53,3],["Ангола",0.51,0.58,125],["Замбия",0.54,0.57,75],["Зимбабве",0.54,0.6,39],["Мозамбик",0.56,0.59,80],["Малави",0.55,0.57,12],["Намибия",0.51,0.62,82],["Ботсвана",0.53,0.62,58],["ЮАР",0.53,0.65,122],["Лесото",0.53,0.64,3],["Эсватини",0.55,0.63,2],["Мадагаскар",0.58,0.62,59],["Маврикий",0.6,0.61,1],["Сейшелы",0.61,0.55,1],["Кабо-Верде",0.38,0.47,1],["Сан-Томе",0.49,0.54,1],["Коморы",0.59,0.58,1],["США",0.2,0.3,380],["Канада",0.2,0.2,400],["Мексика",0.18,0.42,76],["Гватемала",0.18,0.47,11],["Белиз",0.18,0.46,2],["Гондурас",0.19,0.47,11],["Сальвадор",0.18,0.48,2],["Никарагуа",0.19,0.49,13],["Коста-Рика",0.19,0.5,5],["Панама",0.2,0.51,7],["Куба",0.21,0.45,11],["Ямайка",0.22,0.46,1],["Гаити",0.23,0.46,3],["Доминикана",0.24,0.46,5],["Багамы",0.21,0.44,1],["Тринидад",0.25,0.49,1],["Барбадос",0.26,0.49,1],["Гренада",0.25,0.49,1],["Сент-Люсия",0.25,0.49,1],["Антигуа",0.25,0.47,1],["Сент-Китс",0.25,0.47,1],["Сент-Винсент",0.25,0.49,1],["Доминика",0.25,0.48,1],["Бразилия",0.3,0.55,450],["Аргентина",0.28,0.65,180],["Колумбия",0.26,0.51,88],["Венесуэла",0.27,0.49,95],["Перу",0.25,0.56,128],["Чили",0.26,0.68,76],["Боливия",0.27,0.6,110],["Эквадор",0.24,0.53,25],["Парагвай",0.29,0.62,40],["Уругвай",0.3,0.66,18],["Гайана",0.3,0.5,21],["Суринам",0.31,0.5,16],["Австралия",0.85,0.66,400],["Новая Зеландия",0.96,0.72,27],["Папуа-Н.Гвинея",0.88,0.53,46],["Фиджи",0.97,0.58,2],["Соломоновы о-ва",0.92,0.55,3],["Вануату",0.93,0.59,1],["Самоа",0.97,0.59,1],["Тонга",0.98,0.62,1],["Кирибати",0.99,0.55,1],["Маршалловы о-ва",0.95,0.51,1],["Микронезия",0.92,0.49,1],["Палау",0.88,0.48,1],["Науру",0.93,0.53,1],["Тувалу",0.96,0.55,1],["Косово",0.53,0.38,2],["Ватикан",0.5,0.38,1],["Сан-Марино",0.5,0.37,1],["Андорра",0.45,0.37,1],["Монако",0.48,0.37,1],["Лихтенштейн",0.5,0.34,1]];

/* ---------- цвета ---------- */
function hsv(h,s,v){var i=Math.floor(h*6),f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);i%=6;
 return [[v,t,p],[q,v,p],[p,v,t],[p,q,v],[t,p,v],[v,p,q]][i];}
function colorOf(i){var h=(i*0.61803398875)%1,s=0.6+0.3*((i%3)/3),v=0.6+0.3*((i%5)/5),c=hsv(h,s,v);
 return 'rgb('+Math.round(c[0]*255)+','+Math.round(c[1]*255)+','+Math.round(c[2]*255)+')';}

/* ---------- состояние ---------- */
var nations=[],player=null,ais=[],turn=1,year=2019,msg='',logs=[],over=null,sel=null;
var rnd=Math.random;
function ri(a,b){return a+Math.floor(rnd()*(b-a+1));}
function addLog(t){logs.push(t);if(logs.length>8)logs.shift();}

function Nation(i,d){
 this.idx=i;this.name=d[0];this.cx=d[1];this.cy=d[2];this.size=d[3];this.color=colorOf(i);
 this.treasury=Math.max(50,d[3]*2);this.army=Math.max(10,Math.floor(d[3]/2));this.tech=1;
 this.alive=true;this.allies=new Set();this.atWar=new Set();
}
Nation.prototype.income=function(){return Math.max(1,Math.floor(this.size/5)+2)+this.tech;};

function AI(n){this.n=n;this.aggr=0.3+rnd()*0.6;}
AI.prototype.target=function(){
 var n=this.n,c=[];
 nations.forEach(function(o){
  if(o===n||!o.alive||n.allies.has(o.name))return;
  var d=Math.hypot(o.cx-n.cx,o.cy-n.cy);if(d>0.25)return;
  c.push([(1/(o.army+Math.floor(o.treasury/10)+1))*(1/(d+0.01))*this.aggr,o]);
 },this);
 if(!c.length)return null;
 c.sort(function(a,b){return b[0]-a[0];});
 return rnd()<0.7?c[0][1]:c[Math.floor(rnd()*c.length)][1];
};
AI.prototype.act=function(){
 var n=this.n;
 if(n.treasury>50&&n.army<Math.floor(n.size/2)){var add=Math.min(10,Math.floor(n.treasury/30));n.army+=add;n.treasury-=add*5;}
 if(rnd()<0.05){
  var others=nations.filter(function(o){return o!==n&&o.alive&&!n.allies.has(o.name)&&!n.atWar.has(o.name);});
  others.sort(function(a,b){return b.army-a.army;});
  var top=others.slice(0,3);
  for(var k=0;k<top.length;k++){if(rnd()<0.5){n.allies.add(top[k].name);top[k].allies.add(n.name);addLog('Союз: '+n.name+' + '+top[k].name);break;}}
 }
 if(rnd()<this.aggr*0.5){var t=this.target();if(t&&n.army>t.army*0.8)battle(n,t);}
};
function battle(a,d){
 var atk=a.army+ri(0,20)+a.tech*3,dfn=d.army+ri(0,20)+d.tech*3;
 if(atk>dfn){
  var ratio=Math.min(0.5,(atk-dfn)/Math.max(atk,1)),cap=Math.max(1,Math.floor(d.size*ratio));
  d.size=Math.max(0,d.size-cap);a.size+=cap;
  a.army=Math.max(1,a.army-Math.floor(dfn/3));d.army=Math.max(0,d.army-Math.floor(cap/2));
  a.atWar.add(d.name);d.atWar.add(a.name);a.allies.delete(d.name);d.allies.delete(a.name);
  addLog(a.name+' → '+d.name+' (взято '+cap+')');
  if(d.size<=0){d.alive=false;addLog('☠ '+d.name+' уничтожена');}
 }else{
  a.army=Math.max(1,a.army-Math.floor(dfn/4));
  addLog(a.name+' атаковала '+d.name+' — провал');
 }
}
function init(){
 nations=DATA.map(function(d,i){return new Nation(i,d);});
 player=nations[0];player.name='Россия (Вы)';
 ais=nations.slice(1).map(function(n){return new AI(n);});
 turn=1;year=2019;msg='Тапни страну на карте';logs=[];over=null;sel=null;
}
function checkEnd(){
 var alive=nations.filter(function(n){return n.alive&&n.size>0;});
 if(player.size<=0||!player.alive)over='lose';
 else if(alive.length===1&&alive[0]===player)over='win';
}
function endTurn(){
 if(over)return;turn++;year++;
 nations.forEach(function(n){if(n.alive)n.treasury+=n.income();});
 ais.forEach(function(a){if(a.n.alive)a.act();});
 msg='Ход '+turn+', '+year;checkEnd();
}
function aAttack(t){
 if(over)return;
 if(!t||t===player){msg='Выбери врага';return;}
 if(!t.alive){msg='Страна уже уничтожена';return;}
 if(player.allies.has(t.name)){msg='Это союзник';return;}
 if(player.treasury<20){msg='Нужно 20 золота';return;}
 player.treasury-=20;battle(player,t);msg='Атака на '+t.name+'!';checkEnd();
}
function aRecruit(){
 if(over)return;if(player.treasury<30){msg='Нужно 30 золота';return;}
 player.treasury-=30;player.army+=5;msg='+5 армии';
}
function aAlly(t){
 if(over)return;
 if(!t||t===player){msg='Выбери страну';return;}
 if(!t.alive){msg='Страна уже уничтожена';return;}
 if(player.treasury<50){msg='Нужно 50 золота';return;}
 player.treasury-=50;
 if(rnd()<0.5){player.allies.add(t.name);t.allies.add(player.name);msg='Союз с '+t.name+'!';addLog('Союз: Вы + '+t.name);}
 else msg=t.name+' отказала';
}

/* ---------- UI ---------- */
var css=document.createElement('style');
css.textContent='#wc19{position:fixed;inset:0;z-index:10001;display:none;background:#0d1522;color:#e6e6ee;font:14px system-ui,sans-serif;flex-direction:row}'+
'#wc19.on{display:flex}#wc19 .wcmap{position:relative;flex:1;min-width:0;min-height:0}#wc19 canvas{position:absolute;inset:0;width:100%;height:100%;touch-action:none}'+
'#wc19 .wcside{width:290px;max-width:42%;display:flex;flex-direction:column;gap:6px;padding:8px;background:#141c2d;border-left:1px solid #3a3a5c;overflow:auto}'+
'#wc19 .wcstat{font-size:13px;line-height:1.45;white-space:pre-line}#wc19 .wcmsg{color:#f2e48a;min-height:34px;font-size:13px}'+
'#wc19 .wcsel{font-size:12px;color:#b8c4dc;white-space:pre-line;min-height:48px}#wc19 .wclog{font-size:11px;color:#9aa6bf;white-space:pre-line}'+
'#wc19 .wcrow{display:flex;gap:6px}#wc19 .wcrow button{flex:1;min-height:44px;border:1px solid #4a4a6a;border-radius:6px;color:#fff;font:600 13px system-ui;padding:6px 4px}'+
'#wc19 .a{background:#8c3333}#wc19 .b{background:#33597f}#wc19 .c{background:#59337f}#wc19 .d{background:#33802f}#wc19 .e{background:#7f3f3f}#wc19 .f{background:#40406a}'+
'#wc19 .wcx{position:absolute;left:8px;top:8px;z-index:2;padding:8px 12px;border-radius:10px;border:1px solid #e0b64f;background:#101c2bee;color:#f2c14e;font:600 13px system-ui}'+
'#wc19 .wcend{position:absolute;inset:0;display:none;align-items:center;justify-content:center;background:#000a;font-size:24px;font-weight:700;text-align:center;z-index:3}'+
'@media (orientation:portrait){#wc19{flex-direction:column}#wc19 .wcside{width:auto;max-width:none;height:42%;border-left:0;border-top:1px solid #3a3a5c}}';
document.head.appendChild(css);

var root=document.createElement('div');root.id='wc19';
root.innerHTML='<div class="wcmap"><canvas></canvas><button class="wcx">✕ К игре</button><div class="wcend"></div></div>'+
'<div class="wcside"><div class="wcstat"></div><div class="wcmsg"></div><div class="wcsel"></div>'+
'<div class="wcrow"><button class="a" data-a="atk">Атака<br>20 золота</button><button class="b" data-a="rec">Найм<br>30 золота</button><button class="c" data-a="ally">Союз<br>50 золота</button></div>'+
'<div class="wcrow"><button class="d" data-a="turn">Ход ▶</button><button class="e" data-a="new">Заново</button><button class="f" data-a="fit">Сброс вида</button></div>'+
'<div class="wclog"></div></div>';
document.body.appendChild(root);
var cv=root.querySelector('canvas'),ctx=cv.getContext('2d');
var elStat=root.querySelector('.wcstat'),elMsg=root.querySelector('.wcmsg'),elSel=root.querySelector('.wcsel'),elLog=root.querySelector('.wclog'),elEnd=root.querySelector('.wcend');

var W=1,H=1,dpr=1,view={k:1,x:0,y:0},dirty=true,running=false;
function resize(){
 var r=cv.getBoundingClientRect();dpr=window.devicePixelRatio||1;
 W=Math.max(1,r.width);H=Math.max(1,r.height);cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);dirty=true;
}
function px(n){return view.x+n.cx*W*view.k;}
function py(n){return view.y+n.cy*H*view.k;}
function rad(n){return Math.max(3,Math.sqrt(n.size)*1.2*(W/400)*Math.sqrt(view.k));}
function clampView(){
 var minX=W-W*view.k,minY=H-H*view.k;
 view.x=Math.min(0,Math.max(minX,view.x));view.y=Math.min(0,Math.max(minY,view.y));
}
function draw(){
 dirty=false;ctx.setTransform(dpr,0,0,dpr,0,0);
 ctx.fillStyle='#1a2e4d';ctx.fillRect(0,0,W,H);
 ctx.strokeStyle='#243857';ctx.lineWidth=0.5;
 var step=W*view.k/20;
 for(var i=1;i<20;i++){var gx=view.x+i*step;ctx.beginPath();ctx.moveTo(gx,0);ctx.lineTo(gx,H);ctx.stroke();}
 for(var j=1;j<20;j++){var gy=view.y+j*step*(H/W);ctx.beginPath();ctx.moveTo(0,gy);ctx.lineTo(W,gy);ctx.stroke();}
 var list=nations.filter(function(n){return n.alive&&n.size>0;}).sort(function(a,b){return b.size-a.size;});
 list.forEach(function(n){
  var x=px(n),y=py(n),r=rad(n);
  if(x<-r||y<-r||x>W+r||y>H+r)return;
  ctx.fillStyle=n.color;ctx.beginPath();ctx.arc(x,y,r,0,6.2832);ctx.fill();
  var ring=null,lw=1;
  if(n===player){ring='#ffff00';lw=2;r+=2;}
  else if(player.allies.has(n.name)){ring='rgba(255,255,255,.85)';r+=1;}
  else if(player.atWar.has(n.name)){ring='#cc0000';lw=1.5;r+=1;}
  if(ring){ctx.strokeStyle=ring;ctx.lineWidth=lw;ctx.beginPath();ctx.arc(x,y,r,0,6.2832);ctx.stroke();}
  if(n===sel){ctx.strokeStyle='#ffff66';ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y,rad(n)+5,0,6.2832);ctx.stroke();}
  if(n===sel||n===player||view.k>=2.5||(view.k>=1.5&&n.size>=40)){
   ctx.fillStyle='#fff';ctx.font='11px system-ui';ctx.textAlign='center';ctx.fillText(n.name,x,y-rad(n)-4);
  }
 });
}
function nationAt(tx,ty){
 var best=null,bd=1e9;
 nations.forEach(function(n){
  if(!n.alive||n.size<=0)return;
  var d=Math.hypot(tx-px(n),ty-py(n)),r=Math.max(10,rad(n))+6;
  if(d<r&&d<bd){bd=d;best=n;}
 });
 return best;
}
function relation(n){return n===player?'это вы':player.allies.has(n.name)?'союзник':player.atWar.has(n.name)?'война':'нейтрал';}
function refresh(){
 if(!player)return;
 var alive=nations.filter(function(n){return n.alive;}),total=alive.reduce(function(s,n){return s+n.size;},0);
 var pct=Math.floor(player.size*100/Math.max(1,total));
 elStat.textContent='Ход '+turn+' | '+year+' | Мир: '+pct+'%\nЗолото '+player.treasury+'  Армия '+player.army+'  Стран '+alive.length+'\nДоход +'+player.income()+'  Союзы '+player.allies.size+'  Враги '+player.atWar.size;
 elMsg.textContent=over==='win'?'ПОБЕДА! Мир завоёван!':over==='lose'?'ПОРАЖЕНИЕ… Нажми «Заново»':msg;
 elSel.textContent=sel?(sel.name+' ('+relation(sel)+')\nЗемли '+sel.size+' · Армия '+sel.army+' · Золото '+sel.treasury):'Страна не выбрана. Тап — выбрать, перетаскивание и щипок — карта.';
 elLog.textContent=logs.join('\n');
 elEnd.style.display=over?'flex':'none';
 elEnd.textContent=over==='win'?'🏆 ПОБЕДА! Мир завоёван!':over==='lose'?'💀 ПОРАЖЕНИЕ':'';
 if(over)elEnd.onclick=function(){elEnd.style.display='none';};
}
function loop(){
 if(!running)return;
 if(dirty)draw();
 requestAnimationFrame(loop);
}
function mark(){dirty=true;refresh();}

/* жесты: тап / перетаскивание / щипок / колесо */
var ptrs={},moved=false,startPt=null,lastDist=0;
cv.addEventListener('pointerdown',function(e){
 cv.setPointerCapture(e.pointerId);ptrs[e.pointerId]={x:e.offsetX,y:e.offsetY};
 var ids=Object.keys(ptrs);
 if(ids.length===1){moved=false;startPt={x:e.offsetX,y:e.offsetY};}
 if(ids.length===2){var a=ptrs[ids[0]],b=ptrs[ids[1]];lastDist=Math.hypot(a.x-b.x,a.y-b.y);moved=true;}
});
cv.addEventListener('pointermove',function(e){
 var p=ptrs[e.pointerId];if(!p)return;
 var ids=Object.keys(ptrs);
 if(ids.length===1){
  var dx=e.offsetX-p.x,dy=e.offsetY-p.y;
  if(!moved&&Math.hypot(e.offsetX-startPt.x,e.offsetY-startPt.y)>8)moved=true;
  if(moved){view.x+=dx;view.y+=dy;clampView();dirty=true;}
 }else if(ids.length===2){
  p.x=e.offsetX;p.y=e.offsetY;
  var a=ptrs[ids[0]],b=ptrs[ids[1]],d=Math.hypot(a.x-b.x,a.y-b.y);
  if(lastDist>0)zoomAt((a.x+b.x)/2,(a.y+b.y)/2,d/lastDist);
  lastDist=d;return;
 }
 p.x=e.offsetX;p.y=e.offsetY;
});
function endPtr(e){
 var had=ptrs[e.pointerId];delete ptrs[e.pointerId];
 if(had&&Object.keys(ptrs).length===0&&!moved&&e.type==='pointerup'){
  var n=nationAt(e.offsetX,e.offsetY);
  if(n){sel=n;msg='Выбрано: '+n.name;mark();}
 }
 lastDist=0;
}
cv.addEventListener('pointerup',endPtr);cv.addEventListener('pointercancel',endPtr);
function zoomAt(x,y,f){
 var nk=Math.min(8,Math.max(1,view.k*f));f=nk/view.k;
 view.x=x-(x-view.x)*f;view.y=y-(y-view.y)*f;view.k=nk;clampView();dirty=true;
}
cv.addEventListener('wheel',function(e){e.preventDefault();zoomAt(e.offsetX,e.offsetY,e.deltaY<0?1.2:1/1.2);},{passive:false});

root.querySelector('.wcside').addEventListener('click',function(e){
 var b=e.target.closest('button');if(!b)return;
 var a=b.getAttribute('data-a');
 if(a==='atk')aAttack(sel);else if(a==='rec')aRecruit();else if(a==='ally')aAlly(sel);
 else if(a==='turn')endTurn();else if(a==='new'){init();view={k:1,x:0,y:0};}
 else if(a==='fit'){view={k:1,x:0,y:0};}
 mark();
});

function open(){
 if(!player)init();
 root.classList.add('on');running=true;resize();refresh();requestAnimationFrame(loop);
}
function close(){root.classList.remove('on');running=false;}
root.querySelector('.wcx').onclick=close;
window.addEventListener('resize',function(){if(running)resize();});
window.addEventListener('orientationchange',function(){setTimeout(function(){if(running)resize();},250);});

/* кнопка запуска в меню «Ещё» */
function addMenu(){
 var m=document.getElementById('more'),btn=document.createElement('button');
 btn.textContent='🌍 Завоевание мира 2019';
 btn.onclick=function(){if(m){m.style.display='none';m.classList.remove('open');}open();};
 if(m){m.insertBefore(btn,m.firstChild);}
 else{btn.style.cssText='position:fixed;right:8px;bottom:8px;z-index:9998;padding:8px 12px;border-radius:10px;border:1px solid #e0b64f;background:#101c2bee;color:#f2c14e;font:600 14px system-ui';document.body.appendChild(btn);}
}
addMenu();
window.WC2019={open:open,close:close,_t:{init:init,endTurn:endTurn,battle:battle,nations:function(){return nations;},player:function(){return player;},attack:aAttack,recruit:aRecruit,ally:aAlly,over:function(){return over;}}};
})();
