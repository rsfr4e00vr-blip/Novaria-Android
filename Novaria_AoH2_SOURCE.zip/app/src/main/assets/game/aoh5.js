/* aoh5: реальные области страны игрока: точные войска, мобилизация, стройка, переброска */
(function(){'use strict';
var NS='http://www.w3.org/2000/svg',SLOTS=4;
var OB={
 farm:{n:'Ферма',ic:'🌾',c:80,m:4,fx:function(p,o){p.wealth=Math.min(100,(p.wealth||50)+1)}},
 factory:{n:'Завод',ic:'🏭',c:180,m:8,fx:function(p,o){p.industry=Math.min(100,(p.industry||40)+2);p.wealth=Math.min(100,(p.wealth||50)+1)}},
 barracks:{n:'Казармы',ic:'🏕',c:140,m:6,fx:function(p,o){o.m+=2500}},
 fort:{n:'Укрепления',ic:'🧱',c:160,m:6,fx:function(p,o){o.d+=15}},
 port:{n:'Порт',ic:'⚓',c:170,m:7,fx:function(p,o){p.wealth=Math.min(100,(p.wealth||50)+2);p.infra=Math.min(100,(p.infra||50)+1)}},
 market:{n:'Рынок',ic:'🏪',c:130,m:5,fx:function(p,o){p.wealth=Math.min(100,(p.wealth||50)+2)}}
};
var fmt=function(n){return Math.round(n||0).toLocaleString('ru-RU')};
var toast=function(t){try{NG.toast(t)}catch(e){}};
var log=function(t){try{NG.log(t)}catch(e){}};
var save=function(){try{NG.save()}catch(e){}};
var short=function(n){return String(n||'').replace(/ область$/,'')};
var ownC=null,sel=null,mvMode=null,amt='all',multi={},msMode=false,showAll=false;
var spr=function(k,px){return window.NVSPR?NVSPR.svg(k,px||22):''};
var nMulti=function(){return Object.keys(multi).filter(function(k){return multi[k]})};

function geoOwn(){var G=window.GEO;if(!G||!G.c||!window.S||!S.name)return null;
 if(ownC&&ownC.name===S.name)return ownC;
 var k=Object.keys(G.c).find(function(i){return G.c[i].name===S.name});
 ownC=k&&G.c[k].regs&&G.c[k].regs.length>1?G.c[k]:null;return ownC}
function regs(){var C=geoOwn();return C?C.regs.filter(function(r){return r.n}):[]}
function dist(total,ws){var sw=ws.reduce(function(a,b){return a+b},0)||1,o=ws.map(function(w){return Math.floor(total*w/sw)}),rem=total-o.reduce(function(a,b){return a+b},0);
 ws.map(function(w,i){return [total*w/sw-o[i],i]}).sort(function(a,b){return b[0]-a[0]}).forEach(function(x,k){if(k<rem)o[x[1]]++});return o}
function ens(){var R=regs();if(!R.length)return false;
 if(!S.ob||S.ob._for!==S.name||S.ob._n!==R.length){
  var ws=R.map(function(r){return +r.s||1}),A=dist(Math.round(S.army||0),ws),
   man=S.regions.reduce(function(t,r){return t+(r.manpower||0)},0),M=dist(man,ws);
  S.ob={_for:S.name,_n:R.length};S.mv=[];
  R.forEach(function(r,i){S.ob[r.id]={t:A[i],m:M[i],mob:0,d:0,b:[],q:[]}})}
 S.mv=S.mv||[];
 /* согласование суммы с общей численностью армии (потери на войне, найм из других панелей) */
 var tot=S.mv.reduce(function(t,m){return t+m.n},0),ids=R.map(function(r){return r.id});ids.forEach(function(id){tot+=S.ob[id].t});
 var diff=Math.round(S.army||0)-tot;
 if(diff>0){var D=dist(diff,R.map(function(r){return +r.s||1}));ids.forEach(function(id,i){S.ob[id].t+=D[i]})}
 else if(diff<0){var Z=dist(-diff,ids.map(function(id){return S.ob[id].t}));ids.forEach(function(id,i){S.ob[id].t=Math.max(0,S.ob[id].t-Z[i])})}
 return true}
function reg(id){return regs().find(function(r){return r.id===id})}
function parent(id){var R=regs(),i=R.findIndex(function(r){return r.id===id});return S.regions[Math.min(S.regions.length-1,Math.floor(i*S.regions.length/R.length))]}
function eta(a,b){var A=reg(a),B=reg(b),C=geoOwn(),w=Math.max(20,(C.bb?C.bb[2]-C.bb[0]:60));var d=Math.hypot(A.cx-B.cx,A.cy-B.cy);return Math.max(1,Math.min(3,Math.ceil(d/(w/3))))}

/* ---------- прибрежные области: порт только у моря ---------- */
var coastCache={};
function coastal(id){if(id in coastCache)return coastCache[id];var res=true;
 try{var svg=bg.querySelector('svg'),el=svg.querySelector('[data-r="'+id+'"]');if(!el||!el.getTotalLength||!el.isPointInFill)throw 0;
  var ps=[].slice.call(svg.querySelectorAll('path[data-r]')).filter(function(p){return p!==el}),bb=ps.map(function(p){return p.getBBox()}),
   L=el.getTotalLength(),N=60,run=0,best=0,d=Math.max(.3,Math.min(L/200,1.2));
  for(var i=0;i<N;i++){var l=L*i/N,p=el.getPointAtLength(l),q=el.getPointAtLength(Math.min(L,l+L/400)),tx=q.x-p.x,ty=q.y-p.y,ln=Math.hypot(tx,ty)||1,nx=-ty/ln,ny=tx/ln,
    c1={x:p.x+nx*d,y:p.y+ny*d},c2={x:p.x-nx*d,y:p.y-ny*d},out=!el.isPointInFill(c1)?c1:(!el.isPointInFill(c2)?c2:null);
   if(!out)continue;var land=false;
   for(var j=0;j<ps.length;j++){var b=bb[j];if(out.x<b.x||out.x>b.x+b.width||out.y<b.y||out.y>b.y+b.height)continue;if(ps[j].isPointInFill(out)){land=true;break}}
   if(!land){run++;if(run>best)best=run}else run=0}
  res=best>=2}catch(e){res=true}
 return coastCache[id]=res}

/* ---------- действия ---------- */
function mobilize(id,pct){if(!ens())return;var o=S.ob[id],n=Math.floor(o.m*pct/100);if(n<100)return toast('В области нет резерва');
 var c=Math.floor(n*.08);if(S.money<c)return toast('Нужно '+fmt(c)+' млн');S.money-=c;o.m-=n;o.t+=n;o.mob+=n;S.army=(S.army||0)+n;
 log('🪖 Мобилизация в «'+short(reg(id).n)+'»: '+fmt(n));toast('🪖 +'+fmt(n)+' солдат');save();draw();panel()}
function demob(id,part){if(!ens())return;var o=S.ob[id],n=part==='half'?Math.floor(o.t/2):o.t;if(n<1)return toast('Нет войск');
 o.t-=n;o.m+=n;o.mob=Math.max(0,o.mob-n);S.army=Math.max(0,(S.army||0)-n);log('🏳 Демобилизация в «'+short(reg(id).n)+'»: '+fmt(n));toast('🏳 '+fmt(n)+' вернулись в резерв');save();draw();panel()}
function startMove(){if(!sel)return;mvMode=sel;toast('Нажмите на область-цель на карте');panel()}
function doMove(from,to){var o=S.ob[from];mvMode=null;if(from===to)return panel();
 var n=amt==='all'?o.t:amt==='half'?Math.floor(o.t/2):Math.min(o.t,+amt);if(n<1){toast('Нет войск для переброски');return panel()}
 var e=eta(from,to);o.t-=n;S.mv.push({id:'m'+Date.now(),from:from,to:to,n:n,left:e});
 log('⚔ '+fmt(n)+' солдат: «'+short(reg(from).n)+'» → «'+short(reg(to).n)+'» ('+e+' мес.)');toast('⚔ '+fmt(n)+' в пути, '+e+' мес.');save();draw();panel()}
function doMoveMulti(to){mvMode=null;var ids=nMulti().filter(function(i){return i!==to&&S.ob[i]&&S.ob[i].t>0});if(!ids.length){toast('Нет войск в выбранных областях');return panel()}
 var tot=0,t=reg(to);ids.forEach(function(from){var o=S.ob[from],n=amt==='all'?o.t:amt==='half'?Math.floor(o.t/2):Math.min(o.t,+amt);if(n<1)return;var e=eta(from,to);o.t-=n;tot+=n;S.mv.push({id:'m'+Date.now()+from,from:from,to:to,n:n,left:e})});
 log('⚔ Сбор войск: '+fmt(tot)+' солдат из '+ids.length+' обл. → «'+short(t.n)+'»');toast('⚔ '+fmt(tot)+' солдат из '+ids.length+' областей идут в «'+short(t.n)+'»');multi={};msMode=false;save();draw();panel()}
function gather(){if(!ens())return;if(!sel)return toast('Выберите область, куда собрать войска');multi={};regs().forEach(function(r){if(r.id!==sel)multi[r.id]=true});var a=amt;amt='all';doMoveMulti(sel);amt=a}
function selAll(){if(!ens())return;multi={};regs().forEach(function(r){if(S.ob[r.id].t>0)multi[r.id]=true});msMode=false;toast('Выбрано областей: '+nMulti().length);draw();panel()}
function arsenal(){var ks=window.NVSPR?NVSPR.keys.filter(function(k){return k!=='soldier'&&(+S[k]||0)>0}):[];if(!ks.length)return '';
 return '<div class="sec"><h4>🧰 Арсенал страны</h4><div class="ars">'+ks.map(function(k){var A=(window.NG&&NG.ARMS&&NG.ARMS[k])||{};return '<span class="ar" title="'+(A.n||k)+'">'+spr(k,26)+'<b>'+fmt(S[k])+'</b></span>'}).join('')+'</div></div>'}
function build(id,k){if(!ens())return;var o=S.ob[id],B=OB[k];if(k==='port'&&!coastal(id))return toast('⚓ Порт можно строить только у моря');if(o.b.length+o.q.length>=SLOTS)return toast('Нет свободных слотов');
 if(S.money<B.c)return toast('Нужно '+B.c+' млн');S.money-=B.c;o.q.push({t:k,left:B.m,m:B.m});log(B.ic+' «'+short(reg(id).n)+'»: начато '+B.n);toast(B.ic+' '+B.n+' → '+short(reg(id).n));save();panel()}
function tick(){if(!ens())return;var R=regs();
 R.forEach(function(r){var o=S.ob[r.id];o.q=o.q.filter(function(q){q.left--;if(q.left>0)return true;var B=OB[q.t];o.b.push(q.t);B.fx(parent(r.id)||{},o);log(B.ic+' «'+short(r.n)+'»: построено '+B.n);toast(B.ic+' '+B.n+' готово');return false});
  if(o.mob)S.money-=Math.round(o.mob/1000*.5)});
 S.mv=S.mv.filter(function(m){if(--m.left>0)return true;var t=S.ob[m.to];if(t)t.t+=m.n;else S.ob[m.from].t+=m.n;toast('🚩 Прибыло '+fmt(m.n)+' в «'+short((reg(m.to)||{}).n)+'»');return false})}

/* ---------- маркеры на карте ---------- */
var bg=document.getElementById('mapbg'),lastSig='';
function draw(){var on=!!geoOwn();document.body.classList.toggle('a5on',on);if(!on||!ens())return;
 var svg=bg.querySelector('svg');if(!svg)return;var vb=(svg.getAttribute('viewBox')||'0 0 1000 575').split(/[ ,]+/),vw=+vb[2]||1000,sc=vw/1000,fs=9.5*sc;
 var R=regs(),sig=vb.join()+'|'+sel+'|'+mvMode+'|'+nMulti().join(':')+'|'+msMode+'|'+R.map(function(r){return S.ob[r.id].t}).join(',')+'|'+S.mv.map(function(m){return m.id+m.left}).join(',');
 var g=svg.querySelector('#a5-mk');if(g&&sig===lastSig&&g===svg.lastElementChild)return;lastSig=sig;
 if(!g){g=document.createElementNS(NS,'g');g.id='a5-mk';g.style.pointerEvents='none'}svg.appendChild(g);
 var h='';
 var pill=function(x,y,txt,hl,col,ic){var iw=ic&&window.NVSPR?fs*1.3:0,w=txt.length*fs*.58+fs*.9+iw,x0=x-w/2,o='<rect x="'+x0.toFixed(1)+'" y="'+(y-fs*.8).toFixed(1)+'" width="'+w.toFixed(1)+'" height="'+(fs*1.6).toFixed(1)+'" rx="'+(fs*.35).toFixed(1)+'" fill="#0b1424" fill-opacity=".88" stroke="'+(hl?'#fff':col||'#e0b64f')+'" stroke-width="'+(fs*.1).toFixed(2)+'"/>';
  if(iw){var vv=NVSPR.viewBox(ic).split(' '),ih=fs*1.45,iwd=ih*(+vv[2]/+vv[3]);o+='<svg x="'+(x0+fs*.35).toFixed(1)+'" y="'+(y-ih/2).toFixed(1)+'" width="'+iwd.toFixed(1)+'" height="'+ih.toFixed(1)+'" viewBox="'+NVSPR.viewBox(ic)+'">'+NVSPR.inner(ic)+'</svg>'}
  return o+'<text x="'+(iw?x0+iw+fs*.4:x).toFixed(1)+'" y="'+(y+fs*.32).toFixed(1)+'" text-anchor="'+(iw?'start':'middle')+'" font-size="'+fs.toFixed(1)+'" font-weight="600" fill="#fff" style="font-family:Manrope,system-ui;paint-order:normal;stroke:none">'+txt+'</text>'};
 R.forEach(function(r){var o=S.ob[r.id],s=sel===r.id;
  if(s&&r.d)h+='<path d="'+r.d+'" fill="none" stroke="#fff" stroke-width="'+(fs*.18).toFixed(2)+'"/>';
  if(multi[r.id]&&r.d)h+='<path d="'+r.d+'" fill="#e0b64f" fill-opacity=".22" stroke="#e0b64f" stroke-width="'+(fs*.14).toFixed(2)+'"/>';
  if(o.t>0||s)h+=pill(r.cx,r.cy,fmt(o.t),s||multi[r.id],multi[r.id]?'#ffd66b':null,'soldier');
  if(vw<420)h+='<text x="'+r.cx.toFixed(1)+'" y="'+(r.cy+fs*1.7).toFixed(1)+'" text-anchor="middle" font-size="'+(fs*.7).toFixed(1)+'" fill="#fff" fill-opacity=".85" style="font-family:system-ui;stroke:#000;stroke-width:'+(fs*.05).toFixed(2)+'px;paint-order:stroke">'+short(r.n)+'</text>'});
 S.mv.forEach(function(m){var r=reg(m.to);if(r)h+=pill(r.cx,r.cy-fs*1.9,fmt(m.n)+' · '+m.left+'м',false,'#6fb3ff','soldier')});
 g.innerHTML=h}
setInterval(function(){try{draw()}catch(e){}},400);

/* ---------- нажатие на область ---------- */
var dx=0,dy=0;
bg.addEventListener('pointerdown',function(e){dx=e.clientX;dy=e.clientY},true);
bg.addEventListener('pointerup',function(e){if(Math.hypot(e.clientX-dx,e.clientY-dy)>10)return;if(!geoOwn()||!ens())return;
 var el=document.elementFromPoint(e.clientX,e.clientY),n=el&&el.closest&&el.closest('[data-r]');if(!n)return;
 var id=n.getAttribute('data-r'),r=reg(id);if(!r)return;
 if(mvMode==='multi'){return doMoveMulti(id)}
 if(msMode){multi[id]=!multi[id];draw();panel();return}
 if(mvMode){return doMove(mvMode,id)}
 sel=id;showAll=false;var d=document.getElementById('dock');if(d)d.hidden=true;panel();draw()},true);

/* ---------- панель ---------- */
var P=document.createElement('div');P.id='a5';P.hidden=true;document.body.appendChild(P);var last='';
function allSec(){var tot=0,k=nMulti(),ks=0;regs().forEach(function(r){tot+=S.ob[r.id].t});k.forEach(function(i){ks+=S.ob[i]?S.ob[i].t:0});
 var h='<div class="sec"><h4>'+spr('soldier',20)+' Все войска страны: '+fmt(tot)+'</h4><div class="kv"><span>Выбрано областей: <b>'+k.length+'</b></span><span>Солдат: <b>'+fmt(ks)+'</b></span></div>';
 h+='<div class="row"><button onclick="A5.selAll()">Выбрать все</button><button class="'+(msMode?'on':'')+'" onclick="A5.ms()">'+(msMode?'✔ Тап = выбор области':'👆 Выбирать тапом')+'</button><button onclick="A5.clr()">Сбросить</button></div>';
 h+='<div class="row">'+['all','half','1000'].map(function(a){return '<button class="'+(amt===a?'on':'')+'" onclick="A5.amt(\''+a+'\')">'+(a==='all'?'Все':a==='half'?'Половина':'1 000')+'</button>'}).join('')+'</div>';
 h+='<div class="row"><button class="good" onclick="A5.moveMulti()">'+(mvMode==='multi'?'Выберите цель на карте…':'➡ Отправить выбранные…')+'</button>'+(sel?'<button class="good" onclick="A5.gather()">🎯 Собрать всех в «'+short((reg(sel)||{}).n)+'»</button>':'')+'</div></div>';
 return h}
function html(){if(!ens())return '';if(!sel){return showAll?'<h3><span>'+spr('soldier',20)+' Командование</span><button onclick="A5.close()">✕</button></h3>'+allSec()+arsenal():''}var r=reg(sel);if(!r)return '';var o=S.ob[sel],p=parent(sel)||{};
 var h='<h3><span>📍 '+r.n+'</span><button onclick="A5.close()">✕</button></h3>';
 h+='<div class="big">'+spr('soldier',28)+' '+fmt(o.t)+'</div><div class="kv"><span>Резерв: <b>'+fmt(o.m)+'</b></span><span>Мобилиз.: <b>'+fmt(o.mob)+'</b></span><span>Оборона: <b>'+(10+o.d)+'</b></span></div>';
 h+='<div class="sec"><h4>🪖 Мобилизация</h4><div class="row">'+[10,25,50].map(function(q){return '<button onclick="A5.mob(\''+sel+'\','+q+')">'+q+'%<small>'+fmt(o.m*q/100)+'</small></button>'}).join('')+'<button onclick="A5.demob(\''+sel+'\',\'half\')">🏳 ½</button><button onclick="A5.demob(\''+sel+'\',\'all\')">🏳 всех</button></div></div>';
 h+='<div class="sec"><h4>➡ Переброска войск</h4><div class="row">'+['all','half','1000'].map(function(a){return '<button class="'+(amt===a?'on':'')+'" onclick="A5.amt(\''+a+'\')">'+(a==='all'?'Все':a==='half'?'Половина':'1 000')+'</button>'}).join('')+'<button class="good" onclick="A5.move()">'+(mvMode?'Выберите цель на карте…':'Выбрать цель')+'</button></div>'+(mvMode?'<div class="mv" style="margin-top:3px">Нажмите на область страны, куда отправить войска</div>':'')+'</div>';
 h+=allSec()+arsenal();
 var mine=S.mv.filter(function(m){return m.from===sel||m.to===sel});
 if(mine.length)h+='<div class="sec"><h4>🚶 В пути</h4>'+mine.map(function(m){return '<div class="mv">'+fmt(m.n)+': '+short(reg(m.from).n)+' → '+short(reg(m.to).n)+', '+m.left+' мес.</div>'}).join('')+'</div>';
 h+='<div class="sec"><h4>🏗 Здания '+(o.b.length+o.q.length)+'/'+SLOTS+'</h4><div class="kv">'+(o.b.map(function(k){return OB[k].ic}).join(' ')||'—')+(o.q.length?' · строится: '+o.q.map(function(q){return OB[q.t].ic+q.left}).join(' '):'')+'</div><div class="row">'+Object.keys(OB).map(function(k){var B=OB[k],nosea=k==='port'&&!coastal(sel),dis=nosea||o.b.length+o.q.length>=SLOTS||S.money<B.c;return '<button '+(dis?'disabled':'')+' onclick="A5.build(\''+sel+'\',\''+k+'\')">'+B.ic+' '+B.n+'<small>'+(nosea?'нет выхода к морю':B.c+' млн · '+B.m+' мес')+'</small></button>'}).join('')+'</div></div>';
 return h}
function panel(){if(!sel&&!showAll){P.hidden=true;return}P.hidden=false;var h=html();if(h!==last){var sc=P.scrollTop;P.innerHTML=h;last=h;P.scrollTop=sc}}
setInterval(function(){if(!P.hidden)try{panel()}catch(e){}},400);
document.getElementById('dockb').addEventListener('click',function(){sel=null;mvMode=null;P.hidden=true;draw()},true);

var ot=AOH.tick;AOH.tick=function(){ot();try{tick()}catch(e){console.warn(e)}};
window.A5={selAll:selAll,ms:function(){msMode=!msMode;mvMode=null;panel();draw()},clr:function(){multi={};msMode=false;mvMode=null;panel();draw()},gather:gather,moveMulti:function(){if(!nMulti().length)return toast('Сначала выберите области (тап по области в режиме выбора или «Выбрать все»)');mvMode='multi';msMode=false;toast('Нажмите область, куда отправить войска');panel()},
 all:function(){if(!ens()){return false}showAll=true;P.hidden=false;last='';panel();draw();return true},coastal:coastal,active:function(){return !!geoOwn()},close:function(){sel=null;mvMode=null;showAll=false;msMode=false;P.hidden=true;last='';draw()},mob:mobilize,demob:demob,amt:function(a){amt=a;panel()},move:startMove,build:build,tick:tick,ens:ens,draw:draw,select:function(id){sel=id;panel();draw()},_s:function(){return {sel:sel,mv:mvMode}}};
console.log('[AOH5] loaded');
})();
