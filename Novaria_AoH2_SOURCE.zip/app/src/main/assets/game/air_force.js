/* Novaria Air Force & Air Defense — Stage 14. Abstract strategy-game mechanics only. */
(function(root){
 'use strict';
 const VERSION=1, clamp=(v,a,b)=>Math.max(a,Math.min(b,Number.isFinite(+v)?+v:0));
 function ensure(S){
  if(!S)return null;let A=S.airWar;
  if(!A||A.version!==VERSION)A=S.airWar={version:VERSION,drones:0,missiles:0,airDefense:0,missions:[],damageByEnemy:{},totalDamage:0,totalLosses:0,monthKey:null,last:null};
  A.drones=clamp(A.drones,0,100000);A.missiles=clamp(A.missiles,0,100000);A.airDefense=clamp(A.airDefense,0,100);
  if(!Array.isArray(A.missions))A.missions=[];
  return A;
 }
 function build(S,kind){
  const A=ensure(S);if(!A)return {ok:false};
  const spec={drone:{cost:420,steel:1,energy:1,n:5},missile:{cost:850,steel:3,energy:2,n:2},defense:{cost:1600,steel:5,energy:4,n:5}}[kind];
  if(!spec)return {ok:false,reason:'unknown'};
  if((+S.money||0)<spec.cost)return {ok:false,reason:'money'};
  if((+S.steel||0)<spec.steel)return {ok:false,reason:'steel'};
  if((+S.energy||0)<spec.energy)return {ok:false,reason:'energy'};
  S.money-=spec.cost;S.steel=clamp((+S.steel||0)-spec.steel,0,100);S.energy=clamp((+S.energy||0)-spec.energy,0,100);
  if(kind==='drone')A.drones+=spec.n;else if(kind==='missile')A.missiles+=spec.n;else A.airDefense=clamp(A.airDefense+spec.n,0,100);
  return {ok:true,cost:spec.cost,amount:spec.n};
 }
 function atWar(S,name){return (S.wars||[]).some(w=>w&&(w.n===name||w.name===name||w.enemy===name))||(S.mpWars||[]).some(w=>w&&(w.n===name||w.name===name||w.enemy===name));}
 function launch(S,target,kind){
  const A=ensure(S),enemy=(S.relations||[]).find(r=>r&&r.name===target&&!r.self&&!r.annexed);
  if(!A||!enemy)return {ok:false,reason:'target'};
  if(!atWar(S,target))return {ok:false,reason:'peace'};
  const spec={economy:{label:'Экономика',cost:0,damage:900,hit:.78},industry:{label:'Промышленность',cost:0,damage:1250,hit:.68},infrastructure:{label:'Инфраструктура',cost:0,damage:700,hit:.84}}[kind];
  if(!spec)return {ok:false,reason:'mission'};
  const planes=Math.min(Math.max(0,+S.air||0),kind==='industry'?8:6),drones=Math.min(A.drones,kind==='economy'?5:3),missiles=Math.min(A.missiles,kind==='industry'?3:2);
  if(planes+drones+missiles<=0)return {ok:false,reason:'assets'};
  const force=planes*1.2+drones*.65+missiles*1.8;
  const defense=clamp((+enemy.power||40)*.22,4,35);
  const intercept=clamp(defense+A.airDefense*.08,0,55);
  const success=clamp(spec.hit-intercept/100,.15,.95);
  const damage=Math.round((spec.damage+force*24)*success);
  const losses=Math.min(planes,Math.floor((planes*intercept/100)*.22));
  S.air=Math.max(0,(+S.air||0)-losses);
  A.drones-=drones;A.missiles-=missiles;A.totalLosses+=losses;
  enemy.power=clamp((+enemy.power||40)-damage/1500,0,100);
  enemy.airDamage=clamp((+enemy.airDamage||0)+damage,0,1000000000);
  A.damageByEnemy[target]=(A.damageByEnemy[target]||0)+damage;A.totalDamage+=damage;
  const row={month:`${S.year||1}:${S.month||0}`,target,kind,label:spec.label,planes,drones,missiles,intercept:Math.round(intercept),success:Math.round(success*100),damage,losses};
  A.missions.unshift(row);if(A.missions.length>30)A.missions.length=30;A.last=row;
  if(Array.isArray(S.log))S.log.unshift(`✈️ Воздушная операция против ${target}: ${spec.label}, условный ущерб ${damage} млн, перехват ${Math.round(intercept)}%.`);
  return {ok:true,...row};
 }
 function tick(S){
  const A=ensure(S);if(!A||S.campaignOver)return null;
  const key=`${S.year||0}:${S.month||0}:${S.mpMonth||0}`;if(A.monthKey===key)return A.last;
  const aircraft=Math.max(0,+S.air||0),maintenance=aircraft*.035+A.drones*.002+A.missiles*.004;
  const paid=Math.min(Math.max(0,+S.money||0),maintenance);S.money=Math.max(0,(+S.money||0)-paid);
  A.monthKey=key;A.last={maintenance:+paid.toFixed(2),aircraft};return A.last;
 }
 function panel(S){
  const A=ensure(S);if(!A)return '';
  const fmt=n=>Number(n||0).toLocaleString('ru-RU',{maximumFractionDigits:1});
  const enemies=(S.relations||[]).filter(r=>r&&!r.self&&!r.annexed&&atWar(S,r.name));
  const actions=`<div class="actions"><button type="button" onclick="NovariaAirForce.build('drone')">🛩 Произвести 5 дронов · 420 млн</button><button type="button" onclick="NovariaAirForce.build('missile')">🚀 Произвести 2 ракеты · 850 млн</button><button type="button" onclick="NovariaAirForce.build('defense')">🛡 Усилить ПВО · 1 600 млн</button></div>`;
  const targets=enemies.length?enemies.map(r=>`<div class="mini"><b>Цель: ${String(r.name).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}</b><small>Сила государства: ${fmt(r.power)} · накопленный ущерб: ${fmt(A.damageByEnemy[r.name])} млн</small><div class="actions"><button onclick="NovariaAirForce.launch('${String(r.name).replace(/['\\]/g,'') }','economy')">Удар по экономике</button><button onclick="NovariaAirForce.launch('${String(r.name).replace(/['\\]/g,'') }','industry')">Удар по промышленности</button><button onclick="NovariaAirForce.launch('${String(r.name).replace(/['\\]/g,'') }','infrastructure')">Удар по инфраструктуре</button></div></div>`).join(''):'<p class="muted">Для воздушных операций необходимо находиться в состоянии войны.</p>';
  const recent=A.missions.slice(0,5).map(m=>`<div class="mini"><b>${m.target} · ${m.label}</b><small>Самолёты ${m.planes}, дроны ${m.drones}, ракеты ${m.missiles} · перехват ${m.intercept}% · ущерб ${fmt(m.damage)} млн · потери самолётов ${m.losses}</small></div>`).join('');
  return `<section class="panel"><h2>✈️ ВВС и ПВО · этап 15</h2><p class="muted">Воздушные операции доступны только против противника, с которым идёт война. Перехват ПВО снижает результативность удара и может привести к потерям авиации.</p><div class="cards"><div class="mini"><b>Самолёты</b><strong>${fmt(S.air)}</strong><small>Общий авиационный парк страны</small></div><div class="mini"><b>Дроны</b><strong>${fmt(A.drones)}</strong></div><div class="mini"><b>Ракеты</b><strong>${fmt(A.missiles)}</strong></div><div class="mini"><b>Уровень ПВО</b><strong>${fmt(A.airDefense)}/100</strong></div></div>${actions}<h3>Воздушные операции</h3>${targets}<p class="muted">Накопленный условный ущерб: ${fmt(A.totalDamage)} млн · потери самолётов: ${fmt(A.totalLosses)} · ежемесячное содержание: ${fmt(A.last&&A.last.maintenance)} млн.</p><h3>Последние операции и боевые отчёты</h3>${recent||'<p class="muted">Операций пока не было.</p>'}<style>@keyframes nvrAirPulse{0%{opacity:.35;transform:scaleX(.15)}100%{opacity:1;transform:scaleX(1)}}.nvr-air-pulse{height:3px;background:#d6a34e;transform-origin:left;animation:nvrAirPulse .7s ease-out}</style><div class="nvr-air-pulse"></div></section>`;
 }
 root.NovariaAirForce={version:VERSION,ensure,buildState:build,launchState:launch,tick,panel,
  build:(kind)=>{const S=root.NG&&root.NG.S;if(!S)return;const r=build(S,kind);if(!r.ok){if(root.NG.toast)root.NG.toast(({money:'Недостаточно денег',steel:'Недостаточно стали',energy:'Недостаточно энергии'}[r.reason])||'Невозможно выполнить действие');return r;}if(root.NG.toast)root.NG.toast('Военные ресурсы подготовлены');if(root.NG.render)root.NG.render();return r;},
  launch:(target,kind)=>{const S=root.NG&&root.NG.S;if(!S)return;const r=launch(S,target,kind);if(!r.ok){if(root.NG.toast)root.NG.toast(({peace:'Нельзя атаковать государство, с которым нет войны',assets:'Нет доступной авиации, дронов или ракет',target:'Цель не найдена'}[r.reason])||'Операция невозможна');return r;}if(root.NG.toast)root.NG.toast(`Воздушная операция завершена · ущерб ${r.damage} млн`);if(root.NovariaMilitaryVisuals&&root.NovariaMilitaryVisuals.airStrike)root.NovariaMilitaryVisuals.airStrike(r);if(root.NG.render)root.NG.render();return r;}
 };
})(typeof window!=='undefined'?window:globalThis);
