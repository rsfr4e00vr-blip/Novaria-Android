/* Novaria Stage 23 — crash-safe local save storage with legacy compatibility. */
(function(root){
 'use strict';
 const VERSION=2,KEY='novariaSave',BACKUP=KEY+'.backup',TEMP=KEY+'.tmp',META=KEY+'.meta';
 let status={recovered:false,source:'none',error:''};
 function hash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)}return (h>>>0).toString(16)}
 function parse(raw){
  if(typeof raw!=='string'||!raw.trim())return null;
  const x=JSON.parse(raw);
  if(!x||typeof x!=='object'||Array.isArray(x))throw Error('Save root must be an object');
  if(!Array.isArray(x.regions)||!Array.isArray(x.parties)||!Array.isArray(x.relations))throw Error('Save structure is incomplete');
  if(!x.regions.length||!x.parties.length)throw Error('Save contains no regions or parties');
  return x;
 }
 function checked(raw,metaRaw){
  const state=parse(raw);if(!state)return null;
  if(metaRaw){const meta=JSON.parse(metaRaw);if(meta&&meta.checksum&&meta.checksum!==hash(raw))throw Error('Save checksum mismatch')}
  return state;
 }
 function writeMeta(storage,raw){storage.setItem(META,JSON.stringify({version:VERSION,checksum:hash(raw),savedAt:new Date().toISOString()}))}
 function save(state,key){
  key=key||KEY;const storage=root.localStorage;
  if(!storage)throw Error('Local storage is unavailable');
  const raw=JSON.stringify(state);parse(raw);
  const backup=key+'.backup',temp=key+'.tmp',metaKey=key+'.meta';
  storage.setItem(temp,raw);
  const staged=storage.getItem(temp);if(!staged||hash(staged)!==hash(raw))throw Error('Temporary save verification failed');
  const old=storage.getItem(key);
  if(old){try{parse(old);storage.setItem(backup,old)}catch(e){/* retain an existing backup if current save is invalid */}}
  storage.setItem(key,staged);
  storage.setItem(metaKey,JSON.stringify({version:VERSION,checksum:hash(staged),savedAt:new Date().toISOString()}));
  storage.removeItem(temp);
  status={recovered:false,source:'current',error:''};
  return {ok:true,bytes:raw.length,version:VERSION};
 }
 function load(key){
  key=key||KEY;const storage=root.localStorage;status={recovered:false,source:'none',error:''};
  if(!storage)return null;
  const candidates=[
   {key:key,meta:key+'.meta',source:'current'},
   {key:key+'.backup',meta:'',source:'backup'},
   {key:key+'.tmp',meta:'',source:'temporary'}
  ];
  for(let i=0;i<candidates.length;i++){
   const c=candidates[i],raw=storage.getItem(c.key);if(!raw)continue;
   try{
    const state=checked(raw,c.meta?storage.getItem(c.meta):'');
    if(!state)continue;
    if(c.source!=='current'){
     try{storage.setItem(key,raw);writeMeta(storage,raw);storage.removeItem(key+'.tmp')}catch(e){}
     status={recovered:true,source:c.source,error:''};
    }else{
     status={recovered:false,source:'current',error:''};
     // Legacy saves have no metadata; add metadata without changing their state payload.
     if(!storage.getItem(c.meta)){try{writeMeta(storage,raw)}catch(e){}}
    }
    return state;
   }catch(e){status.error=String(e&&e.message||e)}
  }
  return null;
 }
 root.NVRSaveManager={save,load,getStatus:()=>Object.assign({},status),hash,validate:parse,version:VERSION};
})(window);
