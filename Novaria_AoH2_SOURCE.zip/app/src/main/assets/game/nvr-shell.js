(function(){var m=document.getElementById('more');
document.getElementById('moreb').onclick=function(e){e.stopPropagation();m.classList.toggle('open')};
document.addEventListener('click',function(){m.classList.remove('open')});
document.getElementById('close').onclick=function(){document.querySelector('#tabs [data-tab=map]').click()};
var fs=1;setInterval(function(){var a=document.querySelector('#tabs button.active[data-tab]');var t=a?a.dataset.tab:'map';document.body.dataset.tab=t;if(t==='map'){if(!fs&&document.getElementById('wm-slot')&&document.getElementById('wfull')&&!(typeof WMAP!=='undefined'&&WMAP.full)){fs=1;document.getElementById('wfull').click()}}else fs=0},250);document.getElementById('hud').addEventListener('dblclick',function(){var d=document.documentElement;try{(d.requestFullscreen||d.webkitRequestFullscreen).call(d).then(function(){screen.orientation.lock('landscape').catch(function(){})}).catch(function(){})}catch(e){}});
document.addEventListener('click',function(e){var b=e.target.closest('button');if(b&&/^\\s*Играть/.test(b.textContent)&&!b.id){setTimeout(function(){document.querySelector('#tabs [data-tab=map]').click()},900)}},true);
})();
(function(){var last='';setInterval(function(){var c=document.getElementById('clock');if(!c)return;var t=c.textContent;if(t!==last){if(last&&window.AOH&&window.S&&Array.isArray(S.regions)){try{AOH.ensure();AOH.tick()}catch(e){console.warn(e)}}last=t}},300)})();

/* При запуске всегда открывается карта (пока игрок сам не выбрал другой раздел) */
(function(){var nav=false,t=document.getElementById('tabs');
t.addEventListener('pointerdown',function(e){if(e.target.closest('[data-tab]'))nav=true},true);
var n=0,iv=setInterval(function(){n++;if(nav||n>200){clearInterval(iv);return}
var a=document.querySelector('#tabs button.active[data-tab]');
if(!a||a.dataset.tab!=='map'){var b=document.querySelector('#tabs [data-tab=map]');if(b&&document.getElementById('content').innerHTML.length>50)b.click()}},400)})();

/* Горизонтальный режим: если телефон вертикален, разворачиваем интерфейс (кнопка ⟳ выключает) */
(function(){var h=document.documentElement,pref=true;
function upd(){var port=innerHeight>innerWidth;h.classList.toggle('rot',port&&pref);h.classList.toggle('land',!port||pref);window.dispatchEvent(new Event('nvr-rot'))}

addEventListener('resize',upd);upd();
document.addEventListener('pointerdown',function f(){document.removeEventListener('pointerdown',f);try{var d=h;(d.requestFullscreen||d.webkitRequestFullscreen).call(d).then(function(){return screen.orientation.lock('landscape')}).catch(function(){})}catch(e){}},{once:true});
})();

/* Панель провинций на карте: выбор провинции, постройки, призыв, перемещение армий */
(function(){var d=document.getElementById('dock'),b=document.getElementById('dockb'),last='';
function html(){if(!window.AOH||!window.S||!Array.isArray(S.regions))return '<p class="muted" style="padding:10px">Сначала выберите страну.</p>';
try{AOH.ensure()}catch(e){}
var ch=S.regions.map(function(r,i){var a=(S.armies||[]).filter(function(x){return x.region===i}).reduce(function(s,x){return s+x.size},0);
return '<button class="'+(S.selectedProv===i?'on':'')+'" onclick="AOH.openProv('+i+')">'+r.name+'<small>⚔ '+Math.round(a/1000)+' тыс · слоты '+((r.buildings||[]).length+(r.queue||[]).length)+'/'+(r.slots||4)+'</small></button>'}).join('');
var p=document.createElement('div');p.innerHTML=AOH.html();var side=p.querySelector('.aoh-panel-side');
var hint=S.selectedArmy?'<p class="aoh-hint" style="padding:6px">⚔ Армия выбрана: нажмите на другую провинцию сверху, чтобы переместить</p>':'';
return '<div class="dh"><span>🏗 Провинции</span><button onclick="document.getElementById(\'dock\').hidden=true">✕</button></div><div class="chips">'+ch+'</div><div class="body">'+hint+(side?side.innerHTML:'')+'</div>'}
function draw(){if(d.hidden)return;var h=html();if(h!==last){var bd=d.querySelector('.body'),sc=bd?bd.scrollTop:0,cs=d.querySelector('.chips'),cx=cs?cs.scrollLeft:0;d.innerHTML=h;last=h;bd=d.querySelector('.body');if(bd)bd.scrollTop=sc;cs=d.querySelector('.chips');if(cs)cs.scrollLeft=cx}}
b.onclick=function(){d.hidden=!d.hidden;last='';if(!d.hidden){var m=document.querySelector('#tabs [data-tab=map]');draw()}};
setInterval(draw,350);
})();

var NVR_C={"США":[39,-98],"Китай":[35,103],"Германия":[49.9,10.9],"Япония":[36,138],"Индия":[21,79],"Великобритания":[54,-2],"Франция":[46.5,2.5],"Италия":[41.9,12.5],"Бразилия":[-10,-52],"Канада":[56,-96],"Россия":[58,60],"Мексика":[23,-102],"Южная Корея":[37.5,127.0],"Австралия":[-25,134],"Испания":[40,-3.5],"Индонезия":[-2,118],"Нидерланды":[50.8,4.3],"Саудовская Аравия":[24,45],"Турция":[39,35],"Швейцария":[47.4,8.5],"Польша":[52.2,21.0],"Аргентина":[-34,-64],"Бельгия":[50.8,4.3],"Швеция":[52.5,13.4],"Ирландия":[53.3,-6.2],"Австрия":[48.2,16.3],"Израиль":[31.8,35.2],"Таиланд":[15,101],"ОАЭ":[25.3,55.3],"Норвегия":[61,9],"Сингапур":[1.3,103.8],"Бангладеш":[23.7,90.4],"Филиппины":[12,122],"Вьетнам":[16,107],"Дания":[56,10],"Иран":[32,53],"Малайзия":[4,102],"Египет":[27,30],"Южно-Африканская Республика":[-29,24],"Нигерия":[6.5,3.4],"Колумбия":[4.6,-74.1],"Румыния":[44.4,26.1],"Чехия":[50.1,14.4],"Пакистан":[30,70],"Чили":[-30,-71],"Финляндия":[60.2,25.0],"Португалия":[39.5,-8],"Ирак":[33.4,44.4],"Перу":[-12.1,-77.0],"Казахстан":[48,67],"Новая Зеландия":[-42,173],"Греция":[38.0,23.7],"Алжир":[28,2],"Катар":[25.3,51.5],"Венгрия":[47.5,19.1],"Кувейт":[24.6,46.7],"Эфиопия":[9,40],"Марокко":[33.6,-7.6],"Словакия":[50.1,14.4],"Украина":[49,31],"Доминиканская Республика":[18.5,-69.9],"Эквадор":[-1.5,-78.5],"Кения":[-1.3,36.8],"Куба":[23.1,-82.4],"Оман":[25.3,55.3],"Гватемала":[14.6,-90.5],"Болгария":[42.7,23.3],"Венесуэла":[10.5,-66.9],"Хорватия":[44.8,20.5],"Узбекистан":[40.5,68.0],"Ангола":[-12,17],"Люксембург":[50.8,4.3],"Коста-Рика":[9.9,-84.1],"Шри-Ланка":[6.9,79.8],"Панама":[9.0,-79.5],"Кот-д’Ивуар":[5.3,-4.0],"Танзания":[-1.3,36.8],"Литва":[54.7,25.3],"Уругвай":[-34.9,-56.2],"Гана":[5.3,-4.0],"Сербия":[44.8,20.5],"Беларусь":[53.9,27.6],"Азербайджан":[40.4,49.9],"Словения":[44.8,20.5],"ДР Конго":[-2,23],"Мьянма":[21,96],"Туркменистан":[38.0,58.4],"Иордания":[31.9,35.9],"Ливия":[27,17],"Тунис":[36.8,10.2],"Уганда":[-1.3,36.8],"Бахрейн":[25.3,51.5],"Камерун":[6.5,3.4],"Боливия":[-16.5,-68.2],"Латвия":[57.0,24.1],"Эстония":[59.4,24.8],"Парагвай":[-25.3,-57.7],"Непал":[27.7,85.3],"Судан":[15,30],"Зимбабве":[-26.0,32.6],"Сальвадор":[13.7,-89.2],"Гондурас":[14.1,-87.2],"Кипр":[35.1,33.7],"Камбоджа":[13.8,100.5],"Сенегал":[5.3,-4.0],"Папуа — Новая Гвинея":[-7.9,151.4],"Исландия":[5.3,-4.0],"Грузия":[41.7,44.8],"Замбия":[-26.0,32.6],"Тринидад и Тобаго":[18.5,-66.1],"Босния и Герцеговина":[44.8,20.5],"Армения":[40.2,44.5],"Албания":[41.3,19.8],"Ливан":[33.9,35.5],"Гвинея":[5.3,-4.0],"Мальта":[35.9,14.5],"Монголия":[47,103],"Йемен":[24.6,46.7],"Ботсвана":[-26.0,32.6],"Буркина-Фасо":[5.3,-4.0],"Габон":[6.5,3.4],"Гаити":[18.5,-72.3],"Бенин":[6.5,3.4],"Мали":[17,-3],"Ямайка":[18.0,-76.8],"КНДР":[39.0,125.8],"Палестина":[31.5,34.8],"Мозамбик":[-26.0,32.6],"Афганистан":[34,66],"Никарагуа":[12.2,-86.3],"Молдова":[47.0,28.8],"Мадагаскар":[-1.3,36.8],"Нигер":[17,9],"Гайана":[6.8,-58.2],"Северная Македония":[44.8,20.5],"Бруней":[1.6,110.3],"Лаос":[13.8,100.5],"Сирия":[33.5,36.3],"Республика Конго":[6.5,3.4],"Киргизия":[42.9,74.6],"Маврикий":[-20.2,57.5],"Руанда":[-26.0,32.6],"Багамы":[43.6,-79.4],"Малави":[-26.0,32.6],"Таджикистан":[38.6,68.8],"Чад":[15,19],"Экваториальная Гвинея":[6.5,3.4],"Намибия":[-22.6,17.1],"Сомали":[-1.3,36.8],"Мавритания":[20,-10],"Того":[5.3,-4.0],"Монако":[48.9,2.3],"Лихтенштейн":[47.4,8.5],"Черногория":[44.8,20.5],"Мальдивы":[4.2,73.5],"Южный Судан":[4.8,31.6],"Барбадос":[13.1,-59.6],"Фиджи":[-18.1,178.4],"Эсватини":[-26.2,28.0],"Либерия":[6.3,-10.8],"Сьерра-Леоне":[5.3,-4.0],"Андорра":[42.5,1.5],"Джибути":[-1.3,36.8],"Суринам":[5.8,-55.2],"Бутан":[27.5,89.7],"Бурунди":[-26.0,32.6],"Белиз":[17.5,-88.2],"Кабо-Верде":[14.9,-23.5],"Центрально-Африканская Республика":[6.5,3.4],"Эритрея":[-1.3,36.8],"Сент-Люсия":[18.5,-66.1],"Гамбия":[5.3,-4.0],"Лесото":[-26.2,28.0],"Сейшельские о-ва":[25.3,55.3],"Сан-Марино":[41.9,12.5],"Восточный Тимор":[-8.6,125.6],"Гвинея-Бисау":[11.8,-15.6],"Антигуа и Барбуда":[18.5,-66.1],"Соломоновы о-ва":[-9.5,160.2],"Коморы":[-1.3,36.8],"Гренада":[18.5,-66.1],"Вануату":[-17.7,168.4],"Сент-Китс и Невис":[18.5,-66.1],"Сент-Винсент и Гренадины":[18.5,-66.1],"Самоа":[-13.8,-171.7],"Сан-Томе и Принсипи":[0.3,6.7],"Доминика":[18.5,-66.1],"Тонга":[-21.1,-175.2],"Микронезия":[6.9,158],"Ватикан":[41.9,12.5],"Маршалловы о-ва":[5.2,170.2],"Кирибати":[1.9,-157],"Палау":[7.3,134.5],"Науру":[-0.5,166.9],"Тувалу":[1.4,173.0],"Новария":[48.2,36.0]};

/* Карта на заднем плане + маркеры провинций с армией */
(function(){var bg=document.getElementById('mapbg'),NOV=[[48.46,35.04],[49.99,36.23],[48.02,37.8],[46.64,32.62],[46.48,30.73],[47.84,35.14],[45.3,34.4],[48.57,39.31],[46.97,31.99],[50.6,36.59]],lastSig='';
function pos(i){var nm=S.name,n=S.regions.length;
 if(nm&&nm!=='Республика Новария'){try{var line=NG.coords().split('\n').find(function(l){return l.indexOf(nm+'=')===0});
  if(line){var ps=line.slice(nm.length+1).split(';'),q=ps[i%ps.length].split(':');return NG.prj(+q[1],+q[2])}}catch(e){}
  var c=NVR_C[nm];if(c){var a=i/n*2*Math.PI,r=n>1?2.2:0;return NG.prj(c[1]+Math.cos(a)*r*1.4,c[0]+Math.sin(a)*r)}}
 var p=NOV[i%NOV.length];return NG.prj(p[1],p[0])}
function draw(){var svg=bg.querySelector('svg');if(!svg||!window.S||!Array.isArray(S.regions))return;
 var vb=svg.getAttribute('viewBox')||'0 0 1000 575',vw=+vb.split(/[ ,]+/)[2]||1000,sc=vw/1000;
 var arm=(S.armies||[]),sig=vb+'|'+S.selectedProv+'|'+S.selectedArmy+'|'+S.regions.map(function(r,i){return arm.filter(function(a){return a.region===i}).reduce(function(s,a){return s+a.size},0)+':'+(r.buildings||[]).length+':'+(r.queue||[]).length}).join(',');
 var g=svg.querySelector('#nvr-mk');if(g&&sig===lastSig&&g===svg.lastElementChild)return;lastSig=sig;
 if(!g){g=document.createElementNS('http://www.w3.org/2000/svg','g');g.id='nvr-mk'}svg.appendChild(g);
 var s=11*sc,h='';
 var n=S.regions.length,P=S.regions.map(function(_,i){return pos(i)}),cx=P.reduce(function(t,p){return t+p[0]},0)/n,cy=P.reduce(function(t,p){return t+p[1]},0)/n,cols=Math.min(n,3),rows=Math.ceil(n/3);
 S.regions.forEach(function(r,i){var p=[cx+(i%3-(cols-1)/2)*s*4.3,cy+(Math.floor(i/3)-(rows-1)/2)*s*2.9],a=arm.filter(function(x){return x.region===i}).reduce(function(t,x){return t+x.size},0),sel=S.selectedProv===i,b=(r.buildings||[]).length,q=(r.queue||[]).length,k=Math.round(a/1000);
  h+='<g class="nvr-mk" data-i="'+i+'" transform="translate('+p[0].toFixed(1)+' '+p[1].toFixed(1)+')">'+
  '<rect x="'+(-s*1.9)+'" y="'+(-s*1.15)+'" width="'+(s*3.8)+'" height="'+(s*2.3)+'" rx="'+(s*.4)+'" fill="'+(sel?'#e0b64f':'#0b1424')+'" fill-opacity=".92" stroke="'+(sel?'#fff3c4':'#e0b64f')+'" stroke-width="'+(s*.12)+'"/>'+
  '<text y="'+(-s*.1)+'" text-anchor="middle" font-size="'+(s*.82)+'" fill="'+(sel?'#1a1405':'#fff')+'">⚔ '+k+'k</text>'+
  '<text y="'+(s*.82)+'" text-anchor="middle" font-size="'+(s*.62)+'" fill="'+(sel?'#3b2e08':'#9fb0cc')+'">🏗 '+b+(q?'+'+q:'')+'</text></g>'});
 g.innerHTML=h}
window.NVR={draw:draw};
var dn=0,ds=0;
setInterval(function(){if(!window.NG||!window.S)return;
 var svg=bg.querySelector('svg');
 if(!svg){if(Date.now()-ds>3000){ds=Date.now();NG.mountBg(bg)}return}
 dn++;if(dn%3===0)NG.updateMap();draw()},400);
addEventListener('nvr-rot',function(){setTimeout(function(){window.NG&&NG.fitMap&&NG.fitMap()},60)});
addEventListener('resize',function(){setTimeout(function(){window.NG&&NG.fitMap&&NG.fitMap()},60)});
var dx=0,dy=0;
bg.addEventListener('pointerdown',function(e){dx=e.clientX;dy=e.clientY},true);
bg.addEventListener('pointerup',function(e){if(Math.hypot(e.clientX-dx,e.clientY-dy)>10)return;
 var el=document.elementFromPoint(e.clientX,e.clientY),m=el&&el.closest&&el.closest('.nvr-mk');if(!m)return;
 var i=+m.dataset.i;try{AOH.ensure()}catch(_){}
 var d=document.getElementById('dock');if(d.hidden)document.getElementById('dockb').click();
 AOH.openProv(i)},true);
})();

/* Названия стран на карте: ставятся в самую крупную часть страны, без наложений; мелкие появляются при приближении */
(function(){var NS='http://www.w3.org/2000/svg',items=[],raf=0,mo=null,cur=null;
function build(svg){var g=document.createElementNS(NS,'g');g.setAttribute('class','nvrlbl');items=[];
 Object.keys(GEO.c).forEach(function(k){var C=GEO.c[k];if(!C.name||!C.polys)return;var nm=String(C.name),best=null;
  C.polys.forEach(function(p){var r=p[0],A=0,cx=0,cy=0,u0=1e9,u1=-1e9,v0=1e9,v1=-1e9;
   for(var i=0,j=r.length-1;i<r.length;j=i++){var f=r[j][0]*r[i][1]-r[i][0]*r[j][1];A+=f;cx+=(r[j][0]+r[i][0])*f;cy+=(r[j][1]+r[i][1])*f;u0=Math.min(u0,r[i][0]);u1=Math.max(u1,r[i][0]);v0=Math.min(v0,r[i][1]);v1=Math.max(v1,r[i][1])}
   var a=Math.abs(A/2);if(!best||a>best.a){var x=A?cx/(3*A):(u0+u1)/2,y=A?cy/(3*A):(v0+v1)/2;if(!(x>u0&&x<u1&&y>v0&&y<v1)){x=(u0+u1)/2;y=(v0+v1)/2}best={a:a,x:x,y:y,w:u1-u0,h:v1-v0}}});
  if(!best||best.a<.3)return;
  var fs=Math.max(1.1,Math.min(9,best.w*.86/(nm.length*.55),best.h*.7)),t=document.createElementNS(NS,'text');
  t.setAttribute('x',best.x.toFixed(1));t.setAttribute('y',best.y.toFixed(1));t.style.fontSize=fs.toFixed(2)+'px';t.textContent=nm;t.style.display='none';g.appendChild(t);
  items.push({t:t,x:best.x,y:best.y,fs:fs,hw:nm.length*fs*.27,hh:fs*.55,a:best.a})});
 items.sort(function(p,q){return q.a-p.a});return g}
function update(){raf=0;if(!cur)return;var vb=(cur.getAttribute('viewBox')||'').split(/[ ,]+/).map(Number);if(vb.length<4||!(vb[2]>0))return;
 var rc=cur.getBoundingClientRect(),sc=rc.width/vb[2],acc=[],minPx=7.5;
 items.forEach(function(it){var show=it.fs*sc>=minPx&&it.x>vb[0]-5&&it.x<vb[0]+vb[2]+5&&it.y>vb[1]-5&&it.y<vb[1]+vb[3]+5;
  if(show){for(var i=0;i<acc.length;i++){var b=acc[i];if(Math.abs(b.x-it.x)<b.hw+it.hw&&Math.abs(b.y-it.y)<b.hh+it.hh){show=false;break}}}
  if(show)acc.push(it);it.t.style.display=show?'':'none'})}
function sched(){if(!raf)raf=requestAnimationFrame(update)}
setInterval(function(){try{var svg=window.WMAP&&WMAP.node;if(!svg||!window.GEO||!GEO.c)return;
 if(svg.querySelector('.nvrlbl')&&cur===svg)return;
 var old=svg.querySelector('.nvrlbl');if(old)old.remove();
 cur=svg;svg.appendChild(build(svg));if(mo)mo.disconnect();mo=new MutationObserver(sched);mo.observe(svg,{attributes:true,attributeFilter:['viewBox']});window.addEventListener('resize',sched);sched()}catch(e){}},700)})();
