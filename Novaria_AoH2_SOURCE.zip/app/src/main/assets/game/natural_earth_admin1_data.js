window.NATURAL_EARTH_ADMIN1={type:"FeatureCollection",features:[]};
