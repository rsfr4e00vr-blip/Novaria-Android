/* aoh6: дипломатия в духе AoH3: компактная панель страны вместо большого окна, договоры */
(function(){'use strict';
var P=document.createElement('div');P.id='a6';P.hidden=true;document.body.appendChild(P);
var cur=null,last='',TR={nap:{n:'Пакт о ненападении',ic:'📜',c:15,need:-10,months:60},trade:{n:'Торговое соглашение',ic:'💱',c:20,need:0,months:0}};
var toast=function(t){try{NG.toast(t)}catch(e){}},log=function(t){try{NG.log(t)}catch(e){}},save=function(){try{NG.save()}catch(e){}};
var mood=function(v){return v>40?'🤝 Друг':v>10?'🙂 Дружелюбен':v>-20?'😐 Нейтрален':v>-50?'🧊 Холоден':'😠 Враждебен'};
function idx(nm){return S.relations.findIndex(function(r){return r.name===nm})}
function T(nm){S.tr=S.tr||{};return S.tr[nm]=S.tr[nm]||{}}
function show(iso,nm){cur={iso:iso,nm:nm};var d=document.getElementById('dock');if(d)d.hidden=true;try{A5.close()}catch(e){}last='';paint()}
function close(){cur=null;P.hidden=true;last=''}
function paint(){if(!cur){P.hidden=true;return}var i=idx(cur.nm),r=S.relations[i];P.hidden=false;
 var h='<h3><span>🌍 '+cur.nm+'</span><button onclick="A6.close()">✕</button></h3>';
 if(!r){h+='<div class="kv">Нет данных о стране</div>';var x=h;if(x!==last){P.innerHTML=x;last=x}return}
 var war=(S.wars||[]).some(function(w){return w.n===cur.nm}),ally=(S.allies||[]).indexOf(cur.nm)>=0,t=T(cur.nm),pp=Math.round(S.pp||0);
 if(r.self)h+='<div class="kv">🏠 Это ваше государство</div>';
 else{
 h+='<div class="kv"><span>'+mood(r.value||0)+'</span><span>Отношения: <b>'+Math.round(r.value||0)+'</b></span><span>Мощь: <b>'+(r.power||'—')+'</b></span><span>⭐ <b>'+pp+'</b></span></div>';
 h+='<div>'+(war?'<span class="tag" style="color:#ff8a8a">⚔ Война</span>':'')+(ally?'<span class="tag">🛡 Союзник</span>':'')+(t.nap>0?'<span class="tag">📜 Пакт ещё '+t.nap+' мес</span>':'')+(t.trade?'<span class="tag">💱 Торговля</span>':'')+'</div>';
 h+='<div class="sec"><h4>🤝 Дипломатия</h4><div class="row">';
 var prog=(S.relPrograms||{})[cur.nm];
 h+=prog?'<span class="kv">Программа улучшения: ещё '+prog.monthsLeft+' мес</span>':'<button onclick="A6.rel()">🤝 Улучшать отношения<small>40 ⭐ · 4 года</small></button>';
 h+=ally?'<button onclick="A6.brk()">🛡 Расторгнуть союз</button>':'<button onclick="A6.ally()">🛡 Предложить союз<small>25 ⭐</small></button>';
 Object.keys(TR).forEach(function(k){var Q=TR[k],on=k==='nap'?t.nap>0:t.trade;
  h+=on?'<button onclick="A6.cancel(\''+k+'\')">✖ '+Q.n+'<small>расторгнуть</small></button>':'<button onclick="A6.sign(\''+k+'\')" '+(war?'disabled':'')+'>'+Q.ic+' '+Q.n+'<small>'+Q.c+' ⭐ · нужны отношения ≥ '+Q.need+'</small></button>'});
 h+='</div></div><div class="sec"><h4>⚔ Война</h4><div class="row"><button onclick="A6.war()">'+(war?'Фронт и мир…':'Объявить войну…')+'<small>выбор причины и областей</small></button></div></div>'}
 if(h!==last){P.innerHTML=h;last=h}}
function spend(c){if((S.pp||0)<c){toast('Нужно '+c+' ⭐');return false}S.pp-=c;return true}
function sign(k){var r=S.relations[idx(cur.nm)],Q=TR[k];if(!r)return;if((r.value||0)<Q.need){toast('😒 '+cur.nm+' отказывает: отношения слишком низкие');return}
 if(!spend(Q.c))return;var t=T(cur.nm);if(k==='nap')t.nap=Q.months;else t.trade=true;r.value=Math.min(100,(r.value||0)+5);
 log(Q.ic+' '+Q.n+' с '+cur.nm);toast(Q.ic+' '+Q.n+': '+cur.nm);save();last='';paint()}
function cancel(k){var r=S.relations[idx(cur.nm)],t=T(cur.nm);
 if(k==='nap'){t.nap=0;if(r)r.value=Math.max(-100,(r.value||0)-30);S.legitimacy=Math.max(0,(S.legitimacy||0)-3);toast('📜 Пакт расторгнут: доверие упало')}
 else{t.trade=false;if(r)r.value=Math.max(-100,(r.value||0)-8);toast('💱 Соглашение расторгнуто')}
 log('Расторгнут договор с '+cur.nm);save();last='';paint()}
function monthly(){if(!window.S||!S.tr)return;Object.keys(S.tr).forEach(function(nm){var t=S.tr[nm],r=S.relations[idx(nm)];if(!r)return;
 if(t.nap>0){t.nap--;r.value=Math.min(100,(r.value||0)+.4);if(t.nap===0)log('📜 Пакт о ненападении с '+nm+' истёк')}
 if(t.trade){r.value=Math.min(100,(r.value||0)+.2);S.money+=Math.round(5+(r.power||10)*.6)}})}
var ot=AOH.tick;AOH.tick=function(){ot();try{monthly()}catch(e){}};
/* пакт запрещает объявлять войну и начинать кризис */
['declare','justify'].forEach(function(k){var o=H[k];if(typeof o!=='function')return;H[k]=function(i){var r=S.relations[i];if(r&&S.tr&&S.tr[r.name]&&S.tr[r.name].nap>0){toast('📜 Действует пакт о ненападении с '+r.name+'. Расторгните его сначала.');return}return o.apply(this,arguments)}});
setInterval(function(){if(cur)try{paint()}catch(e){}},500);
document.getElementById('dockb').addEventListener('click',close,true);
window.A6={show:show,close:close,rel:function(){var i=idx(cur.nm);H.relProgram(i);last='';paint()},ally:function(){var i=idx(cur.nm);H.allyAsk(i);last='';paint()},brk:function(){var i=idx(cur.nm);H.allyBreak(i);last='';paint()},sign:sign,cancel:cancel,
 war:function(){var iso=cur.iso;close();document.body.dataset.a6war='1';window.__a6occ(iso)},monthly:monthly};
console.log('[AOH6] loaded');
})();
