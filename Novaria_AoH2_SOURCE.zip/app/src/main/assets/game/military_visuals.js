/* Novaria Military Visuals — Stage 15. Visual feedback only; never changes combat outcomes. */
(function(root){'use strict';
 const VERSION=1, timers=new WeakMap();
 const escText=v=>String(v==null?'':v).slice(0,180);
 function formatOperation(row){if(!row)return '';return `${escText(row.target)} · ${escText(row.label)} · самолёты ${Number(row.planes)||0}, дроны ${Number(row.drones)||0}, ракеты ${Number(row.missiles)||0} · перехват ${Number(row.intercept)||0}% · ущерб ${Math.max(0,Number(row.damage)||0).toLocaleString('ru-RU')} млн`;}
 function style(){if(!root.document||root.document.getElementById('nvrMilitaryVisualCss'))return;const s=root.document.createElement('style');s.id='nvrMilitaryVisualCss';s.textContent=`
 #nvrMilitaryToast{position:fixed;z-index:10020;left:50%;bottom:76px;transform:translate(-50%,14px);width:min(92vw,520px);padding:12px 14px;border:1px solid #b88d42;border-radius:13px;background:linear-gradient(135deg,#101c2bf2,#1b2d43f5);color:#edf3fb;box-shadow:0 12px 35px #0008;opacity:0;pointer-events:none;transition:opacity .22s,transform .22s;font:600 13px/1.45 system-ui}
 #nvrMilitaryToast.on{opacity:1;transform:translate(-50%,0)}#nvrMilitaryToast .nvr-viz-title{color:#f2c14e;font-size:14px;margin-bottom:4px}#nvrMilitaryToast .nvr-viz-track{height:4px;background:#34445a;border-radius:5px;overflow:hidden;margin-top:9px}#nvrMilitaryToast .nvr-viz-track i{display:block;height:100%;width:0;background:#f2c14e;animation:nvrVizSweep 2.4s ease-out forwards}
 @keyframes nvrVizSweep{to{width:100%}}@media(prefers-reduced-motion:reduce){#nvrMilitaryToast .nvr-viz-track i{animation:none;width:100%}}
 `;root.document.head.appendChild(s)}
 function announce(title,detail,kind){if(!root.document)return false;style();let el=root.document.getElementById('nvrMilitaryToast');if(!el){el=root.document.createElement('div');el.id='nvrMilitaryToast';root.document.body.appendChild(el)}el.replaceChildren();const h=root.document.createElement('div');h.className='nvr-viz-title';h.textContent=title;const d=root.document.createElement('div');d.textContent=detail;const track=root.document.createElement('div');track.className='nvr-viz-track';const fill=root.document.createElement('i');track.appendChild(fill);el.append(h,d,track);el.classList.add('on');const old=timers.get(el);if(old)root.clearTimeout(old);const t=root.setTimeout(()=>el.classList.remove('on'),3600);timers.set(el,t);return true}
 function airStrike(row){return announce('✈ Воздушная операция',formatOperation(row),'air')}
 function battleStart(b){if(!b)return false;return announce('⚔ Началось сражение',`${escText(b.attackerName)} атакует провинцию ${escText(b.target)} · оборона: ${Math.round(Number(b.def0)||0).toLocaleString('ru-RU')} чел.`,'battle')}
 function battleResult(row){if(!row)return false;return announce('📜 Итог сражения',`${escText(row.target)} · ${escText(row.result)} · потери: ${Math.round(Number(row.attLost)||0).toLocaleString('ru-RU')} / ${Math.round(Number(row.defLost)||0).toLocaleString('ru-RU')}`,'report')}
 root.NovariaMilitaryVisuals={version:VERSION,formatOperation,announce,airStrike,battleStart,battleResult};
})(typeof window!=='undefined'?window:globalThis);
