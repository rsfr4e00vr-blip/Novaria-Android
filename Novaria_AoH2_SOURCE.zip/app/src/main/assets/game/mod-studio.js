/* Novaria Mod Studio: create installable .novaria ZIP packages. */
(function(){
 'use strict';
 const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const starter=`/* Novaria mod entry point. Runs once after the game loads. */\n(function(){\n  'use strict';\n  // Game API: window.NG (notifications, save, render), window.S (campaign state).\n  if (window.NG) window.NG.toast('Мой мод активирован!');\n  window.MyNovariaMod = {\n    version: '1.0.0',\n    hello: function(){ if (window.NG) window.NG.toast('Привет из моего мода!'); }\n  };\n})();`;
 const starterCss=`/* Your mod styles. Prefix selectors with .my-mod to avoid conflicts. */\n.my-mod { }`;
 function studio(){
  return `<section class="panel nvr-mod-studio"><h2>🛠️ Мастерская модов Novaria</h2>
   <p class="muted">Создавай собственные дополнения: новые события, интерфейсы, механики, страны и баланс. Собери пакет .novaria и установи его через менеджер дополнений.</p>
   <div class="nvr-mod-grid">
    <label>Название мода<input id="modName" maxlength="60" value="Мой мод"></label>
    <label>ID (латиница)<input id="modId" maxlength="48" value="my-novaria-mod"></label>
    <label>Версия<input id="modVersion" maxlength="20" value="1.0.0"></label>
    <label>Описание<input id="modDesc" maxlength="180" value="Моё дополнение для Novaria"></label>
   </div>
   <label class="nvr-mod-check"><input id="modMP" type="checkbox" checked> Совместим с мультиплеером (одинаковый мод и версия должны быть установлены у всех игроков)</label>
   <div class="nvr-mod-edit"><label>JavaScript — логика мода<textarea id="modJS" spellcheck="false">${esc(starter)}</textarea></label><label>CSS — оформление<textarea id="modCSS" spellcheck="false">${esc(starterCss)}</textarea></label></div>
   <div class="nvr-mod-actions"><button class="primary" onclick="NVRModStudio.validate()">✓ Проверить код</button><button class="primary" onclick="NVRModStudio.exportZip()">⬇ Скачать мод .novaria</button><button onclick="NVRModStudio.install()">📦 Установить ZIP</button></div>
   <div id="modStatus" class="mini" aria-live="polite">Формат совместим со встроенным менеджером дополнений.</div>
   <div class="mini"><b>Как использовать в мультиплеере</b><br>Каждый участник устанавливает один и тот же пакет. Включи отметку совместимости только если мод не меняет правила синхронизации по-разному у разных игроков. Серверная синхронизация произвольного кода не выполняется.</div>
  </section>`;
 }
 function val(id){return document.getElementById(id)?.value||''}
 function status(s,bad){const e=document.getElementById('modStatus');if(e){e.textContent=s;e.style.borderColor=bad?'#a44':'#398b69'}}
 function files(){const name=val('modName').trim(),id=val('modId').trim(),version=val('modVersion').trim()||'1.0.0',description=val('modDesc').trim(),js=val('modJS'),css=val('modCSS'),mp=!!document.getElementById('modMP')?.checked;
  if(!name)throw Error('Укажи название мода');if(!/^[a-zA-Z0-9._-]{1,48}$/.test(id)||id==='.'||id==='..')throw Error('ID: только латиница, цифры, точка, дефис и подчёркивание');if(!/^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][a-zA-Z0-9.-]+)?$/.test(version))throw Error('Версия должна быть в формате 1.0.0');if(!js.trim())throw Error('Добавь JavaScript-код');new Function(js);
  const manifest={id,name,version,description,entry:'main.js',styles:css.trim()?['style.css']:[],multiplayerCompatible:mp,apiVersion:1};
  return {'manifest.json':JSON.stringify(manifest,null,2),'main.js':js,...(css.trim()?{'style.css':css}:{})};
 }
 function crc32(bytes){let c=-1;for(let i=0;i<bytes.length;i++){c^=bytes[i];for(let j=0;j<8;j++)c=(c>>>1)^((c&1)?0xedb88320:0)}return(c^-1)>>>0}
 function zip(files){const enc=new TextEncoder(),local=[],central=[];let offset=0;
  Object.keys(files).forEach(name=>{const n=enc.encode(name),d=enc.encode(files[name]),crc=crc32(d),h=new Uint8Array(30+n.length),v=new DataView(h.buffer);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x800,true);v.setUint32(14,crc,true);v.setUint32(18,d.length,true);v.setUint32(22,d.length,true);v.setUint16(26,n.length,true);h.set(n,30);local.push(h,d);
   const c=new Uint8Array(46+n.length),w=new DataView(c.buffer);w.setUint32(0,0x02014b50,true);w.setUint16(4,20,true);w.setUint16(6,20,true);w.setUint16(8,0x800,true);w.setUint32(16,crc,true);w.setUint32(20,d.length,true);w.setUint32(24,d.length,true);w.setUint16(28,n.length,true);w.setUint32(42,offset,true);c.set(n,46);central.push(c);offset+=h.length+d.length;
  });const cs=central.reduce((s,x)=>s+x.length,0),end=new Uint8Array(22),dv=new DataView(end.buffer);dv.setUint32(0,0x06054b50,true);dv.setUint16(8,central.length,true);dv.setUint16(10,central.length,true);dv.setUint32(12,cs,true);dv.setUint32(16,offset,true);return new Blob([...local,...central,end],{type:'application/zip'});
 }
 function validate(){try{files();status('✓ Ошибок синтаксиса нет. Манифест и JavaScript готовы.',false);return true}catch(e){status('Ошибка: '+e.message,true);return false}}
 function exportZip(){try{const f=files(),blob=zip(f),id=f['manifest.json'].match(/"id":\s*"([^"]+)/)[1],a=document.createElement('a'),u=URL.createObjectURL(blob);a.href=u;a.download=id+'.novaria';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),30000);status('Пакет '+id+'.novaria собран. Импортируй его в «Дополнения».',false)}catch(e){status('Ошибка: '+e.message,true)}}
 function install(){try{const f=files(),blob=zip(f);if(window.NovariaNative&&NovariaNative.installAddonPackage){status('Собираю пакет и передаю его встроенному установщику…',false);const reader=new FileReader();reader.onload=()=>{try{const data=String(reader.result).split(',')[1]||'';if(NovariaNative.installAddonPackage(data))status('Пакет передан установщику. Дождись сообщения об успешной установке.',false);else status('Не удалось передать пакет установщику.',true)}catch(e){status('Ошибка установки: '+e.message,true)}};reader.onerror=()=>status('Не удалось прочитать собранный ZIP.',true);reader.readAsDataURL(blob)}else{const item=window.NovariaAddons&&NovariaAddons.installPackage?NovariaAddons.installPackage(f):null;if(item)status('Мод «'+item.name+'» установлен локально в браузере. Перезапусти игру для применения.',false);else exportZip()}}catch(e){status('Ошибка: '+e.message,true)}}
 window.NVRModStudio={html:studio,validate,exportZip,install};
})();
