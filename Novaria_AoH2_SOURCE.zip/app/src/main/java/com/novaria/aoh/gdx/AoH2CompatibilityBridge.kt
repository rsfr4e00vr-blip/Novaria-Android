package com.novaria.aoh.gdx

/**
 * Compatibility records for progressively moving Novaria data into AoH2's
 * civilization/province/army concepts.
 *
 * IDs are generated deterministically from ISO codes and sorted region names.
 * They are adapter IDs, not claimed to be IDs from an AoH2 scenario file.
 */
data class AoH2CivilizationRef(
    val civilizationId: Int,
    val isoCode: String,
    val name: String,
    val populationMillions: Float,
    val gdpBillions: Float
)

data class AoH2ArmyStack(
    var units: Int = 0
) {
    init {
        units = units.coerceAtLeast(0)
    }

    fun reinforce(amount: Int) {
        require(amount >= 0) { "Reinforcement amount cannot be negative" }
        units += amount
    }

    fun withdraw(requested: Int): Int {
        require(requested >= 0) { "Withdrawal amount cannot be negative" }
        val removed = minOf(units, requested)
        units -= removed
        return removed
    }
}

data class AoH2ProvinceRef(
    val provinceId: Int,
    val civilizationId: Int,
    val countryIso: String,
    val countryName: String,
    val provinceName: String,
    val latitude: Float,
    val longitude: Float,
    val populationMillions: Float,
    val army: AoH2ArmyStack = AoH2ArmyStack()
)

data class AoH2WorldSnapshot(
    val civilizations: List<AoH2CivilizationRef>,
    val provinces: List<AoH2ProvinceRef>,
    val unassignedNovariaNodes: List<NovariaRegion>
)

object AoH2CompatibilityBridge {
    fun build(world: NovariaWorldData): AoH2WorldSnapshot {
        val civilizations = world.countries
            .sortedBy { it.id }
            .mapIndexed { index, country ->
                AoH2CivilizationRef(
                    civilizationId = index,
                    isoCode = country.id,
                    name = country.name,
                    populationMillions = country.populationMillions,
                    gdpBillions = country.gdpBillions
                )
            }

        val civilizationByName = civilizations.associateBy { it.name }
        val provinces = world.worldRegions
            .mapNotNull { region ->
                val civilization = civilizationByName[region.countryName]
                    ?: return@mapNotNull null
                civilization to region
            }
            .sortedWith(
                compareBy<Pair<AoH2CivilizationRef, WorldRegionPoint>>(
                    { it.first.isoCode },
                    { it.second.name }
                )
            )
            .mapIndexed { index, (civilization, region) ->
                AoH2ProvinceRef(
                    provinceId = index,
                    civilizationId = civilization.civilizationId,
                    countryIso = civilization.isoCode,
                    countryName = civilization.name,
                    provinceName = region.name,
                    latitude = region.latitude,
                    longitude = region.longitude,
                    populationMillions = region.populationMillions
                )
            }

        // Special Novaria nodes do not get a fabricated owner or AoH2 ID.
        return AoH2WorldSnapshot(
            civilizations = civilizations,
            provinces = provinces,
            unassignedNovariaNodes = world.novariaRegions
        )
    }
}
