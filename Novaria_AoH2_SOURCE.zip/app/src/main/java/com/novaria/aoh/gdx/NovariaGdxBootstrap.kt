package com.novaria.aoh.gdx

import com.badlogic.gdx.ApplicationAdapter
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.InputAdapter
import com.badlogic.gdx.assets.AssetManager
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.graphics.ShapeRenderer
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.math.Matrix4
import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.utils.viewport.FitViewport

/**
 * First data-connected map layer.
 *
 * Country and regional points are loaded from the existing Novaria data files.
 * Province polygons are intentionally not fabricated; the supplied AoH2
 * archive contains no map package and Novaria bundles regional center points.
 */
class NovariaGdxBootstrap : ApplicationAdapter() {
    companion object {
        private const val WORLD_WIDTH = 1280f
        private const val WORLD_HEIGHT = 720f
        private const val BACKGROUND_ASSET = "gdx/preview-background.png"
        private const val PICK_COUNTRY_RADIUS = 11f
        private const val PICK_REGION_RADIUS = 18f
    }

    private lateinit var viewport: FitViewport
    private lateinit var batch: SpriteBatch
    private lateinit var shapeRenderer: ShapeRenderer
    private lateinit var font: BitmapFont
    private lateinit var assets: AssetManager
    private lateinit var world: NovariaWorldData
    private lateinit var aoh2Snapshot: AoH2WorldSnapshot

    private val touchPoint = Vector2()
    private var inputMessage = "Tap a country or a Novaria region"
    private var selectedCountryId: String? = null
    private var selectedRegionName: String? = null
    private var selectedCountryProvinces: List<AoH2ProvinceRef> = emptyList()

    override fun create() {
        viewport = FitViewport(WORLD_WIDTH, WORLD_HEIGHT, OrthographicCamera())
        batch = SpriteBatch()
        shapeRenderer = ShapeRenderer()
        font = BitmapFont().apply { data.setScale(1.05f) }

        assets = AssetManager().apply {
            load(BACKGROUND_ASSET, Texture::class.java)
        }

        // Reuse existing Novaria world and region data without changing the WebView game.
        world = NovariaWorldDataRepository.load()
        aoh2Snapshot = AoH2CompatibilityBridge.build(world)

        Gdx.input.inputProcessor = object : InputAdapter() {
            override fun touchDown(
                screenX: Int,
                screenY: Int,
                pointer: Int,
                button: Int
            ): Boolean {
                touchPoint.set(screenX.toFloat(), screenY.toFloat())
                viewport.unproject(touchPoint)
                selectAt(touchPoint.x, touchPoint.y)
                return true
            }
        }
    }

    override fun resize(width: Int, height: Int) {
        viewport.update(width, height, true)
    }

    override fun render() {
        Gdx.gl.glClearColor(0.025f, 0.04f, 0.07f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)
        viewport.apply()

        if (!assets.update()) return

        val projection = viewport.camera.combined
        val background = assets.get(BACKGROUND_ASSET, Texture::class.java)

        batch.projectionMatrix = projection
        batch.begin()
        batch.draw(background, 0f, 0f, WORLD_WIDTH, WORLD_HEIGHT)
        batch.end()

        drawMapPoints(projection)

        batch.begin()
        font.draw(batch, "NOVARIA / WORLD DATA MAP", 28f, WORLD_HEIGHT - 32f)
        font.draw(
            batch,
            "AoH2 bridge: ${aoh2Snapshot.civilizations.size} civilizations / ${aoh2Snapshot.provinces.size} province records",
            28f,
            WORLD_HEIGHT - 64f
        )
        font.draw(batch, inputMessage, 28f, 30f)
        batch.end()
    }

    private fun drawMapPoints(projection: Matrix4) {
        shapeRenderer.projectionMatrix = projection
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled)

        // Country reference points.
        world.countries.forEach { country ->
            shapeRenderer.color = if (country.id == "UA") {
                Color(0.30f, 0.76f, 0.91f, 1f)
            } else {
                Color(0.72f, 0.82f, 0.91f, 0.78f)
            }
            shapeRenderer.circle(
                mapX(country.longitude),
                mapY(country.latitude),
                if (country.id == "UA") 5.5f else 2.7f
            )
        }

        // Novaria's own regional/resource nodes.
        world.novariaRegions.forEach { region ->
            shapeRenderer.color = if (region.name == selectedRegionName) {
                Color(1f, 0.92f, 0.48f, 1f)
            } else {
                Color(0.96f, 0.65f, 0.22f, 1f)
            }
            shapeRenderer.circle(mapX(region.longitude), mapY(region.latitude), 4.8f)
        }

        // Show the detailed regional centers belonging to the selected country.
        selectedCountryProvinces.forEach { province ->
            shapeRenderer.color = if (province.provinceName == selectedRegionName) {
                Color.WHITE
            } else {
                Color(0.35f, 0.91f, 0.65f, 1f)
            }
            shapeRenderer.circle(mapX(province.longitude), mapY(province.latitude), 3.6f)
        }
        shapeRenderer.end()

        shapeRenderer.begin(ShapeRenderer.ShapeType.Line)
        selectedCountry()?.let { country ->
            shapeRenderer.color = Color.WHITE
            shapeRenderer.circle(mapX(country.longitude), mapY(country.latitude), 10f)
        }
        selectedRegionName?.let { selected ->
            world.novariaRegions.firstOrNull { it.name == selected }?.let { region ->
                shapeRenderer.color = Color.WHITE
                shapeRenderer.circle(mapX(region.longitude), mapY(region.latitude), 10f)
            }
            selectedCountryProvinces.firstOrNull { it.provinceName == selected }?.let { province ->
                shapeRenderer.color = Color.WHITE
                shapeRenderer.circle(mapX(province.longitude), mapY(province.latitude), 9f)
            }
        }
        shapeRenderer.end()
    }

    private fun selectAt(worldX: Float, worldY: Float) {
        // First allow direct selection of Novaria's own regional nodes.
        val novariaRegion = world.novariaRegions.minByOrNull {
            distanceSquared(worldX, worldY, mapX(it.longitude), mapY(it.latitude))
        }
        if (novariaRegion != null && distanceSquared(
                worldX, worldY,
                mapX(novariaRegion.longitude), mapY(novariaRegion.latitude)
            ) <= PICK_REGION_RADIUS * PICK_REGION_RADIUS
        ) {
            selectedCountryId = null
            selectedCountryProvinces = emptyList()
            selectedRegionName = novariaRegion.name
            inputMessage = "${novariaRegion.name} • ${novariaRegion.populationMillions} млн • ${novariaRegion.description}"
            return
        }

        // If a country is already selected, try its regional centers.
        selectedCountry()?.let { country ->
            val province = selectedCountryProvinces.minByOrNull {
                distanceSquared(worldX, worldY, mapX(it.longitude), mapY(it.latitude))
            }
            if (province != null && distanceSquared(
                    worldX, worldY,
                    mapX(province.longitude), mapY(province.latitude)
                ) <= PICK_REGION_RADIUS * PICK_REGION_RADIUS
            ) {
                selectedRegionName = province.provinceName
                inputMessage = "${country.name} / ${province.provinceName} • ${province.populationMillions} млн • армия: ${province.army.units}"
                return
            }
        }

        val country = world.countries.minByOrNull {
            distanceSquared(worldX, worldY, mapX(it.longitude), mapY(it.latitude))
        }
        if (country != null && distanceSquared(
                worldX, worldY,
                mapX(country.longitude), mapY(country.latitude)
            ) <= PICK_COUNTRY_RADIUS * PICK_COUNTRY_RADIUS
        ) {
            selectedCountryId = country.id
            selectedRegionName = null
            selectedCountryProvinces = aoh2Snapshot.provinces.filter { it.countryIso == country.id }
            val regionCount = selectedCountryProvinces.size
            inputMessage = "${country.name} • ${country.populationMillions} млн • ВВП ${country.gdpBillions} млрд • регионов: $regionCount"
            return
        }

        selectedCountryId = null
        selectedRegionName = null
        selectedCountryProvinces = emptyList()
        inputMessage = "No country or region at this point"
    }

    private fun selectedCountry(): WorldCountry? =
        world.countries.firstOrNull { it.id == selectedCountryId }

    private fun mapX(longitude: Float): Float =
        ((longitude + 180f) / 360f) * WORLD_WIDTH

    private fun mapY(latitude: Float): Float =
        ((latitude + 90f) / 180f) * WORLD_HEIGHT

    private fun distanceSquared(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2
        val dy = y1 - y2
        return dx * dx + dy * dy
    }

    override fun dispose() {
        Gdx.input.inputProcessor = null
        assets.dispose()
        font.dispose()
        shapeRenderer.dispose()
        batch.dispose()
    }
}
