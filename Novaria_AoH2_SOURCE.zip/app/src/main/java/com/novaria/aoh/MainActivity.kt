package com.novaria.aoh

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.JavascriptInterface
import android.net.Uri
import android.content.Intent
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream
import java.util.UUID
import androidx.activity.result.contract.ActivityResultContracts
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var loadingOverlay: LinearLayout
    private lateinit var loadingText: TextView
    private val addonRoot: File by lazy { File(filesDir, "addons").apply { mkdirs() } }
    private val addonPicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) result.data?.data?.let { importAddon(it) }
    }

    // Локальная версия из assets (работает оффлайн)
    private val GAME_URL = "file:///android_asset/game/game.html"
    // После деплоя на Render можно переключить на:
    // private val GAME_URL = "https://your-app.onrender.com/game"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Полный immersive fullscreen
        setupFullscreen()

        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        loadingOverlay = findViewById(R.id.loadingOverlay)
        loadingText = findViewById(R.id.loadingText)

        setupWebView()
        setupBackPress()

        // Загружаем игру
        webView.loadUrl(GAME_URL)
    }

    private fun setupFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings

        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowFileAccessFromFileURLs = true // локальные пакеты дополнений загружаются из filesDir
        settings.allowContentAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.builtInZoomControls = false
        settings.displayZoomControls = false
        settings.setSupportZoom(false)
        settings.textZoom = 100

        // Важно для производительности карты
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)

        webView.addJavascriptInterface(AddonBridge(), "NovariaNative")
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Небольшая задержка, чтобы JS успел инициализироваться
                webView.postDelayed({
                    loadingOverlay.visibility = View.GONE
                    // Внедряем мобильные улучшения AoH3-стиля
                    injectAoH3MobileStyles()
                }, 600)
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    loadingText.text = "Ошибка загрузки. Проверьте интернет или assets."
                    Toast.makeText(this@MainActivity, "Не удалось загрузить игру", Toast.LENGTH_LONG).show()
                }
            }
        }

        webView.webChromeClient = WebChromeClient()
    }

    /**
     * Внедряем CSS и JS для стиля Age of History 3 + удобства на Android.
     * Это делает интерфейс ближе к AoH3: панель провинции, тёмная палитра,
     * крупные кнопки, fullscreen feel.
     */
    private fun injectAoH3MobileStyles() {
        val css = """
            :root {
                --aoh-bg: #0f0f1a;
                --aoh-panel: #1a1a2e;
                --aoh-border: #3a3a5c;
                --aoh-gold: #c9a227;
                --aoh-gold-light: #e8d5a3;
                --aoh-text: #e0e0e0;
                --aoh-muted: #8a8a9a;
            }
            
            html, body {
                margin: 0 !important;
                padding: 0 !important;
                background: var(--aoh-bg) !important;
                overflow: hidden !important;
                height: 100% !important;
                width: 100% !important;
                font-family: 'Roboto Condensed', 'Oswald', sans-serif !important;
                -webkit-tap-highlight-color: transparent !important;
                user-select: none !important;
            }
            
            header {
                background: linear-gradient(180deg, #1a1a2e 0%, #12121f 100%) !important;
                border-bottom: 2px solid var(--aoh-gold) !important;
                padding: 6px 12px !important;
                min-height: 48px !important;
            }
            
            header h1 {
                font-size: 16px !important;
                color: var(--aoh-gold-light) !important;
                margin: 0 !important;
            }
            
            .timebar {
                background: #161625 !important;
                border-bottom: 1px solid var(--aoh-border) !important;
                padding: 4px 8px !important;
                gap: 6px !important;
                flex-wrap: wrap !important;
            }
            
            .timebar button, .tabbar button, .cats button {
                background: linear-gradient(180deg, #2a2a45 0%, #1e1e35 100%) !important;
                border: 1px solid var(--aoh-border) !important;
                color: var(--aoh-text) !important;
                border-radius: 4px !important;
                padding: 8px 12px !important;
                font-size: 13px !important;
                min-height: 40px !important;
                box-shadow: 0 2px 4px rgba(0,0,0,0.4) !important;
            }
            
            .timebar button.good, button.good {
                background: linear-gradient(180deg, #2d5a2d 0%, #1e3d1e 100%) !important;
                border-color: #3a7a3a !important;
            }
            
            .timebar button.danger, button.danger {
                background: linear-gradient(180deg, #5a2d2d 0%, #3d1e1e 100%) !important;
                border-color: #7a3a3a !important;
            }
            
            .tabbar {
                background: #12121f !important;
                border-bottom: 1px solid var(--aoh-border) !important;
            }
            
            .cats button.on, .sub button.on {
                background: linear-gradient(180deg, #3a3a5c 0%, #2a2a45 100%) !important;
                border-color: var(--aoh-gold) !important;
                color: var(--aoh-gold-light) !important;
                box-shadow: inset 0 0 8px rgba(201,162,39,0.25) !important;
            }
            
            /* Панель контента */
            #content, .panel, section.panel {
                background: var(--aoh-panel) !important;
                border: 1px solid var(--aoh-border) !important;
                border-radius: 6px !important;
                color: var(--aoh-text) !important;
            }
            
            /* Кнопки строительства в стиле AoH3 */
            .build-btn, button[data-build], .actions button {
                background: linear-gradient(180deg, #2a2a45 0%, #1a1a30 100%) !important;
                border: 1px solid #4a4a6a !important;
                color: var(--aoh-gold-light) !important;
                padding: 10px 14px !important;
                margin: 4px !important;
                border-radius: 4px !important;
                font-weight: 600 !important;
                min-height: 44px !important;
                display: inline-flex !important;
                align-items: center !important;
                gap: 8px !important;
            }
            
            .build-btn:active, button:active {
                transform: scale(0.97) !important;
                filter: brightness(1.15) !important;
            }
            
            /* Карта на весь экран насколько возможно */
            #map, .map-container, [id*="map"] {
                width: 100% !important;
                min-height: 55vh !important;
            }
            
            /* Убираем лишние отступы на мобиле */
            main {
                padding: 0 !important;
                height: calc(100vh - 90px) !important;
                overflow: auto !important;
            }
            
            .topline {
                background: #161625 !important;
                font-size: 12px !important;
                padding: 4px 8px !important;
            }
            
            /* Скроллбары тёмные */
            ::-webkit-scrollbar { width: 6px; height: 6px; }
            ::-webkit-scrollbar-track { background: #12121f; }
            ::-webkit-scrollbar-thumb { background: #3a3a5c; border-radius: 3px; }
        """.trimIndent()

        val js = """
            (function() {
                // Добавляем стили AoH3
                if (!document.getElementById('aoh3-mobile-inject')) {
                    var style = document.createElement('style');
                    style.id = 'aoh3-mobile-inject';
                    style.textContent = `$css`;
                    document.head.appendChild(style);
                }
                
                // Делаем body fullscreen-friendly
                document.body.style.overflow = 'hidden';
                document.documentElement.style.overflow = 'hidden';
                
                // Увеличиваем удобство тапа по регионам/провинциям
                var mapEls = document.querySelectorAll('[id*="map"], .region, .province, svg path, canvas');
                mapEls.forEach(function(el) {
                    el.style.touchAction = 'manipulation';
                });
                
                console.log('[NovariaAoH] Age of History 3 mobile styles injected');
            })();
        """.trimIndent()

        webView.evaluateJavascript(js, null)
    }

    private inner class AddonBridge {
        @JavascriptInterface fun chooseAddon() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/octet-stream", "application/x-zip-compressed"))
                }
                addonPicker.launch(intent)
            }
        }
        @JavascriptInterface fun installAddonPackage(encodedZip: String): Boolean {
            return try {
                require(encodedZip.length <= 140 * 1024 * 1024) { "Пакет слишком большой" }
                val bytes = android.util.Base64.decode(encodedZip, android.util.Base64.DEFAULT)
                require(bytes.size <= 100 * 1024 * 1024) { "Пакет больше 100 МБ" }
                val source = File(cacheDir, "generated-addon-${UUID.randomUUID()}.novaria")
                source.writeBytes(bytes)
                runOnUiThread { importAddon(Uri.fromFile(source)) }
                true
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, e.message ?: "Не удалось установить мод", Toast.LENGTH_LONG).show() }
                false
            }
        }
        @JavascriptInterface fun listAddons(): String = buildAddonList().toString()
        @JavascriptInterface fun setEnabled(id: String, enabled: Boolean): Boolean {
            if (!id.matches(Regex("[a-zA-Z0-9._-]{1,64}"))) return false
            val dir = File(addonRoot, id)
            if (!dir.isDirectory) return false
            getSharedPreferences("addons", MODE_PRIVATE).edit().putBoolean(id, enabled).apply()
            return true
        }
        @JavascriptInterface fun deleteAddon(id: String): Boolean {
            if (!id.matches(Regex("[a-zA-Z0-9._-]{1,64}"))) return false
            val dir = File(addonRoot, id)
            val ok = dir.canonicalFile.parentFile == addonRoot.canonicalFile && dir.exists() && dir.deleteRecursively()
            if (ok) getSharedPreferences("addons", MODE_PRIVATE).edit().remove(id).apply()
            return ok
        }
    }

    private fun buildAddonList(): JSONArray {
        val result = JSONArray()
        addonRoot.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.forEach { dir ->
            try {
                val manifest = File(dir, "manifest.json")
                if (!manifest.isFile) return@forEach
                val m = JSONObject(manifest.readText())
                val id = m.optString("id", dir.name)
                val enabled = getSharedPreferences("addons", MODE_PRIVATE).getBoolean(id, true)
                result.put(JSONObject().apply {
                    put("id", id); put("name", m.optString("name", id))
                    put("version", m.optString("version", "1.0.0"))
                    put("description", m.optString("description", "Дополнение Novaria"))
                    put("multiplayerCompatible", m.optBoolean("multiplayerCompatible", false))
                    put("enabled", enabled)
                    put("entry", m.optString("entry", ""))
                    put("styles", m.optJSONArray("styles") ?: JSONArray())
                    put("installedAt", dir.lastModified()); put("basePath", Uri.fromFile(dir).toString() + "/")
                })
            } catch (_: Exception) { }
        }
        return result
    }

    private fun importAddon(uri: Uri) {
        Thread {
            var message = "Не удалось установить дополнение"
            var success = false
            val temp = File(cacheDir, "addon-import-${System.currentTimeMillis()}")
            try {
                temp.mkdirs()
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Файл не читается" }
                    ZipInputStream(input).use { zip ->
                        var total = 0L; var count = 0
                        while (true) {
                            val entry = zip.nextEntry ?: break
                            count++; require(count <= 5000) { "Слишком много файлов" }
                            val name = entry.name.replace('\\', '/')
                            require(!name.startsWith("/") && !name.split('/').any { it == ".." } && !name.contains(':')) { "Недопустимый путь в архиве" }
                            val out = File(temp, name).canonicalFile
                            require(out.path.startsWith(temp.canonicalPath + File.separator) || out == temp.canonicalFile) { "Недопустимый путь" }
                            if (entry.isDirectory) out.mkdirs() else {
                                out.parentFile?.mkdirs()
                                out.outputStream().use { sink ->
                                    val buffer = ByteArray(8192)
                                    while (true) {
                                        val n = zip.read(buffer); if (n < 0) break
                                        total += n; require(total <= 100L * 1024 * 1024) { "Архив больше 100 МБ" }
                                        sink.write(buffer, 0, n)
                                    }
                                }
                            }
                            zip.closeEntry()
                        }
                    }
                }
                val mf = File(temp, "manifest.json")
                require(mf.isFile) { "В архиве нет manifest.json" }
                val m = JSONObject(mf.readText())
                val id = m.optString("id", "")
                require(id.matches(Regex("[a-zA-Z0-9._-]{1,64}")) && id != "." && id != "..") { "Неверный ID дополнения" }
                require(m.optString("name").isNotBlank()) { "В manifest.json не указано name" }
                val entry = m.optString("entry", "")
                if (entry.isNotBlank()) require(File(temp, entry).canonicalPath.startsWith(temp.canonicalPath + File.separator) && File(temp, entry).isFile && entry.endsWith(".js")) { "JS-файл entry не найден" }
                val styles = m.optJSONArray("styles") ?: JSONArray()
                for (i in 0 until styles.length()) {
                    val css = styles.getString(i)
                    require(css.endsWith(".css") && File(temp, css).canonicalPath.startsWith(temp.canonicalPath + File.separator) && File(temp, css).isFile) { "CSS-файл не найден: $css" }
                }
                val dest = File(addonRoot, id)
                // Use a unique hidden backup name: "$id.backup" could collide with
                // a legitimate add-on whose ID is, for example, "${id}.backup".
                val backup = File(addonRoot, ".update-backup-${UUID.randomUUID()}")
                if (dest.exists()) require(dest.renameTo(backup)) { "Не удалось сохранить предыдущую версию" }
                if (!temp.renameTo(dest)) {
                    if (backup.exists()) backup.renameTo(dest)
                    error("Не удалось записать дополнение")
                }
                backup.deleteRecursively()
                success = true
                message = "Установлено: ${m.optString("name")} ${m.optString("version", "1.0.0")}"
            } catch (e: Exception) { message = e.message ?: message }
            finally { if (temp.exists()) temp.deleteRecursively(); if (uri.scheme == "file") uri.path?.let { File(it).delete() } }
            runOnUiThread {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('novaria-addons-changed',{detail:{success:$success}}));", null)
            }
        }.start()
    }

    private fun setupBackPress() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    // Можно добавить диалог выхода
                    finish()
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        setupFullscreen()
        webView.onResume()
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
