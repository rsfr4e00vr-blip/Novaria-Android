package com.novaria.aoh.gdx

import android.os.Bundle
import com.badlogic.gdx.backends.android.AndroidApplication
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration

/**
 * Isolated LibGDX Android entry point.
 *
 * The existing MainActivity remains the app's normal launcher. This activity is
 * registered separately so the LibGDX runtime can be tested before migration.
 */
class GdxLauncherActivity : AndroidApplication() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val config = AndroidApplicationConfiguration().apply {
            useImmersiveMode = true
            useWakelock = true
            useAccelerometer = false
            useCompass = false
        }

        initialize(NovariaGdxBootstrap(), config)
    }
}
