package com.novaria.aoh.gdx

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.utils.JsonReader

data class WorldCountry(
    val id: String,
    val name: String,
    val latitude: Float,
    val longitude: Float,
    val populationMillions: Float,
    val gdpBillions: Float
)

data class NovariaRegion(
    val id: String,
    val name: String,
    val latitude: Float,
    val longitude: Float,
    val populationMillions: Float,
    val description: String
)

data class WorldRegionPoint(
    val countryName: String,
    val name: String,
    val latitude: Float,
    val longitude: Float,
    val populationMillions: Float
)

data class NovariaWorldData(
    val countries: List<WorldCountry>,
    val novariaRegions: List<NovariaRegion>,
    val worldRegions: List<WorldRegionPoint>
)

/**
 * Read-only adapter over Novaria's existing country and regional data.
 * No source JS/JSON file is rewritten by this repository.
 */
object NovariaWorldDataRepository {
    fun load(
        countryAssetPath: String = "game/world.json",
        regionAssetPath: String = "game/regions_map.json"
    ): NovariaWorldData {
        val root = JsonReader().parse(Gdx.files.internal(countryAssetPath))
        val countries = mutableListOf<WorldCountry>()
        val novariaRegions = mutableListOf<NovariaRegion>()
        val worldRegions = mutableListOf<WorldRegionPoint>()

        val countryNodes = root.get("countries")
        for (index in 0 until countryNodes.size) {
            val node = countryNodes.get(index)
            countries += WorldCountry(
                id = node.getString("i", ""),
                name = node.getString("ru", node.getString("i", "Unknown")),
                latitude = node.getFloat("lat", 0f),
                longitude = node.getFloat("lon", 0f),
                populationMillions = node.getFloat("p", 0f),
                gdpBillions = node.getFloat("g", 0f)
            )
        }

        val novariaNodes = root.get("novaria")
        if (novariaNodes != null) {
            for (index in 0 until novariaNodes.size) {
                val node = novariaNodes.get(index)
                novariaRegions += NovariaRegion(
                    id = node.getString("id", ""),
                    name = node.getString("ru", node.getString("id", "Region")),
                    latitude = node.getFloat("lat", 0f),
                    longitude = node.getFloat("lon", 0f),
                    populationMillions = node.getFloat("pop", 0f),
                    description = node.getString("note", "")
                )
            }
        }

        val regionRoot = JsonReader().parse(Gdx.files.internal(regionAssetPath))
        val regionNodes = regionRoot.get("regions")
        for (index in 0 until regionNodes.size) {
            val node = regionNodes.get(index)
            worldRegions += WorldRegionPoint(
                countryName = normalizeCountryName(node.getString("country", "")),
                name = node.getString("name", ""),
                latitude = node.getFloat("lat", 0f),
                longitude = node.getFloat("lon", 0f),
                populationMillions = node.getFloat("pop", 0f)
            )
        }

        return NovariaWorldData(countries, novariaRegions, worldRegions)
    }

    private fun normalizeCountryName(name: String): String = when (name) {
        "Южная Африка" -> "Южно-Африканская Республика"
        else -> name
    }
}
