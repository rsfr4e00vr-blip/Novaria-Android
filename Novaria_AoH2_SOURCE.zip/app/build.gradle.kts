plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Version is declared once in the root gradle.properties.
val gdxVersion: String by project

// libGDX native artifacts are extracted into build/ and packaged as JNI libraries.
val gdxNatives by configurations.creating {
    isCanBeConsumed = false
    isCanBeResolved = true
}

android {
    namespace = "com.novaria.aoh"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.novaria.aoh"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2.0"
    }

    sourceSets.getByName("main").jniLibs.srcDir(
        layout.buildDirectory.dir("generated/gdxJniLibs")
    )

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    
    kotlinOptions {
        jvmTarget = "17"
    }
    
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")

    // libGDX core + Android backend. The existing WebView game remains the active launcher.
    implementation("com.badlogicgames.gdx:gdx:$gdxVersion")
    implementation("com.badlogicgames.gdx:gdx-backend-android:$gdxVersion")

    // Native binaries for current Android device/emulator ABIs.
    gdxNatives("com.badlogicgames.gdx:gdx-platform:$gdxVersion:natives-arm64-v8a")
    gdxNatives("com.badlogicgames.gdx:gdx-platform:$gdxVersion:natives-armeabi-v7a")
    gdxNatives("com.badlogicgames.gdx:gdx-platform:$gdxVersion:natives-x86")
    gdxNatives("com.badlogicgames.gdx:gdx-platform:$gdxVersion:natives-x86_64")
}

// Extract libGDX .so files to the Android Gradle JNI source directory.
// This does not modify app/src/main or the user's game assets.
val extractGdxNatives by tasks.registering {
    val outputDir = layout.buildDirectory.dir("generated/gdxJniLibs")
    inputs.files(gdxNatives)
    outputs.dir(outputDir)

    doLast {
        val destination = outputDir.get().asFile
        destination.deleteRecursively()

        gdxNatives.files.forEach { archive ->
            val abi = when {
                archive.name.endsWith("natives-arm64-v8a.jar") -> "arm64-v8a"
                archive.name.endsWith("natives-armeabi-v7a.jar") -> "armeabi-v7a"
                archive.name.endsWith("natives-x86.jar") -> "x86"
                archive.name.endsWith("natives-x86_64.jar") -> "x86_64"
                else -> null
            }

            if (abi != null) {
                val abiDirectory = File(destination, abi).apply { mkdirs() }
                project.copy {
                    from(project.zipTree(archive))
                    include("*.so")
                    into(abiDirectory)
                }
            }
        }
    }
}

tasks.named("preBuild").configure {
    dependsOn(extractGdxNatives)
}
