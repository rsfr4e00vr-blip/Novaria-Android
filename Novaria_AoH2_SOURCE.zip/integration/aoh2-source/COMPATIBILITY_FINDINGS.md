# AoH2 compatibility findings

## Binary compatibility
The supplied `AoC2-Updated-Compiled.jar` contains libGDX `1.9.10` and the desktop LWJGL backend. The Android project now declares libGDX `1.14.2`.

Do not add the whole original JAR directly to the Android app: it contains its own `com.badlogic.gdx.*` classes and would conflict with the newer libGDX artifacts. Desktop backend classes and natives are also not the Android backend.

## Source compilation probe
A local Java 8-target compilation probe compiled 185 of the 187 supplied AoH2 Java source files against the supplied JAR. Two source files were excluded because they import JDK 8-era packages absent from the available JDK 21:
- `LanguageManager.java` — `org.omg.SendingContext.RunTime`
- `PeaceTreaty_Data.java` — `com.sun.javaws.exceptions.CacheAccessException`

This probe does not prove Android runtime compatibility. The original source still needs selective refactoring and testing against libGDX 1.14.2.

## Current safe integration
Stage 6 adds a separate Kotlin compatibility bridge that maps Novaria country/region data into AoH2-style civilization IDs, province records, and army-stack state. It does not add the old JAR to the Android dependency graph and does not replace Novaria's economy or diplomacy.
