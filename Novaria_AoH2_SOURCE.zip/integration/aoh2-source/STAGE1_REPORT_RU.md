# Этап 1 — выделение игровых классов Age of Civilizations 2.5

## Что сделано
- В исходный Android Studio проект Novaria добавлена отдельная папка `integration/aoh2-source/`.
- Скопированы все 187 Java-файлов из исходного архива AoH2, с сохранением исходных пакетов и структуры.
- Добавлена зависимость `AoC2-Updated-Compiled.jar`, на которую прямо указывает README исходного проекта.
- Добавлена копия README исходного AoH2 для сохранения происхождения и оговорок.
- Существующая папка `app/`, WebView Launcher, игровые JS/CSS-файлы, экономика, дипломатия и сетевые файлы Novaria не изменялись.

## Карта игровых подсистем
### Игровое ядро и ход партии
`AoCGame.java`, `Game.java`, `Game_Action.java`, `Game_NewGame.java`, `Game_NextTurnUpdate.java`, `Turn_NewTurn.java`, `Game_Ages.java`, `Game_Autonomy.java`, `Player.java`, `RTS.java`

### Государства, провинции и территории
`Civilization.java`, `Province.java`, `Province_Army.java`, `Province_Border.java`, `Alliance.java`, `AutonomyStatus.java`, `Vassal_GameData.java`, `CreateVassal_Data.java`, `UnionFlagsToGenerate.java`, `VassalFlagsToGenerate.java`

### Война и мир
`War_GameData.java`, `PeaceTreaty_Data.java`, `PeaceTreaty_Demands.java`, `Message_War.java`, `Message_PrepareForWar.java`, `Message_PeaceTreaty.java`, `Menu_InGame_DeclareWar.java`, `Menu_InGame_WarDetails.java`, `Menu_PeaceTreaty.java`, `Menu_PeaceTreaty_Response.java`

### Дипломатия и решения
`DiplomacyManager.java`, `Game_Decisions.java`, `Decision_GameData.java`, `Civ_Decision_GameData.java`, `Civilization_Diplomacy_ImproveRelations_GameData.java`, `Menu_InGame_ImproveRelations.java`, `Menu_InGame_TradeRequest.java`

### ИИ и события
`AI.java`, `AI_Style.java`, `DynamicEventManager.java`, `DynamicEventManager_CivilWar.java`, `DynamicEventManager_Class.java`, `DynamicEventManager_Economy.java`, `DynamicEventManager_Leader.java`, `DynamicEventManager_War.java`, `EventsManager.java`, `Game_Events.java`, `Event_GameData.java`, `Event_Outcome.java`

### Сохранения и сценарии
`Save_GameData_1.java`, `Save_GameData2.java`, `Save_Civ_GameData.java`, `Save_Provinces_GameData.java`, `Game_Scenarios.java`, `Scenario_GameData_Province2.java`, `Scenario_GameData_Diplomacy2.java`, `Scenario_GameData_Diplomacy_VassalsData.java`

### Карта, ввод и отрисовка
`Map_Scroll.java`, `Map_TouchManager.java`, `Game_Render.java`, `Game_Render_Province.java`, `Images.java`, `FlagManager.java`, `Flag_GameData.java`, `TimelapseManager.java`

### Интерфейс AoH2 (потребует отдельной адаптации)
`Menu.java`, `MenuManager.java`, `Menu_InGame.java`, `Menu_Main.java`, `Menu_InitGame.java`, `Menu_NextPlayerTurn.java`, `Menu_LoadSave.java`, `Button_Diplomacy.java`, `Button_Government.java`, `Dialog.java`, `SliderMenu.java`

## Важные технические выводы
- AoH2 source README предупреждает, что исходный код неполный: отсутствующие базовые классы должны браться из `AoC2-Updated-Compiled.jar`. Поэтому исходники AoH2 пока размещены как изолированный интеграционный слой, а не подключены в компиляцию Android-приложения.
- В исходном AoH2 репозитории нет готового Android Launcher и Gradle-модуля LibGDX. Обнаружены 187 Java-файлов: 183 в пакете `age...` и 4 вспомогательных класса `com...`.
- Текущий Novaria Android-проект использует Kotlin + Android WebView. Перевод рендеринга на LibGDX нельзя делать заменой текущего Launcher: на следующих этапах потребуется отдельный игровой экран/модуль и постепенное переключение, чтобы сохранить работающую Novaria.
- APK на этом этапе не пересобирался: этап 1 — инвентаризация и безопасное выделение исходников, а не подключение их к Android-компиляции.

## Проверка целостности
- Исходные файлы Novaria внутри Android Studio проекта оставлены без изменений.
- AoH2 исходники и JAR лежат вне `app/src/main`, поэтому Android Gradle не пытается компилировать несовместимый исходный код преждевременно.
- Следующий этап: подобрать и подключить совместимые LibGDX зависимости отдельным модулем, не меняя текущую WebView-сборку.

## Происхождение
Исходники AoH2 взяты из переданного пользователем архива `Age-of-Civilizations-2.5-master.zip`. См. `UPSTREAM_README.md` и исходные условия авторства в нём.