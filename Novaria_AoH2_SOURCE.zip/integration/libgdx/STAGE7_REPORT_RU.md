# Этап 7 — подготовка проверки APK

## Что сделано
- Добавлен GitHub Actions workflow `.github/workflows/android-apk.yml`.
- Workflow устанавливает JDK 17, Android SDK API 35, Build Tools 35.0.0 и Gradle 8.9.
- Workflow запускает `gradle --no-daemon assembleDebug`.
- При успешной сборке APK публикуется как артефакт `Novaria-AoH2-Android-APK`.
- Добавлена русская инструкция `BUILD_APK_GITHUB_ACTIONS_RU.md`.

## Что проверено
- YAML workflow успешно разобран.
- Пути к Gradle-проекту и ожидаемому APK соответствуют структуре приложения.
- Workflow использует установленный Gradle 8.9, поэтому ему не требуются отсутствующие в архиве `gradlew` и `gradle-wrapper.jar`.

## Что не удалось подтвердить
В среде подготовки нет установленного Gradle и Android SDK. Workflow не запускался, поэтому реальный APK здесь не собран и не проверен. Не следует считать APK готовым до успешного выполнения GitHub Actions или сборки в Android Studio.

## Что нужно для фактической проверки
Загрузить содержимое `NovariaAoH_AndroidStudio` в GitHub-репозиторий, открыть Actions и вручную запустить `Build Novaria AoH2 Android APK`. Инструкция находится в `BUILD_APK_GITHUB_ACTIONS_RU.md`.

## Следующий этап
После первого успешного APK build можно продолжать портирование отдельных механик AoH2. Для настоящей провинциальной карты всё ещё нужен map/assets-пакет AoH2 или набор GeoJSON границ; без него нельзя безопасно делать соседство провинций, перемещение армий и территориальные бои.
