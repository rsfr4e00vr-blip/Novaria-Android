# Этап 3 — отдельный Android Launcher для LibGDX

## Что сделано
- Создан `GdxLauncherActivity`, наследующий `AndroidApplication`.
- Launcher создаёт `AndroidApplicationConfiguration` и запускает `NovariaGdxBootstrap`.
- Добавлен минимальный тестовый экран LibGDX, чтобы проверить инициализацию OpenGL, рендеринг и жизненный цикл.
- Новая Activity зарегистрирована в `AndroidManifest.xml` под отдельным действием `com.novaria.aoh.OPEN_GDX_PREVIEW`.
- Добавлена декларация OpenGL ES 2.0 как необязательное устройство-требование, чтобы не ограничивать установку существующей WebView-версии на устройствах без GLES 2.
- Для тестовой Activity сохранён альбомный режим и immersive/fullscreen режим.

## Сохранность Novaria
- `MainActivity` осталась основной LAUNCHER Activity.
- WebView, текущий экран игры, игровые данные, экономика, дипломатия и мультиплеер не переключались на LibGDX.
- Новая Activity не подменяет и не перезаписывает текущую.

## Как отдельно запустить тестовый экран после Gradle Sync и установки приложения
Через ADB:
`adb shell am start -a com.novaria.aoh.OPEN_GDX_PREVIEW`

Либо Android Studio: создать Run Configuration типа Android App с запуском Activity `com.novaria.aoh.gdx.GdxLauncherActivity`.

## Проверка
Структура исходников и Manifest проверены статически. Полная компиляция Kotlin/Android и запуск на устройстве не подтверждены, поскольку в среде сборки отсутствуют Gradle, wrapper JAR и Android SDK. Для реальной проверки нужно выполнить Gradle Sync и запуск на Android-устройстве из Android Studio.

## Следующий этап
Адаптация ввода, экрана и загрузки ресурсов. Пока это будет делаться внутри отдельного LibGDX слоя; существующий WebView путь остаётся резервным и основным.
