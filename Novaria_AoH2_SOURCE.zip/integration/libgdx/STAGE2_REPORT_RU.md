# Этап 2 — подключение LibGDX

## Что сделано
- Подключён стабильный релиз libGDX `1.14.2` через Maven Central.
- Добавлены `gdx` (core) и `gdx-backend-android` (Android backend).
- Добавлены native artifacts `gdx-platform` для ABI: `arm64-v8a`, `armeabi-v7a`, `x86`, `x86_64`.
- Добавлена Gradle-задача `extractGdxNatives`: она извлекает `.so` библиотеки в `app/build/generated/gdxJniLibs/<abi>` перед Android-сборкой.
- Путь generated JNI-библиотек подключён к `android.sourceSets.main.jniLibs`.
- Версия LibGDX вынесена в корневой `gradle.properties`.

## Что намеренно не менялось
- `MainActivity.kt` и текущий WebView Launcher не изменялись.
- `AndroidManifest.xml`, навигация, игровые JS/CSS/JSON-данные, экономика, дипломатия и мультиплеер Novaria не переписывались.
- AoH2 Java-классы из этапа 1 по-прежнему находятся вне `app/src/main/java`: они не включены в компиляцию, пока не будут устранены зависимости от отсутствующих базовых классов исходного AoH2.

## Ограничение проверки
В среде подготовки отсутствуют установленный Gradle и `gradle-wrapper.jar`, а Android SDK недоступен. Поэтому здесь невозможно честно подтвердить `assembleDebug` или APK. Gradle-конфигурация подготовлена, но окончательную проверку синхронизации и сборки нужно выполнить в Android Studio с интернетом и установленным Android SDK.

## Следующий этап
Создать отдельный LibGDX Game/Core слой и Android Launcher-класс, не заменяя текущий WebView Launcher. Переключение Novaria на новый экран не выполнять, пока не будет проверен запуск отдельного тестового LibGDX экрана.
