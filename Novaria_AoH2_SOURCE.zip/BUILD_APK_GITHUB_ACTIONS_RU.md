# Сборка APK через GitHub Actions

## Что делает workflow
Файл `.github/workflows/android-apk.yml` устанавливает JDK 17, Android SDK (API 35), Gradle 8.9 и запускает `assembleDebug`. Если сборка успешна, APK загружается как артефакт `Novaria-AoH2-Android-APK`.

## Как получить APK
1. Загрузите содержимое папки `NovariaAoH_AndroidStudio` в отдельный GitHub-репозиторий (не загружайте ZIP как единственный файл).
2. Откройте вкладку **Actions**.
3. Выберите **Build Novaria AoH2 Android APK**.
4. Нажмите **Run workflow**.
5. Дождитесь зелёного статуса сборки.
6. Внизу результата скачайте артефакт **Novaria-AoH2-Android-APK** и извлеките из него `app-debug.apk`.

## Важное ограничение текущего этапа
Workflow создан и YAML/пути проверены, но в среде подготовки нет Gradle и Android SDK, поэтому сам workflow здесь не запускался и APK ещё не получен. Не считайте APK собранным до успешного результата GitHub Actions или Android Studio.
